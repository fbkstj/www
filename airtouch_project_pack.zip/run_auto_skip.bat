@echo off
chcp 65001 >nul
title YouTube 智慧自動略過廣告守護小精靈 - AirTouch Edge AI
color 0B
cls
echo =====================================================================
echo    🛡️ YouTube 智慧自動略過廣告守護小精靈 (AirTouch Sub-system)
echo =====================================================================
echo  [功能特色]
echo   1. 自動辨識 YouTube「略過廣告」/「略過」/「Skip Ads」按鈕
echo   2. 出現時自動 0 秒精準點擊，省去手動拿滑鼠的麻煩
echo   3. 具備游標保護機制：點擊後 0.02 秒內自動復原滑鼠位置，完全不干擾工作！
echo   4. 內建高科技提示雙音效，跳過時即時通知
echo ---------------------------------------------------------------------
echo  正在啟動 AI 影像偵測守護引擎...
echo =====================================================================
echo.

python auto_skip_ad.py

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [提示] 執行時遇到問題，請確認已安裝相依套件: pip install -r requirements.txt
    pause
)
