﻿AirTouch 無接觸手勢智慧遙控 - 專題程式包
========================================

【事前準備】
1. 安裝 Python 3.10 以上版本（安裝時勾選 Add Python to PATH）。
2. 開啟命令提示字元，執行：
   pip install mediapipe opencv-python pyautogui numpy pillow pywin32 sounddevice soundfile SpeechRecognition
3. 準備一顆 USB 網路攝影機。

【開始使用】
- 雙擊 run_airtouch.bat：啟動手勢遙控（hand_landmarker.task 是手部模型，請與程式放在同一資料夾）。
- 雙擊 run_auto_skip.bat：啟動 YouTube 廣告自動略過。
- 雙擊 run_screen_recorder.bat：錄製示範影片。
- AirTouch_YouTube_AutoSkip_Extension 資料夾：Chrome 擴充功能，安裝方式見資料夾內說明。

詳細說明請看 AirTouch_無接觸手勢遙控實作指南.md
展示網頁：https://fbkstj.github.io/www/#page/airtouch_project_showcase
