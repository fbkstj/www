# -*- coding: utf-8 -*-
"""
Desktop Screen Recorder for Teaching Demonstrations (專題教材全螢幕影音雙軌錄影工具)
================================================================================
功能亮點：
1. 【全螢幕高畫質擷取 (Video)】：自動擷取 1080p 全桌面，完整記錄 YouTube 播放與懸浮 AirTouch 隔空互動。
2. 【同步即時收音 (Audio)】：透過 sounddevice 背景平行錄製麥克風與環境音效，影音完美同步。
3. 【語音控制 (Voice Control)】：對著麥克風說「關閉程式」或「停止錄影」，即可自動結束並存檔！
4. 【手動停止】：隨時按 [Enter] 鍵或 [Ctrl+C] 亦可結束。
5. 【自動 FFmpeg 合流】：結束時自動將影像與聲音封裝為標準 H.264/AAC MP4 影片，存於 recordings/。
"""

import os
import sys
import time
import threading
import collections
import subprocess
import winsound
import numpy as np
import cv2
from PIL import ImageGrab

try:
    import sounddevice as sd
    import soundfile as sf
    HAS_AUDIO = True
except ImportError:
    HAS_AUDIO = False

try:
    import speech_recognition as sr
    HAS_SR = True
except ImportError:
    HAS_SR = False

try:
    import win32service, win32gui
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False

def ensure_desktop():
    if HAS_WIN32:
        try:
            hwinsta = win32service.OpenWindowStation('winsta0', False, 0x02000000)
            hwinsta.SetProcessWindowStation()
            hdesk = win32service.OpenDesktop('default', 0, False, 0x02000000)
            hdesk.SetThreadDesktop()
        except Exception:
            pass

class AudioRecorder:
    def __init__(self, samplerate=44100):
        self.samplerate = samplerate
        self.frames = []
        self.stream = None
        self.recording = False

    def start(self):
        if not HAS_AUDIO:
            return
        self.frames = []
        self.recording = True
        def callback(indata, frames, time_info, status):
            if self.recording:
                self.frames.append(indata.copy())
        try:
            self.stream = sd.InputStream(samplerate=self.samplerate, channels=1, callback=callback)
            self.stream.start()
        except Exception as e:
            print(f"[錄音警告] 音訊串流啟動失敗: {e}")
            self.stream = None

    def stop(self, out_wav_path):
        self.recording = False
        if self.stream:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None

        if self.frames and HAS_AUDIO:
            try:
                audio_data = np.concatenate(self.frames, axis=0)
                sf.write(out_wav_path, audio_data, self.samplerate)
                return True
            except Exception as e:
                print(f"[錄音警告] 儲存音訊檔案失敗: {e}")
        return False

class VoiceExitListener:
    """
    語音指令監聽器 (錄影工具)
    --------------------------
    • 說「停止錄影」：結束錄影並存檔。
    • 說「關閉程式」：結束錄影存檔，並自動連帶關閉 AirTouch 輔助視窗！
    """
    def __init__(self, on_command_callback):
        self.on_command = on_command_callback
        self.running = False
        self.r = sr.Recognizer() if HAS_SR else None
        self.audio_buf = collections.deque(maxlen=16000 * 2)
        self.stream = None

    def start(self):
        if not HAS_AUDIO or not HAS_SR or not self.r:
            return
        self.running = True
        def callback(indata, frames, time_info, status):
            if self.running:
                self.audio_buf.extend(indata[:, 0].copy())
        try:
            self.stream = sd.InputStream(samplerate=16000, channels=1, dtype='int16', callback=callback)
            self.stream.start()
        except Exception as e:
            print(f"[錄影語音] 啟動失敗: {e}")
            return

        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if self.stream:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None

    def _worker(self):
        last_check = time.time()
        while self.running:
            time.sleep(0.35)
            if len(self.audio_buf) < 16000:
                continue
            data = np.array(self.audio_buf, dtype='int16')
            rms = np.sqrt(np.mean(data.astype(np.float32)**2))
            if rms > 140:
                now = time.time()
                if now - last_check < 0.8:
                    continue
                last_check = now
                ad = sr.AudioData(data.tobytes(), 16000, 2)
                try:
                    text = self.r.recognize_google(ad, language='zh-TW')
                    print(f"[錄影語音] 🎙️ 聽取到: '{text}'")
                    if any(k in text for k in ['關閉程式', '結束程式', '退出程式', '關閉', '退出', '結束', '停止錄影', '停止', 'close', 'exit']):
                        print(f"[錄影語音] 🎯 辨識到「{text}」！正在執行關閉...")
                        try:
                            winsound.Beep(900, 150)
                            winsound.Beep(600, 250)
                        except Exception:
                            pass
                        self.on_command(text)
                        break
                except (sr.UnknownValueError, sr.RequestError):
                    pass

def main():
    print("=" * 70)
    print("   🎥 AirTouch 全螢幕教材示範錄影工具 (影音雙軌 + 語音控制版)")
    print("=" * 70)
    print("功能說明：")
    print("  • 完整錄製整台電腦 1080p 螢幕 (YouTube 播放 + 右上角懸浮 AirTouch 鏡頭)")
    print("  • 同步即時收錄麥克風與環境音效 (含影音雙軌)")
    print("  • 支援【語音控制】：對著麥克風說「關閉程式」或「停止錄影」即可退出！")
    print("  • 亦可直接在控制台按 [Enter] 鍵結束錄影")
    print("-" * 70)
    print("操作步驟：")
    print("  1. 請確保已開啟 AirTouch 手勢視窗 與 YouTube 影片")
    print("  2. 系統將在 3 秒倒數後自動開跑錄影")
    print("  3. 想要結束時，請說「關閉程式」或按下 [Enter] 鍵")
    print("=" * 70)

    rec_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "recordings")
    os.makedirs(rec_dir, exist_ok=True)

    ensure_desktop()
    screen_img = ImageGrab.grab()
    screen_w, screen_h = screen_img.size
    print(f"[偵測螢幕解析度] {screen_w} x {screen_h}")

    now_str = time.strftime("%Y%m%d_%H%M%S")
    temp_v = os.path.join(rec_dir, f"temp_v_{now_str}.mp4")
    temp_a = os.path.join(rec_dir, f"temp_a_{now_str}.wav")
    final_mp4 = os.path.join(rec_dir, f"screen_demo_{now_str}.mp4")

    target_fps = 20.0
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    writer = cv2.VideoWriter(temp_v, fourcc, target_fps, (screen_w, screen_h))

    print("\n[提示] 系統將在 3 秒後開始錄影，請切換至操作畫面...")
    for i in range(3, 0, -1):
        print(f"倒數: {i}...")
        try:
            winsound.Beep(1000, 80)
        except Exception:
            pass
        time.sleep(1)

    try:
        winsound.Beep(1600, 200)
    except Exception:
        pass

    print("\n" + "=" * 70)
    print("   🔴 正在錄影中... (含畫面與聲音)")
    print("   👉 結束方式 A：對麥克風說「關閉程式」或「停止錄影」")
    print("   👉 結束方式 B：回到此視窗按下 [Enter] 鍵")
    print("=" * 70)

    running = True
    close_reason = ""

    def trigger_stop(reason="User Action"):
        nonlocal running, close_reason
        close_reason = reason
        nonlocal running
        running = False

    # 鍵盤監聽
    def wait_for_enter():
        nonlocal running
        try:
            input()
            trigger_stop("Enter Key")
        except Exception:
            pass

    t_input = threading.Thread(target=wait_for_enter, daemon=True)
    t_input.start()

    # 語音監聽
    voice_listener = VoiceExitListener(trigger_stop)
    voice_listener.start()

    # 音訊錄製
    audio_recorder = AudioRecorder(samplerate=44100)
    audio_recorder.start()

    frame_count = 0
    start_time = time.time()
    frame_interval = 1.0 / target_fps

    try:
        while running:
            loop_start = time.time()
            ensure_desktop()
            img = ImageGrab.grab()
            frame = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

            elapsed = int(time.time() - start_time)
            m, s = divmod(elapsed, 60)
            rec_text = f"REC {m:02d}:{s:02d} (含影音)"
            
            # 閃爍紅點
            if int(time.time() * 2) % 2 == 0:
                cv2.circle(frame, (35, 35), 10, (0, 0, 255), -1)
            cv2.putText(frame, rec_text, (55, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2)
            cv2.putText(frame, "[Enter] 或 說「關閉程式」停止", (55, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 220, 255), 1)

            writer.write(frame)
            frame_count += 1

            took = time.time() - loop_start
            wait_time = max(0.001, frame_interval - took)
            time.sleep(wait_time)

    except KeyboardInterrupt:
        pass
    finally:
        voice_listener.stop()
        writer.release()
        audio_saved = audio_recorder.stop(temp_a)
        total_time = time.time() - start_time

        print("\n" + "=" * 70)
        print("   ⏳ 正在封裝高畫質影音 MP4 檔案 (FFmpeg Muxing)...")

        # 呼叫 FFmpeg 合併影音
        mux_success = False
        if audio_saved and os.path.exists(temp_a):
            cmd = [
                'ffmpeg', '-y',
                '-i', temp_v,
                '-i', temp_a,
                '-c:v', 'copy',
                '-c:a', 'aac',
                '-b:a', '192k',
                '-movflags', '+faststart',
                final_mp4
            ]
            try:
                res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if res.returncode == 0 and os.path.exists(final_mp4):
                    mux_success = True
                    try:
                        os.remove(temp_v)
                        os.remove(temp_a)
                    except Exception:
                        pass
            except Exception as e:
                print(f"[FFmpeg 警告] 合流異常: {e}")

        if not mux_success:
            if os.path.exists(temp_v):
                if os.path.exists(final_mp4):
                    os.remove(final_mp4)
                os.rename(temp_v, final_mp4)

        print("   ✅ 錄影已圓滿完成 (包含完整畫面與聲音)！")
        print(f"   總時長: {total_time:.1f} 秒 | 總影格: {frame_count} 幀")
        print(f"   檔案位置: {final_mp4}")
        if os.path.exists(final_mp4):
            print(f"   檔案大小: {os.path.getsize(final_mp4):,} 位元組")
        
        if any(k in close_reason for k in ['關閉程式', '結束程式', '退出']):
            print("[系統] 正在同步關閉 AirTouch 輔助程式視窗...")
            if HAS_WIN32:
                try:
                    import win32con
                    hwnd = win32gui.FindWindow(None, "AirTouch Gesture Remote")
                    if hwnd:
                        win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                        print("[系統] 已向 AirTouch 發送關閉訊號！")
                except Exception:
                    pass

        print("=" * 70)
        try:
            winsound.Beep(1200, 100)
            winsound.Beep(1600, 150)
        except Exception:
            pass

if __name__ == "__main__":
    main()
