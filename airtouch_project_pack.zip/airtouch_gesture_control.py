# -*- coding: utf-8 -*-
import sys
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

"""
專題 12：AirTouch 無接觸手勢智慧遙控 (科幻懸浮透明・教材錄影旗艦版)
=============================================================
核心功能：
1. 🖐️ 手掌張開懸停 0.4s   -> 播放 / 暫停 (YouTube / 多媒體)
2. 👉 食指朝右停留 0.3s   -> 快轉 10 秒 / 簡報下一頁 ('l' + Right)
3. 👈 食指朝左停留 0.3s   -> 倒退 10 秒 / 簡報上一頁 ('j' + Left)
4. ✌️ 剪刀手 / 勝利手勢   -> 隔空強制略過廣告 (穿透置頂並秒按「略過 ▶|」)
5. 👍 大拇指朝上          -> 音量增加 (+)
6. 👎 大拇指朝下          -> 音量降低 (-)
-------------------------------------------------------------
🎥 教材影片錄製功能：
• [R] 鍵：隨開隨錄！一鍵啟動/停止「鏡頭手勢 + AI骨架 + HUD儀表」高畫質 MP4 錄影
  (錄影中畫面上方會亮起紅燈 ● REC [00:15]，停止時自動存入 recordings/ 資料夾)
-------------------------------------------------------------
視窗特效與快捷鍵：
• 【懸浮透明 HUD】：視窗預設永遠置頂在所有應用程式上方，並具備 75% 科幻透明感！
• [T] 鍵：切換視窗透明度 (75% 半透明 ➔ 55% 高度透視 ➔ 100% 完全不透明)
• [O] 鍵：切換視窗「永遠置頂」開關 (ON / OFF)
• [P] 鍵：切換「右上角迷你畫中畫 (Mini PiP)」精巧模式
• [Q] 或 [S] 鍵：一鍵強制略過 YouTube 廣告
• [A] 鍵：切換背景「廣告自動跳過」守護 (ON / OFF)
• [M] 鍵：切換實體鍵盤模擬 (ON / OFF)
• [ESC] 鍵：退出程式
"""

import time
import math
import collections
import ctypes
import winsound
import threading
import re
import numpy as np
import cv2
import pyautogui
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
from PIL import Image, ImageDraw, ImageFont, ImageGrab
import os
import subprocess

try:
    import win32api
    import win32con
    import win32gui
    import win32process
    import win32service
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False

_HWINSTA = None
_HDESK = None

def ensure_desktop():
    global _HWINSTA, _HDESK
    if HAS_WIN32:
        try:
            if _HWINSTA is None:
                _HWINSTA = win32service.OpenWindowStation('winsta0', False, 0x02000000)
                _HWINSTA.SetProcessWindowStation()
            if _HDESK is None:
                _HDESK = win32service.OpenDesktop('default', 0, False, 0x02000000)
            _HDESK.SetThreadDesktop()
        except Exception:
            pass

ensure_desktop()



try:
    import sounddevice as sd
    import soundfile as sf
    HAS_AUDIO = True
except ImportError:
    HAS_AUDIO = False

try:
    import speech_recognition as sr
    HAS_SR = True
except ImportError:
    HAS_SR = False


try:
    from auto_skip_ad import AdSkipperEngine
    HAS_AD_SKIPPER = True
except ImportError:
    try:
        from .auto_skip_ad import AdSkipperEngine
        HAS_AD_SKIPPER = True
    except Exception:
        HAS_AD_SKIPPER = False

pyautogui.FAILSAFE = False

VK_MEDIA_PLAY_PAUSE = 0xB3
VK_VOLUME_DOWN = 0xAE
VK_VOLUME_UP = 0xAF
VK_VOLUME_MUTE = 0xAD

FONT_PATH = r"C:\Windows\Fonts\msjh.ttc"
if not os.path.exists(FONT_PATH):
    FONT_PATH = r"C:\Windows\Fonts\simhei.ttf"

def draw_chinese_text(img, text, pos, font_size=22, color=(255, 255, 255)):
    try:
        font = ImageFont.truetype(FONT_PATH, font_size)
        img_pil = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(img_pil)
        draw.text(pos, text, font=font, fill=color)
        return cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    except Exception:
        cv2.putText(img, text, pos, cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        return img

HAND_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),
    (0, 5), (5, 6), (6, 7), (7, 8),
    (5, 9), (9, 10), (10, 11), (11, 12),
    (9, 13), (13, 14), (14, 15), (15, 16),
    (13, 17), (17, 18), (18, 19), (19, 20),
    (0, 17)
]

class FloatingWindowManager:
    """Windows 原生視窗置頂、透明度與畫中畫管理器"""
    def __init__(self, window_name="AirTouch Gesture Remote"):
        self.window_name = window_name
        self.hwnd = None
        self.topmost = True
        self.alpha_levels = [190, 140, 255]
        self.alpha_labels = ["75% 半透明", "55% 透視", "100% 不透明"]
        self.alpha_idx = 0
        self.pip_mode = False
        self.orig_rect = None

    def find_and_setup(self):
        if not HAS_WIN32:
            return False
        self.hwnd = win32gui.FindWindow(None, self.window_name)
        if self.hwnd:
            self.orig_rect = win32gui.GetWindowRect(self.hwnd)
            self.apply_style()
            return True
        return False

    def apply_style(self):
        if not HAS_WIN32 or not self.hwnd:
            return
        try:
            top_flag = win32con.HWND_TOPMOST if self.topmost else win32con.HWND_NOTOPMOST
            win32gui.SetWindowPos(self.hwnd, top_flag, 0, 0, 0, 0,
                                  win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_SHOWWINDOW)
            style = win32gui.GetWindowLong(self.hwnd, win32con.GWL_EXSTYLE)
            win32gui.SetWindowLong(self.hwnd, win32con.GWL_EXSTYLE, style | win32con.WS_EX_LAYERED)
            alpha_val = self.alpha_levels[self.alpha_idx]
            ctypes.windll.user32.SetLayeredWindowAttributes(self.hwnd, 0, alpha_val, 2)
        except Exception:
            pass

    def cycle_transparency(self):
        self.alpha_idx = (self.alpha_idx + 1) % len(self.alpha_levels)
        self.apply_style()
        return self.alpha_labels[self.alpha_idx]

    def toggle_topmost(self):
        self.topmost = not self.topmost
        self.apply_style()
        return "開啟 (ON)" if self.topmost else "關閉 (OFF)"

    def toggle_pip(self):
        if not HAS_WIN32 or not self.hwnd:
            return "不支援"
        self.pip_mode = not self.pip_mode
        try:
            if self.pip_mode:
                win32gui.SetWindowPos(self.hwnd, win32con.HWND_TOPMOST, 1920 - 410, 30, 380, 285, win32con.SWP_SHOWWINDOW)
                return "迷你畫中畫 (Mini PiP)"
            else:
                win32gui.SetWindowPos(self.hwnd, win32con.HWND_TOPMOST, 1220, 100, 660, 520, win32con.SWP_SHOWWINDOW)
                return "標準懸浮視窗"
        except Exception:
            return "切換完成"




class FullScreenAVRecorder:
    """
    全螢幕高畫質影音錄影引擎 (Full Desktop Screen + Audio Recorder)
    --------------------------------------------------------------
    • 錄製整台電腦螢幕 (1920x1080)：完整包含 YouTube 播放、廣告略過與懸浮 AirTouch 視窗。
    • 同步收音 (Audio)：背景平行錄製麥克風與環境音效。
    • 即時紅燈指示：錄製畫面上方顯示 ● REC MM:SS (全螢幕影音錄影中)。
    • 自動 FFmpeg 封裝：結束時自動輸出標準 H.264/AAC MP4，存於 recordings/。
    """
    def __init__(self, target_fps=20.0):
        self.target_fps = target_fps
        self.recording = False
        self.thread = None
        self.audio_frames = []
        self.audio_stream = None
        self.writer = None
        self.start_time = 0.0
        self.current_mp4 = ""
        self.temp_v = ""
        self.temp_a = ""
        self.screen_w = 1920
        self.screen_h = 1080

    def start(self):
        if self.recording:
            return
        ensure_desktop()
        rec_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "recordings")
        os.makedirs(rec_dir, exist_ok=True)

        now_str = time.strftime("%Y%m%d_%H%M%S")
        self.current_mp4 = os.path.join(rec_dir, f"screen_demo_{now_str}.mp4")
        self.temp_v = os.path.join(rec_dir, f"temp_screen_v_{now_str}.mp4")
        self.temp_a = os.path.join(rec_dir, f"temp_screen_a_{now_str}.wav")

        try:
            img = ImageGrab.grab(all_screens=True)
            self.screen_w, self.screen_h = img.size
        except Exception:
            self.screen_w, self.screen_h = 1920, 1080

        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        self.writer = cv2.VideoWriter(self.temp_v, fourcc, self.target_fps, (self.screen_w, self.screen_h))
        self.recording = True
        self.start_time = time.time()

        # 音訊錄製
        self.audio_frames = []
        if HAS_AUDIO:
            def audio_cb(indata, frames, time_info, status):
                if self.recording:
                    self.audio_frames.append(indata.copy())
            try:
                self.audio_stream = sd.InputStream(samplerate=44100, channels=1, callback=audio_cb)
                self.audio_stream.start()
            except Exception as e:
                print(f"[全螢幕錄影] 音訊啟動失敗: {e}")
                self.audio_stream = None

        # 啟動螢幕擷取背景執行緒
        self.thread = threading.Thread(target=self._capture_loop, daemon=True)
        self.thread.start()
        print(f"\n[全螢幕錄影] 🔴 開始錄製整台電腦螢幕 ({self.screen_w}x{self.screen_h})！")
        print(f"[全螢幕錄影] 存檔路徑: {self.current_mp4}")

    def _capture_loop(self):
        ensure_desktop()
        interval = 1.0 / self.target_fps
        while self.recording:
            t0 = time.time()
            try:
                img = ImageGrab.grab(all_screens=True)
                frame = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
                elapsed = int(time.time() - self.start_time)
                m, s = divmod(elapsed, 60)
                rec_text = f"REC {m:02d}:{s:02d} (全螢幕影音錄影)"

                # 閃爍紅點指示器
                if int(time.time() * 2) % 2 == 0:
                    cv2.circle(frame, (35, 35), 10, (0, 0, 255), -1)
                cv2.putText(frame, rec_text, (55, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2)
                cv2.putText(frame, "[R] 或 [F9] 或 說「關閉程式」停止", (55, 68), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 220, 255), 1)

                if self.writer:
                    self.writer.write(frame)
            except Exception:
                time.sleep(0.02)
            took = time.time() - t0
            wait = max(0.001, interval - took)
            time.sleep(wait)

    def stop(self):
        if not self.recording:
            return "", 0
        self.recording = False
        if self.thread:
            self.thread.join(timeout=2.5)
            self.thread = None

        if self.writer:
            self.writer.release()
            self.writer = None

        # 停止音訊
        audio_saved = False
        if self.audio_stream:
            try:
                self.audio_stream.stop()
                self.audio_stream.close()
            except Exception:
                pass
            self.audio_stream = None

        if self.audio_frames and HAS_AUDIO:
            try:
                audio_data = np.concatenate(self.audio_frames, axis=0)
                sf.write(self.temp_a, audio_data, 44100)
                audio_saved = True
            except Exception as e:
                print(f"[全螢幕錄影] 音訊儲存異常: {e}")

        duration = int(time.time() - self.start_time)

        # 呼叫 FFmpeg 合併影音
        mux_success = False
        if audio_saved and os.path.exists(self.temp_a) and os.path.exists(self.temp_v):
            cmd = [
                'ffmpeg', '-y',
                '-i', self.temp_v,
                '-i', self.temp_a,
                '-c:v', 'copy',
                '-c:a', 'aac',
                '-b:a', '192k',
                '-movflags', '+faststart',
                self.current_mp4
            ]
            try:
                res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if res.returncode == 0 and os.path.exists(self.current_mp4):
                    mux_success = True
                    try:
                        os.remove(self.temp_v)
                        os.remove(self.temp_a)
                    except Exception:
                        pass
            except Exception:
                pass

        if not mux_success:
            if os.path.exists(self.temp_v):
                if os.path.exists(self.current_mp4):
                    try:
                        os.remove(self.current_mp4)
                    except Exception:
                        pass
                try:
                    os.rename(self.temp_v, self.current_mp4)
                except Exception:
                    pass

        print(f"\n[全螢幕錄影] ✅ 全螢幕錄影圓滿完成！時長: {duration}秒")
        print(f"[全螢幕錄影] 檔案位置: {self.current_mp4}")
        if os.path.exists(self.current_mp4):
            print(f"[全螢幕錄影] 檔案大小: {os.path.getsize(self.current_mp4):,} 位元組")
        return self.current_mp4, duration

CN_NUM = {
    '零': 0, '一': 1, '二': 2, '兩': 2, '三': 3, '四': 4,
    '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '十': 10
}

def parse_cn_number(s):
    if not s:
        return 0
    if s == '十':
        return 10
    if s.startswith('十'):
        return 10 + CN_NUM.get(s[1], 0)
    if '十' in s:
        parts = s.split('十')
        tens = CN_NUM.get(parts[0], 1)
        ones = CN_NUM.get(parts[1], 0) if len(parts) > 1 and parts[1] else 0
        return tens * 10 + ones
    if len(s) == 1:
        return CN_NUM.get(s, 0)
    return 0

def extract_seek_seconds(text):
    m_min = re.search(r'(\d+|[一二兩三四五六七八九十]+)\s*(?:個?分鐘|分)', text)
    sec_from_min = 0
    if m_min:
        num_str = m_min.group(1)
        if num_str.isdigit():
            sec_from_min = int(num_str) * 60
        else:
            sec_from_min = parse_cn_number(num_str) * 60
    elif '半分鐘' in text or '半分' in text:
        sec_from_min = 30

    m_sec = re.search(r'(\d+|[一二兩三四五六七八九十]+)\s*秒', text)
    sec_val = 0
    if m_sec:
        num_str = m_sec.group(1)
        if num_str.isdigit():
            sec_val = int(num_str)
        else:
            sec_val = parse_cn_number(num_str)

    total_sec = sec_from_min + sec_val
    if total_sec == 0:
        m_raw = re.search(r'(?:快轉|前進|後退|倒退|倒轉|往後|往前)?\s*(\d+)', text)
        if m_raw:
            total_sec = int(m_raw.group(1))

    return total_sec if total_sec > 0 else 10

import webbrowser
import urllib.request
import urllib.parse

def get_first_yt_video(query):
    encoded = urllib.parse.quote(query)
    url = f'https://www.youtube.com/results?search_query={encoded}'
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            html = response.read().decode('utf-8', errors='ignore')
            video_ids = re.findall(r'"videoId":"([a-zA-Z0-9_-]{11})"', html)
            if video_ids:
                return f'https://www.youtube.com/watch?v={video_ids[0]}'
            video_ids2 = re.findall(r'/watch\?v=([a-zA-Z0-9_-]{11})', html)
            if video_ids2:
                return f'https://www.youtube.com/watch?v={video_ids2[0]}'
    except Exception as e:
        print(f"[語音點歌] YouTube 搜尋抓取異常: {e}")
    return f'https://www.youtube.com/results?search_query={encoded}'

def is_close_media_command(text):
    text_clean = text.strip().lower()
    close_media_keywords = [
        '關閉這首影音', '關閉這首', '關閉這首歌', '關閉影片', '關閉音樂', '關閉歌曲',
        '關掉這首影音', '關掉這首', '關掉這首歌', '關掉影片', '關掉音樂', '關掉歌曲',
        '關閉分頁', '關掉分頁', '不要聽了', '別放了', '不要播了', '別播了', '停止影音',
        'close video', 'close media', 'close song'
    ]
    if any(sw in text_clean for sw in ['換播', '換聽', '換成', '換一首', '換歌曲', '換開啟']):
        return False
    return any(k in text_clean for k in close_media_keywords)

def extract_music_query(text):
    text_clean = text.strip()
    if text_clean in ['播放', '開始播放', '繼續播放', '播放影片', '暫停', '暫停播放', '停止播放', '停止']:
        return None
        
    patterns = [
        r'(?:關閉這首換播|關閉這首換聽|關閉這首換成|關閉這首換開啟|關閉這首換|關掉這首換播|關掉這首換聽|關閉換播|關閉換聽)\s*(.+)',
        r'(?:換開啟|換聽|換播|換成|換一首|換一首歌|換首|換歌)\s*(.+)',
        r'(?:我想聽|想聽|聽一下|聽聽)\s*(.+)',
        r'(?:點播|點歌|來一首|播一首|放一首)\s*(.+)',
        r'(?:搜尋歌曲|搜尋音樂|搜尋影片|搜尋|查詢|找一下|找)\s*(.+)',
        r'(?:幫我播放|幫我放|播放|播|放)\s*(.+)',
        r'play\s*(.+)',
        r'search\s*(.+)'
    ]
    
    for pat in patterns:
        m = re.match(pat, text_clean, re.IGNORECASE)
        if m:
            query = m.group(1).strip()
            query = re.sub(r'(?:的歌|的歌曲|的mv|mv|歌曲|音樂|一下)$', '', query, flags=re.IGNORECASE).strip()
            if query and query not in ['影片', '音樂', '歌']:
                return query
                
    return None

class VoiceCommandListener:
    """
    語音指令監聽器 (Voice Command Remote Controller)
    -------------------------------------------------
    支援完整自然語言語音指令：
    • 播放 / 暫停：說「播放」、「暫停」、「繼續播放」
    • 音量控制：說「大聲一點 / 增加音量」、「小聲一點 / 降低音量」、「靜音」
    • 進度跳轉：說「快轉 / 前進 10 秒」、「倒退 / 後退 10 秒」
    • 去除廣告：說「跳過廣告 / 去廣告」
    • 視窗模式：說「全螢幕 / 全屏」
    • 全螢幕錄影：說「開始錄影」、「停止錄影」
    • 安全退出：說「關閉程式 / 結束程式」
    """
    def __init__(self, on_exit_callback, on_record_callback=None, on_action_callback=None):
        self.on_action_callback = on_action_callback
        self.on_exit_callback = on_exit_callback
        self.on_record_callback = on_record_callback
        self.running = False
        self.r = sr.Recognizer() if HAS_SR else None
        self.audio_buf = collections.deque(maxlen=16000 * 2) # 最近 2 秒音訊
        self.stream = None

    def start(self):
        if not HAS_AUDIO or not HAS_SR or not self.r:
            return
        self.running = True
        def callback(indata, frames, time_info, status):
            if self.running:
                self.audio_buf.extend(indata[:, 0].copy())
        try:
            self.stream = sd.InputStream(samplerate=16000, channels=1, dtype='int16', callback=callback)
            self.stream.start()
            print("[語音系統] 🎙️ 語音辨識已就緒！隨時說出「播放」、「暫停」、「大聲一點」、「快轉」、「跳過廣告」、「開始錄影」或「關閉程式」。")
        except Exception as e:
            print(f"[語音系統] 串流啟動失敗: {e}")
            return

        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if self.stream:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None

    def _worker(self):
        last_check = time.time()
        while self.running:
            time.sleep(0.25)
            if len(self.audio_buf) < 16000:
                continue
            data = np.array(self.audio_buf, dtype='int16')
            rms = np.sqrt(np.mean(data.astype(np.float32)**2))
            if rms > 130: # 偵測到人聲
                now = time.time()
                if now - last_check < 0.6:
                    continue
                last_check = now
                ad = sr.AudioData(data.tobytes(), 16000, 2)
                try:
                    # 辨識前先清空緩衝區，防止同一音訊被重複判斷
                    self.audio_buf.clear()
                    text = self.r.recognize_google(ad, language='zh-TW')
                    text_clean = text.strip().lower()
                    print(f"[語音指令] 🎙️ 聽取到: '{text}'")

                    # 1. 關閉整個輔助程式 (明確說「關閉程式」、「結束程式」)
                    if any(k in text_clean for k in ['關閉程式', '結束程式', '退出程式', '關閉系統', '退出系統', '停止程式']):
                        print("[語音指令] 🎯 辨識到「關閉程式」！正在完全關閉整個輔助程式...")
                        try:
                            winsound.Beep(900, 150)
                            winsound.Beep(600, 250)
                        except Exception:
                            pass
                        self.on_exit_callback(text)
                        break

                    # 2. 語音點歌 / 換開啟另一首 (例：「我想聽周杰倫」、「換聽告五人」、「關閉這首換播稻香」)
                    elif extract_music_query(text):
                        song_query = extract_music_query(text)
                        print(f"[語音指令] 🎯 辨識到換歌/點歌「{song_query}」！正在關閉舊曲換開新曲...")
                        if self.on_action_callback:
                            self.on_action_callback(('song_search', song_query))

                    # 3. 關閉當前影音分頁 (例：「關閉這首影音」、「關閉這首」、「關閉影片」、「關掉音樂」)
                    elif is_close_media_command(text):
                        print("[語音指令] 🎯 辨識到「關閉這首影音」！正在關閉目前播放分頁...")
                        if self.on_action_callback:
                            self.on_action_callback('close_media')

                    # 2. 全螢幕錄影控制 (優先於通用播放/停止)
                    elif any(k in text_clean for k in ['開始錄影', '啟動錄影', '開啟錄影', '錄影開始', 'start recording', 'record']):
                        print("[語音指令] 🎯 辨識到「開始錄影」！")
                        if self.on_record_callback:
                            self.on_record_callback(True)

                    elif any(k in text_clean for k in ['停止錄影', '結束錄影', '關閉錄影', '錄影結束', 'stop recording']):
                        print("[語音指令] 🎯 辨識到「停止錄影」！")
                        if self.on_record_callback:
                            self.on_record_callback(False)

                    # 3. 開啟 YouTube 網站 (例：「開啟YT網站」、「開啟YT」、「打開YouTube」、「打開YT」)
                    elif any(k in text_clean for k in ['開啟yt網站', '開啟yt', '打開yt網站', '打開yt', '開yt', '進yt', '進入yt', '開啟youtube', '打開youtube', '開youtube', '進入youtube', 'open youtube']):
                        print("[語音指令] 🎯 辨識到「開啟YT網站」！正在打開瀏覽器...")
                        if self.on_action_callback:
                            self.on_action_callback('open_youtube')

                    # 4. 去除 / 跳過廣告
                    elif any(k in text_clean for k in ['跳過廣告', '略過廣告', '去除廣告', '去廣告', '跳廣告', 'skip ad']):
                        print("[語音指令] 🎯 辨識到「跳過廣告」！")
                        if self.on_action_callback:
                            self.on_action_callback('skip_ad')

                    # 4. 音量控制 (大聲、小聲、靜音)
                    elif any(k in text_clean for k in ['提高音量', '增加音量', '音量提高', '音量增加', '音量調高', '音量調大', '音量大聲', '音量放大', '大一點', '音量大', '音量加', '大聲一點', '大聲些', '大聲', 'volume up', 'louder']):
                        print("[語音指令] 🎯 辨識到「音量大聲」！")
                        if self.on_action_callback:
                            self.on_action_callback('volume_up')

                    elif any(k in text_clean for k in ['降低音量', '減少音量', '音量降低', '音量減少', '音量調低', '音量調小', '音量小聲', '音量縮小', '小一點', '音量小', '音量減', '小聲一點', '小聲些', '小聲', 'volume down', 'quieter']):
                        print("[語音指令] 🎯 辨識到「音量小聲」！")
                        if self.on_action_callback:
                            self.on_action_callback('volume_down')

                    elif any(k in text_clean for k in ['系統靜音', '取消靜音', '解除靜音', '靜音', '閉嘴', 'mute', 'unmute']):
                        print("[語音指令] 🎯 辨識到「靜音切換」！")
                        if self.on_action_callback:
                            self.on_action_callback('mute')

                    # 5. 任意秒數快轉與倒退跳轉 (例:「往前快轉20秒」、「往後快轉20秒」、「快轉30秒」、「倒退15秒」)
                    elif ('秒' in text_clean and any(c in text_clean for c in '0123456789一二兩三四五六七八九十')) or any(k in text_clean for k in ['快轉', '倒轉', '前進', '後退', '倒退', '往前', '往後', 'forward', 'rewind', 'skip']):
                        is_backward = any(k in text_clean for k in ['後', '倒', 'back', 'rewind', 'prev'])
                        direction = 'backward' if is_backward else 'forward'
                        seconds = extract_seek_seconds(text_clean)
                        action_name = "往後倒退" if is_backward else "往前快轉"
                        print(f"[語音指令] 🎯 辨識到「{action_name} {seconds} 秒」！")
                        if self.on_action_callback:
                            self.on_action_callback(('seek', direction, seconds))

                    elif any(k in text_clean for k in ['下一首', '下一個', '下一部', '下一集', 'next']):
                        print("[語音指令] 🎯 辨識到「下一首」！")
                        if self.on_action_callback:
                            self.on_action_callback(('seek', 'forward', 10))

                    elif any(k in text_clean for k in ['上一首', '上一個', '上一部', '上一集', 'previous']):
                        print("[語音指令] 🎯 辨識到「上一首」！")
                        if self.on_action_callback:
                            self.on_action_callback(('seek', 'backward', 10))

                    # 6. 全螢幕
                    elif any(k in text_clean for k in ['全螢幕', '全屏', '放大全螢幕', '劇院模式', 'fullscreen']):
                        print("[語音指令] 🎯 辨識到「全螢幕」！")
                        if self.on_action_callback:
                            self.on_action_callback('fullscreen')



                    # 8. 暫停播放 (排除點歌後的標準指令)
                    elif any(k in text_clean for k in ['暫停播放', '停止播放', '先暫停', '暫停', 'pause', 'hold']):
                        print("[語音指令] 🎯 辨識到「暫停播放」！")
                        if self.on_action_callback:
                            self.on_action_callback('pause')

                    # 9. 繼續播放 / 播放 (排除點歌後的標準指令)
                    elif any(k in text_clean for k in ['繼續播放', '開始播放', '播放影片', '繼續', '播放', 'play', 'resume']):
                        print("[語音指令] 🎯 辨識到「繼續播放」！")
                        if self.on_action_callback:
                            self.on_action_callback('play')

                    # 10. 通用單字退出
                    elif any(k in text_clean for k in ['關閉', '退出', '結束', 'close', 'exit']):
                        print("[語音指令] 🎯 辨識到退出指令！正在完全關閉整個輔助程式...")
                        self.on_exit_callback(text)
                        break



                except (sr.UnknownValueError, sr.RequestError):
                    pass

class AirTouchController:
    def __init__(self, model_path="hand_landmarker.task"):
        if not os.path.exists(model_path):
            alt_path = os.path.join(os.path.dirname(__file__), "hand_landmarker.task")
            if os.path.exists(alt_path):
                model_path = alt_path
            else:
                raise FileNotFoundError(f"找不到模型檔 {model_path}，請確認檔案路徑！")

        base_options = python.BaseOptions(model_asset_path=model_path)
        options = vision.HandLandmarkerOptions(
            base_options=base_options,
            running_mode=vision.RunningMode.IMAGE,
            num_hands=1,
            min_hand_detection_confidence=0.55,
            min_hand_presence_confidence=0.55,
            min_tracking_confidence=0.55
        )
        self.detector = vision.HandLandmarker.create_from_options(options)

        self.index_trail = collections.deque(maxlen=12)
        self.hover_counter = 0
        # 手勢防誤觸蓄力計數器 (精準校準防誤觸機制)
        self.hover_counter = 0
        self.hover_required_frames = 15  # 手掌張開需穩定懸停 ~0.50 秒 (避免動作過渡期誤判)
        self.last_palm_pos = None

        self.peace_counter = 0
        self.peace_required_frames = 10  # ✌️ 剪刀手略過廣告需穩定維持 ~0.33 秒 (徹底杜絕手勢變換時誤判！)

        self.point_right_counter = 0
        self.point_left_counter = 0
        self.point_required_frames = 7  # 👉 食指指向需穩定維持 ~0.40 秒 (防止無意揮動時觸發)

        self.thumb_up_counter = 0
        self.thumb_down_counter = 0
        self.thumb_required_frames = 7   # 👍 / 👎 拇指需穩定維持 ~0.23 秒

        self.pinch_counter = 0
        self.pinch_required_frames = 8   # 👌 捏合需維持 ~0.26 秒
        
        self.last_action_time = 0.0
        self.cooldown_seconds = 0.9
        self.volume_last_time = 0.0
        self.volume_cooldown = 0.35

        self.simulate_os_keys = True
        self.last_triggered_text = "等待手勢指令..."
        self.trigger_toast_until = 0.0
        self.swipe_dx_display = 0.0

        # 廣告自動跳過
        self.ad_skipper = None
        self.auto_ad_skip_enabled = True
        self.ad_skipped_count = 0
        self.ad_skipped_toast_until = 0.0

        if HAS_AD_SKIPPER:
            try:
                self.ad_skipper = AdSkipperEngine(check_interval=0.6, on_skipped_callback=self.on_ad_skipped)
                self.ad_skipper.start()
            except Exception as e:
                print(f"[AirTouch] 廣告略過模組啟動異常: {e}")

        # 語音指令退出開關
        self.request_exit = False

        # 全螢幕桌面影音錄製引擎 (Full-Screen Desktop Recorder)
        self.screen_recorder = FullScreenAVRecorder(target_fps=20.0)
        self.is_recording = False
        self.record_start_time = 0.0
        self.video_writer = None
        self.current_record_path = ""

    def toggle_recording(self, *args, force_state=None, **kwargs):
        """[R] 鍵 / [F9] 鍵 / 語音啟動或停止【整台電腦螢幕】高畫質影音錄影 (包含背景 YouTube 與懸浮鏡頭)"""
        try:
            if force_state is not None:
                target = force_state
            else:
                target = not self.is_recording

            if target and not self.is_recording:
                self.screen_recorder.start()
                self.is_recording = True
                self.record_start_time = time.time()
                self.current_record_path = self.screen_recorder.current_mp4
                self.last_triggered_text = "【🎥 全螢幕錄影開始】錄製整台電腦螢幕 (含 YouTube 與聲音)..."
                self.trigger_toast_until = time.time() + 2.5
                try:
                    winsound.Beep(1400, 80)
                    winsound.Beep(1800, 120)
                except Exception:
                    pass
                return True
            elif not target and self.is_recording:
                self.is_recording = False
                out_file, duration = self.screen_recorder.stop()
                self.current_record_path = out_file
                fn = os.path.basename(out_file) if out_file else "screen_demo.mp4"
                self.last_triggered_text = f"【💾 全螢幕錄影完成】已儲存: {fn} ({duration}秒)"
                self.trigger_toast_until = time.time() + 3.5
                try:
                    winsound.Beep(1800, 80)
                    winsound.Beep(1300, 140)
                except Exception:
                    pass
                return False
        except Exception as e:
            print(f"[全螢幕錄影] 錄影切換失敗: {e}")
            self.last_triggered_text = f"【❌ 錄影異常】{e}"
            self.trigger_toast_until = time.time() + 3.0
            return False

    def on_ad_skipped(self, label, coords):
        now = time.time()
        if now < self.ad_skipped_toast_until:
            return
        self.ad_skipped_count += 1
        self.last_triggered_text = f"【🛡️ 廣告略過】已成功按掉「{label}」！"
        self.trigger_toast_until = now + 2.0
        self.ad_skipped_toast_until = now + 3.5

    def toggle_ad_skipper(self):
        self.auto_ad_skip_enabled = not self.auto_ad_skip_enabled
        if self.ad_skipper:
            self.ad_skipper.enabled = self.auto_ad_skip_enabled
        state = "開啟 [ON]" if self.auto_ad_skip_enabled else "關閉 [OFF]"
        self.last_triggered_text = f"【設定】廣告自動跳過: {state}"
        self.trigger_toast_until = time.time() + 1.5
        try:
            winsound.Beep(1000, 60)
        except Exception:
            pass

    def trigger_force_skip_ad(self, custom_text=None):
        now = time.time()
        self.last_action_time = now
        self.cooldown_seconds = 1.0
        self.last_triggered_text = custom_text or "【強制略過】⚡ 穿透喚醒 YouTube 並秒按「略過」！"
        self.trigger_toast_until = now + 2.0
        self.hover_counter = 0
        self.index_trail.clear()

        if self.ad_skipper:
            threading.Thread(target=self.ad_skipper.force_skip_now, daemon=True).start()
        else:
            try:
                pyautogui.press('l')
            except Exception:
                pass

        try:
            winsound.Beep(1300, 70)
            winsound.Beep(1700, 110)
        except Exception:
            pass

    def stop(self):
        if self.is_recording:
            try:
                self.screen_recorder.stop()
            except Exception:
                pass
            self.is_recording = False
        if self.ad_skipper:
            self.ad_skipper.stop()

    def _get_youtube_hwnd(self):
        if not HAS_WIN32:
            return None
        ensure_desktop()
        yt_hwnd = None
        def enum_cb(h, _):
            if win32gui.IsWindowVisible(h):
                t = win32gui.GetWindowText(h).lower()
                if 'airtouch' not in t and any(b in t for b in ['youtube', 'chrome', 'edge', 'brave', 'firefox']):
                    nonlocal yt_hwnd
                    if 'youtube' in t:
                        yt_hwnd = h
                    elif yt_hwnd is None:
                        yt_hwnd = h
        try:
            win32gui.EnumWindows(enum_cb, None)
        except Exception:
            pass
        return yt_hwnd

    def _focus_window(self, hwnd):
        if not HAS_WIN32 or not hwnd:
            return
        ensure_desktop()
        try:
            if win32gui.IsIconic(hwnd):
                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            fore = win32gui.GetForegroundWindow()
            if fore != hwnd:
                win32gui.SetForegroundWindow(hwnd)
                time.sleep(0.04)
        except Exception:
            pass

    def open_youtube_website(self, custom_text=None):
        """【語音控制】在預設瀏覽器中開啟 YouTube 官方網站首頁"""
        now = time.time()
        self.last_action_time = now
        self.last_triggered_text = custom_text or "【🌐 視窗】🚀 正在為您開啟 YouTube 網站！"
        self.trigger_toast_until = now + 3.0

        try:
            winsound.Beep(900, 80)
            winsound.Beep(1350, 120)
        except Exception:
            pass

        def worker():
            try:
                webbrowser.open("https://www.youtube.com")
                print("[語音指令] 🌐 成功在瀏覽器中開啟 YouTube 網站！")
            except Exception as e:
                print(f"[語音指令] 開啟 YouTube 網站失敗: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def close_current_media(self, custom_text=None):
        """【手勢/語音】關閉當前播放的 YouTube 影音分頁 (發送 Ctrl+W)"""
        now = time.time()
        self.last_action_time = now
        self.last_triggered_text = custom_text or "【視窗】🛑 已關閉目前影音分頁 (YouTube)"
        self.trigger_toast_until = now + 2.0
        
        yt_hwnd = self._get_youtube_hwnd()
        if yt_hwnd:
            self._focus_window(yt_hwnd)
            time.sleep(0.04)
            try:
                # 先按暫停確保聲音立刻停止
                pyautogui.press('k')
                time.sleep(0.04)
                pyautogui.hotkey('ctrl', 'w')
            except Exception:
                pass
        else:
            try:
                pyautogui.hotkey('ctrl', 'w')
            except Exception:
                pass

        try:
            winsound.Beep(650, 80)
            winsound.Beep(450, 140)
        except Exception:
            pass

    def search_and_play_song(self, query, close_current=True):
        """【語音點歌/換歌】關閉當前影音並換開啟搜尋到的新歌曲"""
        now = time.time()
        self.last_action_time = now
        self.last_triggered_text = f"【🎵 換歌】關閉目前影音，換開「{query}」..." if close_current else f"【🎵 語音點歌】搜尋「{query}」中..."
        self.trigger_toast_until = now + 4.0

        try:
            winsound.Beep(880, 80)
            winsound.Beep(1200, 120)
        except Exception:
            pass

        def worker():
            if close_current:
                yt_hwnd = self._get_youtube_hwnd()
                if yt_hwnd:
                    self._focus_window(yt_hwnd)
                    time.sleep(0.04)
                    try:
                        pyautogui.press('k')
                        time.sleep(0.04)
                        pyautogui.hotkey('ctrl', 'w')
                        time.sleep(0.12)
                    except Exception:
                        pass

            try:
                link = get_first_yt_video(query)
                print(f"[語音點歌] 🎵 成功獲取最佳曲目: {link}")
                webbrowser.open(link)
                self.last_triggered_text = f"【🎵 正在播放】{query}"
                self.trigger_toast_until = time.time() + 3.5
            except Exception as e:
                print(f"[語音點歌] 搜尋播放失敗: {e}")
                self.last_triggered_text = f"【❌ 點歌異常】{e}"
                self.trigger_toast_until = time.time() + 2.5

        threading.Thread(target=worker, daemon=True).start()

    def trigger_play_pause(self, custom_text=None):
        """【手勢/語音觸發】🖐️ 單一乾淨觸發 YouTube 播放 / 暫停 (絕不連發多鍵防互相抵消)"""
        now = time.time()
        self.last_action_time = now
        self.cooldown_seconds = 1.2
        self.last_triggered_text = custom_text or "【觸發】🖐️ 播放 / 暫停 (YouTube)"
        self.trigger_toast_until = now + 1.2
        self.hover_counter = 0
        self.index_trail.clear()

        if self.simulate_os_keys:
            yt_hwnd = self._get_youtube_hwnd()
            if yt_hwnd:
                self._focus_window(yt_hwnd)
                try:
                    pyautogui.press('k')
                except Exception:
                    pass
            else:
                try:
                    ctypes.windll.user32.keybd_event(VK_MEDIA_PLAY_PAUSE, 0, 0, 0)
                    time.sleep(0.02)
                    ctypes.windll.user32.keybd_event(VK_MEDIA_PLAY_PAUSE, 0, 2, 0)
                except Exception:
                    pass

        try:
            winsound.Beep(900, 80)
        except Exception:
            pass

    def trigger_seek(self, seconds=10, direction='forward', custom_text=None):
        """【手勢/語音觸發】精準秒數快轉或倒退 (支援 5s、10s、20s、30s... 任意秒數)"""
        now = time.time()
        self.last_action_time = now
        self.cooldown_seconds = 0.8

        # 限制在 5 秒 ~ 600 秒 (10 分鐘)
        sec = max(5, min(600, int(round(seconds / 5.0) * 5)))
        n_10 = sec // 10
        n_5 = (sec % 10) // 5

        dir_str = "⏩ 往前快轉" if direction == 'forward' else "⏪ 往後倒退"
        self.last_triggered_text = custom_text or f"【語音】{dir_str} {sec} 秒 (YouTube)"
        self.trigger_toast_until = now + 1.5
        self.index_trail.clear()
        self.hover_counter = 0

        if self.simulate_os_keys:
            yt_hwnd = self._get_youtube_hwnd()
            if yt_hwnd:
                self._focus_window(yt_hwnd)
                time.sleep(0.03)

            key_10 = 'l' if direction == 'forward' else 'j'
            key_5 = 'right' if direction == 'forward' else 'left'

            for _ in range(n_10):
                try:
                    pyautogui.press(key_10)
                    time.sleep(0.04)
                except Exception:
                    pass

            for _ in range(n_5):
                try:
                    pyautogui.press(key_5)
                    time.sleep(0.04)
                except Exception:
                    pass

        try:
            freq = 1100 if direction == 'forward' else 700
            winsound.Beep(freq, 80)
        except Exception:
            pass

    def trigger_swipe_right(self, custom_text=None):
        """【手勢/語音觸發】👉 快轉 10 秒"""
        self.point_right_counter = 0
        self.trigger_seek(10, direction='forward', custom_text=custom_text or "【快轉】👉 食指指右：快轉 10 秒")

    def trigger_swipe_left(self, custom_text=None):
        """【手勢/語音觸發】👈 倒退 10 秒"""
        self.point_left_counter = 0
        self.trigger_seek(10, direction='backward', custom_text=custom_text or "【倒退】👈 食指指左：倒退 10 秒")

    def trigger_volume_up(self, steps=1, custom_text=None):
        """【手勢/語音觸發】👍 調大系統主音量 (絕不觸碰 YouTube 內部音量滑桿)"""
        now = time.time()
        self.last_action_time = now
        self.volume_last_time = now
        self.last_triggered_text = custom_text or "【音量】👍 系統音量增加 (+)"
        self.trigger_toast_until = now + (1.2 if custom_text else 0.8)
        if self.simulate_os_keys:
            for _ in range(steps):
                try:
                    ctypes.windll.user32.keybd_event(VK_VOLUME_UP, 0, 0, 0)
                    time.sleep(0.01)
                    ctypes.windll.user32.keybd_event(VK_VOLUME_UP, 0, 2, 0)
                    time.sleep(0.01)
                except Exception:
                    try:
                        pyautogui.press('volumeup')
                    except Exception:
                        pass
        try:
            winsound.Beep(850, 50)
        except Exception:
            pass

    def trigger_volume_down(self, steps=1, custom_text=None):
        """【手勢/語音觸發】👎 調小系統主音量 (絕不觸碰 YouTube 內部音量滑桿)"""
        now = time.time()
        self.last_action_time = now
        self.volume_last_time = now
        self.last_triggered_text = custom_text or "【音量】👎 系統音量降低 (-)"
        self.trigger_toast_until = now + (1.2 if custom_text else 0.8)
        if self.simulate_os_keys:
            for _ in range(steps):
                try:
                    ctypes.windll.user32.keybd_event(VK_VOLUME_DOWN, 0, 0, 0)
                    time.sleep(0.01)
                    ctypes.windll.user32.keybd_event(VK_VOLUME_DOWN, 0, 2, 0)
                    time.sleep(0.01)
                except Exception:
                    try:
                        pyautogui.press('volumedown')
                    except Exception:
                        pass
        try:
            winsound.Beep(550, 50)
        except Exception:
            pass

    def trigger_toggle_mute(self, custom_text=None):
        """【語音觸發】🔇 切換系統主音量靜音 (絕不觸碰 YouTube 內部音量滑桿)"""
        now = time.time()
        self.last_action_time = now
        self.volume_last_time = now
        self.last_triggered_text = custom_text or "【音量】🔇 系統靜音切換"
        self.trigger_toast_until = now + 1.2
        if self.simulate_os_keys:
            try:
                ctypes.windll.user32.keybd_event(VK_VOLUME_MUTE, 0, 0, 0)
                time.sleep(0.01)
                ctypes.windll.user32.keybd_event(VK_VOLUME_MUTE, 0, 2, 0)
            except Exception:
                try:
                    pyautogui.press('volumemute')
                except Exception:
                    pass
        try:
            winsound.Beep(600, 80)
        except Exception:
            pass

    def trigger_toggle_fullscreen(self, custom_text=None):
        """【語音觸發】🖥️ 切換 YouTube 全螢幕 (發送乾淨 'f' 鍵)"""
        now = time.time()
        self.last_action_time = now
        self.last_triggered_text = custom_text or "【視窗】🖥️ YouTube 全螢幕切換"
        self.trigger_toast_until = now + 1.2
        if self.simulate_os_keys:
            yt_hwnd = self._get_youtube_hwnd()
            if yt_hwnd:
                self._focus_window(yt_hwnd)
                try:
                    pyautogui.press('f')
                except Exception:
                    pass
            else:
                try:
                    pyautogui.press('f11')
                except Exception:
                    pass
        try:
            winsound.Beep(950, 80)
        except Exception:
            pass

    def trigger_action(self, action_name, key_to_press=None, cooldown=0.8, beep_freq=650):
        now = time.time()
        self.last_action_time = now
        self.cooldown_seconds = cooldown
        self.last_triggered_text = f"【觸發】{action_name}"
        self.trigger_toast_until = now + 1.2
        self.hover_counter = 0
        self.index_trail.clear()

        if self.simulate_os_keys and key_to_press:
            try:
                pyautogui.press(key_to_press)
            except Exception:
                pass

        try:
            winsound.Beep(beep_freq, 50)
        except Exception:
            pass

    def is_extended(self, lm, tip_idx, pip_idx, wrist_idx=0, threshold=1.12):
        w = lm[wrist_idx]
        tip = lm[tip_idx]
        pip = lm[pip_idx]
        d_tip = math.hypot(tip.x - w.x, tip.y - w.y)
        d_pip = math.hypot(pip.x - w.x, pip.y - w.y)
        return d_tip > (d_pip * threshold)

    def process_frame(self, frame, win_mgr):
        h, w, _ = frame.shape
        now = time.time()

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
        detection_result = self.detector.detect(mp_image)

        is_cooling_down = (now - self.last_action_time) < self.cooldown_seconds
        gesture_detected = "無手部動態"
        self.swipe_dx_display = 0.0

        if detection_result.hand_landmarks:
            landmarks = detection_result.hand_landmarks[0]
            pts = [(int(lm.x * w), int(lm.y * h)) for lm in landmarks]

            for (p1_idx, p2_idx) in HAND_CONNECTIONS:
                cv2.line(frame, pts[p1_idx], pts[p2_idx], (255, 200, 0), 2, cv2.LINE_AA)
            for i, (px, py) in enumerate(pts):
                if i in [4, 8, 12, 16, 20]:
                    cv2.circle(frame, (px, py), 7, (0, 255, 255), -1, cv2.LINE_AA)
                else:
                    cv2.circle(frame, (px, py), 4, (0, 255, 128), -1, cv2.LINE_AA)

            is_index_extended = self.is_extended(landmarks, 8, 6, 0, threshold=1.15)
            is_middle_extended = self.is_extended(landmarks, 12, 10, 0, threshold=1.12)
            is_ring_extended = self.is_extended(landmarks, 16, 14, 0, threshold=1.12)
            is_pinky_extended = self.is_extended(landmarks, 20, 18, 0, threshold=1.12)

            extended_count = sum([is_index_extended, is_middle_extended, is_ring_extended, is_pinky_extended])

            thumb_vec_y = landmarks[4].y - landmarks[2].y
            is_thumb_up = (thumb_vec_y < -0.06) and (landmarks[4].y < landmarks[8].y)
            is_thumb_down = (thumb_vec_y > 0.06) and (landmarks[4].y > landmarks[8].y)

            pinch_dist = math.hypot(landmarks[4].x - landmarks[8].x, landmarks[4].y - landmarks[8].y)
            peace_v_dist = math.hypot(landmarks[8].x - landmarks[12].x, landmarks[8].y - landmarks[12].y)

            index_x, index_y = landmarks[8].x, landmarks[8].y
            self.index_trail.append((index_x, index_y, now))

            palm_x = int((pts[0][0] + pts[9][0]) / 2)
            palm_y = int((pts[0][1] + pts[9][1]) / 2)

            # 手勢 1：🖐️ 手掌張開懸停 (播放 / 暫停)
            if extended_count >= 3 and not (is_index_extended and not is_middle_extended and not is_ring_extended and not is_pinky_extended):
                self.point_right_counter = 0
                self.point_left_counter = 0
                gesture_detected = f"🖐️ 手掌張開 (蓄力中 {int(self.hover_counter / self.hover_required_frames * 100)}%)"
                if not is_cooling_down:
                    self.hover_counter += 1
                    hover_progress = min(1.0, self.hover_counter / self.hover_required_frames)
                    radius = 36
                    cv2.circle(frame, (palm_x, palm_y), radius, (60, 60, 60), 4, cv2.LINE_AA)
                    angle = int(hover_progress * 360)
                    progress_color = (0, int(150 + 105 * hover_progress), int(255 * hover_progress))
                    cv2.ellipse(frame, (palm_x, palm_y), (radius, radius), 0, -90, -90 + angle, progress_color, 5, cv2.LINE_AA)
                    cv2.circle(frame, (palm_x, palm_y), int(6 + 8 * hover_progress), progress_color, -1, cv2.LINE_AA)

                    if self.hover_counter >= self.hover_required_frames:
                        self.trigger_play_pause()
                else:
                    self.hover_counter = max(0, self.hover_counter - 1)

            # 手勢 2：✌️ 剪刀手 / 勝利手勢 (略過廣告)
            elif is_index_extended and is_middle_extended and not is_ring_extended and not is_pinky_extended and peace_v_dist > 0.030:
                self.hover_counter = max(0, self.hover_counter - 1)
                self.point_right_counter = 0
                self.point_left_counter = 0
                gesture_detected = "✌️ 剪刀手 (略過廣告！)"
                cv2.circle(frame, pts[8], 12, (0, 255, 0), -1, cv2.LINE_AA)
                cv2.circle(frame, pts[12], 12, (0, 255, 0), -1, cv2.LINE_AA)
                if not is_cooling_down:
                    self.trigger_force_skip_ad()

            # 手勢 3：👉 單一食指靜態指向 (向右指快轉 / 向左指倒退 - 方案 B 零衝突版)
            elif is_index_extended and extended_count <= 2 and not is_middle_extended and not is_thumb_up and not is_thumb_down:
                self.hover_counter = 0

                # 計算食指骨架向量 (從指根 MCP pts[5] 指向指尖 Tip pts[8])
                vec_x = landmarks[8].x - landmarks[5].x
                vec_y = landmarks[8].y - landmarks[5].y
                vec_len = math.hypot(vec_x, vec_y)

                tip_px, tip_py = pts[8]
                mcp_px, mcp_py = pts[5]

                # 繪製食指科幻導向箭頭骨架
                cv2.line(frame, (mcp_px, mcp_py), (tip_px, tip_py), (0, 255, 255), 3, cv2.LINE_AA)
                cv2.circle(frame, (tip_px, tip_py), 8, (0, 200, 255), -1, cv2.LINE_AA)

                if vec_len > 0.07:
                    norm_x = vec_x / vec_len
                    if norm_x > 0.45: # 靜態水平朝右指
                        self.point_left_counter = 0
                        if not is_cooling_down:
                            self.point_right_counter += 1
                        pct = int(min(1.0, self.point_right_counter / self.point_required_frames) * 100)
                        if is_cooling_down:
                            gesture_detected = f"👉 食指朝右 (冷卻中)"
                        else:
                            gesture_detected = f"👉 食指朝右 (快轉蓄力 {pct}%)"

                        # 充能進度環 (青藍色)
                        progress = min(1.0, self.point_right_counter / self.point_required_frames)
                        radius = 28
                        angle = int(progress * 360)
                        cv2.circle(frame, (tip_px, tip_py), radius, (50, 50, 50), 3, cv2.LINE_AA)
                        cv2.ellipse(frame, (tip_px, tip_py), (radius, radius), 0, -90, -90 + angle, (0, 255, 255), 4, cv2.LINE_AA)
                        cv2.putText(frame, f">> +10s ({pct}%)", (tip_px + 20, tip_py + 6), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

                        if self.point_right_counter >= self.point_required_frames:
                            self.trigger_swipe_right()
                            self.point_right_counter = 0

                    elif norm_x < -0.45: # 靜態水平朝左指
                        self.point_right_counter = 0
                        if not is_cooling_down:
                            self.point_left_counter += 1
                        pct = int(min(1.0, self.point_left_counter / self.point_required_frames) * 100)
                        if is_cooling_down:
                            gesture_detected = f"👈 食指朝左 (冷卻中)"
                        else:
                            gesture_detected = f"👈 食指朝左 (倒退蓄力 {pct}%)"

                        # 充能進度環 (紫紅色)
                        progress = min(1.0, self.point_left_counter / self.point_required_frames)
                        radius = 28
                        angle = int(progress * 360)
                        cv2.circle(frame, (tip_px, tip_py), radius, (50, 50, 50), 3, cv2.LINE_AA)
                        cv2.ellipse(frame, (tip_px, tip_py), (radius, radius), 0, -90, -90 + angle, (255, 100, 255), 4, cv2.LINE_AA)
                        cv2.putText(frame, f"<< -10s ({pct}%)", (tip_px - 110, tip_py + 6), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 100, 255), 2)

                        if self.point_left_counter >= self.point_required_frames:
                            self.trigger_swipe_left()
                            self.point_left_counter = 0
                    else:
                        # 向上或中立
                        self.point_right_counter = max(0, self.point_right_counter - 1)
                        self.point_left_counter = max(0, self.point_left_counter - 1)
                        gesture_detected = "👉 食指就緒 (指右快轉 / 指左倒退)"
                        cv2.circle(frame, (tip_px, tip_py), 14, (0, 255, 200), 2, cv2.LINE_AA)
                else:
                    self.point_right_counter = max(0, self.point_right_counter - 1)
                    self.point_left_counter = max(0, self.point_left_counter - 1)
                    gesture_detected = "👉 食指就緒 (指右快轉 / 指左倒退)"

            # 手勢 4：👍 大拇指朝上 (僅調大 Windows 主音量，絕不碰觸 YouTube 內部音量)
            elif is_thumb_up and not is_index_extended and not is_middle_extended:
                self.hover_counter = max(0, self.hover_counter - 1)
                gesture_detected = "👍 大拇指朝上 (調大音量)"
                if (now - self.volume_last_time) > self.volume_cooldown:
                    self.trigger_volume_up()

            # 手勢 5：👎 大拇指朝下 (僅調小 Windows 主音量，絕不碰觸 YouTube 內部音量)
            elif is_thumb_down and not is_index_extended and not is_middle_extended:
                self.hover_counter = max(0, self.hover_counter - 1)
                gesture_detected = "👎 大拇指朝下 (調小音量)"
                if (now - self.volume_last_time) > self.volume_cooldown:
                    self.trigger_volume_down()

            else:
                self.hover_counter = max(0, self.hover_counter - 1)

        else:
            self.hover_counter = max(0, self.hover_counter - 1)
            self.index_trail.clear()

        # HUD 介面
        overlay = frame.copy()
        cv2.rectangle(overlay, (0, 0), (w, 85), (15, 23, 42), -1)
        cv2.rectangle(overlay, (0, h - 55), (w, h), (15, 23, 42), -1)
        cv2.addWeighted(overlay, 0.75, frame, 0.25, 0, frame)

        frame = draw_chinese_text(frame, "AirTouch 懸浮透明遙控 + 全螢幕桌面錄影", (16, 10), font_size=20, color=(255, 215, 0))
        status_color = (0, 255, 255) if "就緒" in gesture_detected or "蓄力" in gesture_detected or "剪刀" in gesture_detected else (200, 200, 200)
        frame = draw_chinese_text(frame, f"手勢: {gesture_detected}", (16, 42), font_size=17, color=status_color)

        # 錄影紅燈指示器 (REC [00:15])
        if self.is_recording:
            start_t = getattr(self, 'record_start_time', 0.0)
            if start_t <= 0.0:
                start_t = now
                self.record_start_time = now
            elapsed = int(now - start_t)
            m, s = divmod(elapsed, 60)
            rec_str = f"全螢幕 REC {m:02d}:{s:02d}"
            # 閃爍紅燈
            if int(now * 2) % 2 == 0:
                cv2.circle(frame, (w - 280, 20), 7, (0, 0, 255), -1, cv2.LINE_AA)
            frame = draw_chinese_text(frame, rec_str, (w - 268, 10), font_size=15, color=(0, 0, 255))
        else:
            top_str = "置頂:ON" if win_mgr.topmost else "置頂:OFF"
            alpha_str = f"透明:{win_mgr.alpha_labels[win_mgr.alpha_idx][:3]}"
            pip_str = " [PiP]" if win_mgr.pip_mode else ""
            hud_right = f"{top_str} | {alpha_str}{pip_str}"
            frame = draw_chinese_text(frame, hud_right, (w - 240, 10), font_size=13, color=(56, 189, 248))

        if "食指" in gesture_detected:
            meter_w = int(abs(self.swipe_dx_display) / 0.088 * 60)
            meter_w = min(60, meter_w)
            meter_x = w - 240
            meter_color = (0, 255, 128) if abs(self.swipe_dx_display) >= 0.088 else (0, 200, 255)
            cv2.rectangle(frame, (meter_x, 48), (meter_x + 60, 58), (50, 50, 50), -1)
            cv2.rectangle(frame, (meter_x, 48), (meter_x + meter_w, 58), meter_color, -1)
            frame = draw_chinese_text(frame, "力道:", (meter_x - 45, 42), font_size=13, color=(200, 200, 200))
        else:
            mode_text = "鍵盤:ON" if self.simulate_os_keys else "演示:OFF"
            frame = draw_chinese_text(frame, f"{mode_text} [R]錄影 [T]透明 [P]畫中畫", (w - 260, 42), font_size=12, color=(160, 160, 160))

        if now < self.trigger_toast_until:
            toast_overlay = frame.copy()
            toast_color = (139, 92, 246) if "語音" in self.last_triggered_text else ((16, 185, 129) if ("略過" in self.last_triggered_text or "視窗" in self.last_triggered_text or "錄影" in self.last_triggered_text) else (37, 99, 235))
            cv2.rectangle(toast_overlay, (20, h - 50), (w - 20, h - 10), toast_color, -1)
            cv2.addWeighted(toast_overlay, 0.85, frame, 0.15, 0, frame)
            frame = draw_chinese_text(frame, f"{self.last_triggered_text}", (32, h - 45), font_size=17, color=(255, 255, 255))
        else:
            frame = draw_chinese_text(frame, "🖐️手勢+🎙️語音 (點歌/播/停/音量/快倒轉/廣告/錄影/退出) | [ESC]退出", (16, h - 42), font_size=13, color=(210, 210, 210))

        # 若正在錄影，寫入 MP4 影像幀
        if self.is_recording and self.video_writer:
            self.video_writer.write(frame)

        return frame

def main():
    print("=" * 68)
    print("【專題 12】AirTouch 無接觸智慧遙控 (科幻懸浮透明・教材錄影旗艦版) 啟動中...")
    print("=" * 68)
    print("🎥 教材錄製專屬熱鍵：")
    print("  • [R] 鍵 / [F9] 鍵：一鍵開始 / 停止全螢幕 1080P 錄影")
    print("-" * 68)
    print("🎙️ 智慧語音指令 (Voice AI Remote)：")
    print("  • 🌐 開啟 YouTube 網站：說「開啟YT網站」、「開啟YT」、「打開YouTube」等")
    print("  • 🛑 關閉當前影音：說「關閉這首影音 / 關閉這首」、「關閉影片」、「關掉音樂」等")
    print("  • 🔄 換聽其他影音：說「換聽告五人」、「換播周杰倫」、「關閉這首換播稻香」、「我想聽五月天」等")
    print("  • 🎵 語音點歌搜尋：說「我想聽周杰倫的稻香」、「播放告五人」、「點歌 孤勇者」等")
    print("  • 播放/暫停：說「播放」、「暫停」、「繼續播放」")
    print("  • 音量調整：說「大聲一點 / 增加音量」、「小聲一點 / 降低音量」、「靜音」")
    print("  • 任意秒數跳轉：說「往前快轉XX秒 / 快轉XX秒」、「往後快轉XX秒 / 倒退XX秒」")
    print("  • 去除廣告：說「跳過廣告 / 去廣告」")
    print("  • 視窗模式：說「全螢幕 / 全屏」")
    print("  • 全螢幕錄影：說「開始錄影」、「停止錄影」")
    print("  • 安全退出：說「關閉程式 / 結束程式」")
    print("-" * 68)
    print("🌟 懸浮透明視窗熱鍵：")
    print("  • [T] 鍵：切換透明度 (75% 半透明 ➔ 55% 透視 ➔ 100% 不透明)")
    print("  • [O] 鍵：切換「永遠置頂懸浮」開關 (ON / OFF)")
    print("  • [P] 鍵：切換「右上角迷你畫中畫 (Mini PiP)」")
    print("-" * 68)
    print("🎮 手勢與遙控操作：")
    print("  • ✌️ 剪刀手 / 勝利手勢    -> 隔空強制略過 YouTube 廣告！")
    print("  • [Q] 或 [S] 鍵           -> 鍵盤一鍵強制略過 YouTube 廣告！")
    print("  • [A] 鍵                  -> 切換「廣告自動跳過」開關 (ON / OFF)")
    print("  • [M] 鍵                  -> 切換實體鍵盤模擬 (ON / OFF)")
    print("  • [ESC] 鍵                -> 安全退出程式")
    print("=" * 68)

    controller = AirTouchController(model_path="hand_landmarker.task")
    win_mgr = FloatingWindowManager("AirTouch Gesture Remote")

    cap = None
    for cam_idx in [0, 1, 2]:
        temp_cap = cv2.VideoCapture(cam_idx, cv2.CAP_DSHOW)
        if temp_cap.isOpened():
            ret, _ = temp_cap.read()
            if ret:
                cap = temp_cap
                print(f"[系統] 成功連接 WebCam 攝影機 (索引: {cam_idx})")
                break
            temp_cap.release()

    if cap is None:
        print("[錯誤] 找不到任何可用的攝影機！請檢查 USB 鏡頭連線或隱私權設定。")
        input("請按 Enter 鍵結束...")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    cv2.namedWindow("AirTouch Gesture Remote", cv2.WINDOW_AUTOSIZE)

    prev_time = time.time()
    fps = 0
    window_setup_done = False

    def on_voice_exit(cmd_text):
        controller.request_exit = True
        controller.last_triggered_text = f"【🎙️ 語音控制】收到指令「{cmd_text}」！安全退出中..."
        controller.trigger_toast_until = time.time() + 3.0

    def on_voice_record(start_flag):
        controller.toggle_recording(force_state=start_flag)

    def on_voice_action(action):
        if isinstance(action, tuple):
            if action[0] == 'seek':
                _, direction, seconds = action
                dir_text = "⏩ 往前快轉" if direction == 'forward' else "⏪ 往後倒退"
                controller.trigger_seek(seconds, direction=direction, custom_text=f"【🎙️ 語音】{dir_text} {seconds} 秒 (YouTube)")
            elif action[0] == 'song_search':
                _, song_query = action
                controller.search_and_play_song(song_query)
        elif action == 'open_youtube':
            controller.open_youtube_website(custom_text="【🎙️ 語音】🚀 正在為您開啟 YouTube 網站！")
        elif action == 'close_media':
            controller.close_current_media(custom_text="【🎙️ 語音】🛑 已關閉這首影音分頁")
        elif action == 'play':
            controller.trigger_play_pause(custom_text="【🎙️ 語音】▶️ 繼續播放 (YouTube)")
        elif action == 'pause':
            controller.trigger_play_pause(custom_text="【🎙️ 語音】⏸️ 暫停播放 (YouTube)")
        elif action == 'forward':
            controller.trigger_seek(10, direction='forward', custom_text="【🎙️ 語音】⏩ 往前快轉 10 秒 (YouTube)")
        elif action == 'rewind':
            controller.trigger_seek(10, direction='backward', custom_text="【🎙️ 語音】⏪ 往後倒退 10 秒 (YouTube)")
        elif action == 'volume_up':
            controller.trigger_volume_up(steps=4, custom_text="【🎙️ 語音】🔊 音量增加 (+)")
        elif action == 'volume_down':
            controller.trigger_volume_down(steps=4, custom_text="【🎙️ 語音】🔉 音量降低 (-)")
        elif action == 'mute':
            controller.trigger_toggle_mute(custom_text="【🎙️ 語音】🔇 系統靜音切換")
        elif action == 'skip_ad':
            controller.trigger_force_skip_ad(custom_text="【🎙️ 語音】⚡ 立即跳過 YouTube 廣告")
        elif action == 'fullscreen':
            controller.trigger_toggle_fullscreen(custom_text="【🎙️ 語音】🖥️ 全螢幕切換 (YouTube)")

    voice_listener = VoiceCommandListener(on_voice_exit, on_record_callback=on_voice_record, on_action_callback=on_voice_action)
    voice_listener.start()

    # 全域熱鍵守護執行緒：無論焦點在哪個視窗 (包含全螢幕 YouTube)，按下 [F9] 或 [Ctrl+R] 都能立即錄影！
    def global_hotkey_worker():
        last_f9 = False
        last_ctrl_r = False
        while not controller.request_exit:
            try:
                # F9 (0x78)
                f9 = (ctypes.windll.user32.GetAsyncKeyState(0x78) & 0x8000) != 0
                if f9 and not last_f9:
                    print("\n[全域熱鍵] 🔴 按下 [F9] 鍵！切換全螢幕影音錄影...")
                    controller.toggle_recording()
                last_f9 = f9

                # Ctrl+R (0x11 + 0x52)
                ctrl = (ctypes.windll.user32.GetAsyncKeyState(0x11) & 0x8000) != 0
                r_key = (ctypes.windll.user32.GetAsyncKeyState(0x52) & 0x8000) != 0
                ctrl_r = ctrl and r_key
                if ctrl_r and not last_ctrl_r:
                    print("\n[全域熱鍵] 🔴 按下 [Ctrl+R] 鍵！切換全螢幕影音錄影...")
                    controller.toggle_recording()
                last_ctrl_r = ctrl_r
            except Exception:
                pass
            time.sleep(0.04)

    if HAS_WIN32:
        threading.Thread(target=global_hotkey_worker, daemon=True).start()


    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            frame = cv2.flip(frame, 1)

            processed_frame = controller.process_frame(frame, win_mgr)

            curr_time = time.time()
            fps = int(1.0 / (curr_time - prev_time + 1e-6))
            prev_time = curr_time
            cv2.putText(processed_frame, f"FPS: {fps}", (processed_frame.shape[1] - 85, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)

            cv2.imshow("AirTouch Gesture Remote", processed_frame)

            if not window_setup_done:
                time.sleep(0.05)
                if win_mgr.find_and_setup():
                    window_setup_done = True
                    print("[視窗特效] 🛡️ 懸浮置頂 (Always-on-Top) 與 75% 科幻透明樣式已成功啟用！")

            key = cv2.waitKey(1) & 0xFF
            if key == 27 or controller.request_exit: # ESC or Voice Exit
                exit_msg = "語音「關閉程式」" if controller.request_exit else "ESC 鍵"
                print(f"[系統] 收到退出指令 ({exit_msg})，正在安全釋放資源並結束程式...")
                break
            elif key == ord('r') or key == ord('R'):
                controller.toggle_recording()
            elif key == ord('t') or key == ord('T'):
                label = win_mgr.cycle_transparency()
                controller.last_triggered_text = f"【視窗特效】透明度切換為: {label}"
                controller.trigger_toast_until = time.time() + 1.5
            elif key == ord('o') or key == ord('O'):
                state = win_mgr.toggle_topmost()
                controller.last_triggered_text = f"【視窗特效】永遠置頂: {state}"
                controller.trigger_toast_until = time.time() + 1.5
            elif key == ord('p') or key == ord('P'):
                pip_label = win_mgr.toggle_pip()
                controller.last_triggered_text = f"【視窗特效】切換至: {pip_label}"
                controller.trigger_toast_until = time.time() + 1.5
            elif key == ord('q') or key == ord('Q') or key == ord('s') or key == ord('S'):
                print("[快捷熱鍵] 按下 Q/S 鍵：發動強制略過廣告！")
                controller.trigger_force_skip_ad()
            elif key == ord('m') or key == ord('M'):
                controller.simulate_os_keys = not controller.simulate_os_keys
                state_str = "開啟 (ON)" if controller.simulate_os_keys else "關閉 (OFF)"
                print(f"[模式切換] 鍵盤模擬已 {state_str}")
            elif key == ord('a') or key == ord('A'):
                controller.toggle_ad_skipper()
                state_str = "開啟 (ON)" if controller.auto_ad_skip_enabled else "關閉 (OFF)"
                print(f"[模式切換] 廣告自動跳過已 {state_str}")
    finally:
        print("[系統] 正在完全關閉整個輔助程式 (釋放攝影機、銷毀視窗)...")
        voice_listener.stop()
        if controller.is_recording:
            controller.toggle_recording()
        controller.stop()
        cap.release()
        cv2.destroyAllWindows()
        print("[系統] ✅ 整個輔助程式已安全關閉完成！")
        time.sleep(0.15)
        os._exit(0)

if __name__ == "__main__":
    main()
