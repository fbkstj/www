# -*- coding: utf-8 -*-
"""
Auto Ad Hunter for YouTube & Video Platforms (多尺度・超感度旗艦守護版)
======================================================================
核心優化：
1. 【多樣態多尺度樣板池 (70+組)】：
   包含 YouTube 真實按鈕多尺度 (0.55x ~ 1.60x)、深色/淺色/半透明多字體「略過」、「略過廣告」、
   「跳過」、「Skip」、「Skip Ads」，徹底解決新版按鈕樣式多變問題！
2. 【自適應感度閥值 (0.72 / 0.75)】：
   解決 YouTube 半透明按鈕因背景影片色彩變動導致匹對分數降至 0.75~0.80 而無法觸發之痛點。
3. 【自適應動態裁切框】：
   精確鎖定播放器右下半部 (x: 38%~100%, y: 15%~底部-25px)，無論視窗縮放或移動，完美包覆按鈕且避開底列音量鍵。
4. 【強力獵犬重試模式 (Active Hunter Loop)】：
   手勢 ✌️ 或語音「跳過廣告」時，若廣告正在 5 秒倒數，自動啟動 4.5 秒高頻獵犬追蹤，
   倒數一結束按鈕浮現的瞬間 0.1 秒秒按！
5. 【單擊精確點擊 + 瞬間游標復原】：
   絕不連擊以防誤觸全螢幕，點擊後 0.02 秒光速復原滑鼠位置，使用者工作完全不被打擾。
"""

import os
import sys
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass
import time
import threading
import winsound
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont, ImageGrab

try:
    import win32api
    import win32con
    import win32gui
    import win32process
    import win32service
    import ctypes
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False


def force_foreground_window(hwnd):
    """強效將指定視窗帶至前景"""
    if not HAS_WIN32 or not hwnd or not win32gui.IsWindow(hwnd):
        return None
    fore_hwnd = win32gui.GetForegroundWindow()
    if hwnd == fore_hwnd:
        return fore_hwnd
    try:
        fore_thread = win32process.GetWindowThreadProcessId(fore_hwnd)[0]
        cur_thread = ctypes.windll.kernel32.GetCurrentThreadId()
        ctypes.windll.user32.AttachThreadInput(cur_thread, fore_thread, True)
        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        ctypes.windll.user32.SetForegroundWindow(hwnd)
        ctypes.windll.user32.AttachThreadInput(cur_thread, fore_thread, False)
        return fore_hwnd
    except Exception:
        try:
            win32gui.SetForegroundWindow(hwnd)
            return fore_hwnd
        except Exception:
            return None


class AdSkipperEngine:
    """YouTube 廣告自動跳過精準穿透引擎"""
    def __init__(self, check_interval=0.5, on_skipped_callback=None):
        self.check_interval = check_interval
        self.on_skipped_callback = on_skipped_callback
        self.running = False
        self.enabled = True
        self.thread = None
        
        self.last_skip_time = 0
        self.skip_cooldown = 2.5
        self.skip_count = 0
        
        self.templates = []
        self._init_templates()

    def _init_templates(self):
        """載入真實 YouTube 按鈕樣板與高感度合成樣板"""
        cur_dir = os.path.dirname(os.path.abspath(__file__))
        exact_tpl_path = os.path.join(cur_dir, "yt_skip_button_tpl.png")
        if not os.path.exists(exact_tpl_path):
            alt = os.path.join(os.path.dirname(cur_dir), "yt_skip_button_tpl.png")
            if os.path.exists(alt):
                exact_tpl_path = alt

        # 1. 真實按鈕多尺度 (0.55x ~ 1.60x)
        if os.path.exists(exact_tpl_path):
            try:
                exact_img = Image.open(exact_tpl_path)
                exact_cv = cv2.cvtColor(np.array(exact_img), cv2.COLOR_RGB2GRAY)
                self.templates.append(("真實_略過_100%", exact_cv))
                for scale in [0.55, 0.68, 0.80, 0.90, 1.10, 1.25, 1.40, 1.60]:
                    nw = int(exact_cv.shape[1] * scale)
                    nh = int(exact_cv.shape[0] * scale)
                    scaled_cv = cv2.resize(exact_cv, (nw, nh), interpolation=cv2.INTER_AREA if scale < 1.0 else cv2.INTER_LINEAR)
                    self.templates.append((f"真實_略過_{int(scale*100)}%", scaled_cv))
            except Exception as e:
                print(f"[AdSkipper] 載入真實樣板異常: {e}")

        # 2. 全方位合成樣板 (深色膠囊按鈕、淺色膠囊按鈕、現代簡約按鈕)
        texts = ["略過", "略過廣告", "略過 ▶|", "略過 ▶", "跳過", "跳過廣告", "Skip", "Skip Ad", "Skip Ads"]
        font_paths = ["C:/Windows/Fonts/msjhbd.ttc", "C:/Windows/Fonts/msjh.ttc", "C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/arial.ttf"]
        found_fonts = [fp for fp in font_paths if os.path.exists(fp)]

        for text in texts:
            for fp in found_fonts[:1]:
                for sz in [14, 16, 18, 20]:
                    try:
                        font = ImageFont.truetype(fp, sz)
                        dummy = Image.new('RGB', (10, 10))
                        d_draw = ImageDraw.Draw(dummy)
                        bbox = d_draw.textbbox((0, 0), text, font=font)
                        w = (bbox[2] - bbox[0]) + 16
                        h = (bbox[3] - bbox[1]) + 10
                        
                        # 深色主題/半透明黑按鈕 (YouTube 大宗)
                        img_dark = Image.new('RGB', (w, h), (24, 24, 24))
                        d_dark = ImageDraw.Draw(img_dark)
                        d_dark.text((8, 4), text, fill=(255, 255, 255), font=font)
                        cv_tpl_dark = cv2.cvtColor(np.array(img_dark), cv2.COLOR_RGB2GRAY)
                        self.templates.append((f"深色_{text}_{sz}px", cv_tpl_dark))

                        # 淺色主題/白底黑字膠囊按鈕
                        img_light = Image.new('RGB', (w, h), (235, 235, 235))
                        d_light = ImageDraw.Draw(img_light)
                        d_light.text((8, 4), text, fill=(20, 20, 20), font=font)
                        cv_tpl_light = cv2.cvtColor(np.array(img_light), cv2.COLOR_RGB2GRAY)
                        self.templates.append((f"淺色_{text}_{sz}px", cv_tpl_light))
                    except Exception:
                        pass

        print(f"[AdSkipper] 成功載入 {len(self.templates)} 組高感度 YouTube 廣告按鈕尺度樣板！")

    def _ensure_desktop(self):
        if HAS_WIN32:
            try:
                hwinsta = win32service.OpenWindowStation('winsta0', False, 0x02000000)
                hwinsta.SetProcessWindowStation()
                hdesk = win32service.OpenDesktop('default', 0, False, 0x02000000)
                hdesk.SetThreadDesktop()
            except Exception:
                pass

    def _find_youtube_window(self):
        """即時搜尋並定位系統中的 YouTube / 瀏覽器視窗 (支援隨時移動與縮放)"""
        if not HAS_WIN32:
            return None
        self._ensure_desktop()
        candidates = []
        def enum_cb(hwnd, _):
            if win32gui.IsWindowVisible(hwnd) and not win32gui.IsIconic(hwnd):
                title = win32gui.GetWindowText(hwnd).lower()
                if 'airtouch' in title:
                    return
                if any(b in title for b in ['youtube', 'chrome', 'edge', 'brave', 'firefox', 'opera']):
                    try:
                        r = win32gui.GetWindowRect(hwnd)
                        w = r[2] - r[0]
                        h = r[3] - r[1]
                        if w >= 320 and h >= 240:
                            score = 10 if 'youtube' in title else 2
                            candidates.append((score, hwnd, r))
                    except Exception:
                        pass
        try:
            win32gui.EnumWindows(enum_cb, None)
        except Exception:
            pass

        if candidates:
            candidates.sort(key=lambda x: x[0], reverse=True)
            best_hwnd = candidates[0][1]
            try:
                return (best_hwnd, win32gui.GetWindowRect(best_hwnd))
            except Exception:
                return (best_hwnd, candidates[0][2])
        return None

    def force_skip_now(self, max_duration=4.5):
        """【強力略過獵犬模式】持續追蹤掃描 4.5 秒，廣告一倒數完畢轉成「略過」按鈕時立即秒按！"""
        self._ensure_desktop()
        yt_info = self._find_youtube_window()
        if not yt_info:
            print("[AdSkipper] 未偵測到執行中的 YouTube 瀏覽器視窗！")
            try:
                winsound.Beep(550, 70)
            except Exception:
                pass
            return False

        yt_hwnd, yt_rect = yt_info
        orig_fore = win32gui.GetForegroundWindow()

        # 若 YouTube 視窗非前景，平滑帶到前景以利即時截圖與點擊
        if yt_hwnd != orig_fore:
            force_foreground_window(yt_hwnd)
            time.sleep(0.12)

        start_t = time.time()
        hit = False
        print("[AdSkipper] 啟動強力獵犬守護：即時追蹤廣告按鈕中...")
        while time.time() - start_t < max_duration:
            hit = self.scan_and_click(force_mode=True)
            if hit:
                print("[AdSkipper] 成功鎖定並秒按略過廣告按鈕！")
                break
            time.sleep(0.25) # 每 250ms 高頻重試

        if not hit:
            print("[AdSkipper] ℹ️ 追蹤結束：當前畫面無可略過按鈕（可能為不可略過廣告或已結束）。")

        if orig_fore and orig_fore != yt_hwnd:
            time.sleep(0.08)
            force_foreground_window(orig_fore)

        return hit

    def scan_and_click(self, force_mode=False):
        """比對畫面並單次精準點擊略過按鈕"""
        if not self.enabled and not force_mode:
            return False

        now = time.time()
        if not force_mode and (now - self.last_skip_time < self.skip_cooldown):
            return False

        self._ensure_desktop()

        yt_info = self._find_youtube_window()
        try:
            screen_img = ImageGrab.grab()
            screen_w, screen_h = screen_img.size
        except Exception:
            return False

        screen_np = np.array(screen_img)

        # 遮蔽 AirTouch 攝影機自身視窗
        if HAS_WIN32:
            try:
                airtouch_hwnd = win32gui.FindWindow(None, "AirTouch Gesture Remote")
                if airtouch_hwnd and win32gui.IsWindowVisible(airtouch_hwnd):
                    ar = win32gui.GetWindowRect(airtouch_hwnd)
                    ax1, ay1 = max(0, ar[0]), max(0, ar[1])
                    ax2, ay2 = min(screen_w, ar[2]), min(screen_h, ar[3])
                    if ax2 > ax1 and ay2 > ay1:
                        screen_np[ay1:ay2, ax1:ax2] = 0
            except Exception:
                pass

        if yt_info:
            yt_hwnd, yt_rect = yt_info
            try:
                yt_rect = win32gui.GetWindowRect(yt_hwnd)
            except Exception:
                pass
            yt_x1, yt_y1, yt_x2, yt_y2 = yt_rect
            yt_w = yt_x2 - yt_x1
            yt_h = yt_y2 - yt_y1

            # 自適應動態裁切：精準鎖定 YouTube 播放器右下部
            # 寬度從 38%~100% 涵蓋非全螢幕/劇院/窄視窗各種佈局，避開底部 Windows 狀態列 (yt_y2 - 25)
            # 且避開左側 0~38% 的播放控制與音量滑桿
            crop_x1 = max(yt_x1, yt_x1 + int(yt_w * 0.38))
            crop_y1 = max(yt_y1, yt_y1 + int(yt_h * 0.15))
            crop_x2 = min(screen_w, yt_x2)
            crop_y2 = min(screen_h, yt_y2 - 25)
        else:
            crop_x1 = int(screen_w * 0.35)
            crop_y1 = int(screen_h * 0.15)
            crop_x2 = screen_w
            crop_y2 = screen_h

        if crop_x2 <= crop_x1 + 80 or crop_y2 <= crop_y1 + 80:
            return False

        cropped_np = screen_np[crop_y1:crop_y2, crop_x1:crop_x2]
        gray_screen = cv2.cvtColor(cropped_np, cv2.COLOR_RGB2GRAY)

        best_score = 0
        best_loc = None
        best_tpl_name = ""
        best_tpl_size = (0, 0)

        for tpl_name, tpl in self.templates:
            th, tw = tpl.shape
            if th >= gray_screen.shape[0] or tw >= gray_screen.shape[1]:
                continue
            res = cv2.matchTemplate(gray_screen, tpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)

            if max_val > best_score:
                best_score = max_val
                best_loc = max_loc
                best_tpl_name = tpl_name
                best_tpl_size = (tw, th)

            if best_score >= 0.94:
                break

        # 自適應感度閥值 (真實樣板 >= 0.72，合成樣板 >= 0.75)
        # 由於裁切框已嚴格鎖定在右下方，0.72 即可極高靈敏度命中半透明/動態背景按鈕且零誤觸！
        THRESHOLD = 0.72 if "真實" in best_tpl_name else 0.75
        if best_score >= THRESHOLD and best_loc is not None:
            btn_x = crop_x1 + best_loc[0] + best_tpl_size[0] // 2
            btn_y = crop_y1 + best_loc[1] + best_tpl_size[1] // 2

            self.last_skip_time = now
            self.skip_count += 1
            print(f"\n[略過廣告] 精準鎖定「{best_tpl_name}」！座標: ({btn_x}, {btn_y}) 信心度: {best_score:.2%}")
            
            # 發送單次精確點擊 (Single Click)
            self._execute_single_click_at(btn_x, btn_y)

            if self.on_skipped_callback:
                try:
                    self.on_skipped_callback(best_tpl_name, (btn_x, btn_y))
                except Exception:
                    pass
            return True

        return False

    def _execute_single_click_at(self, x, y):
        """
        單次精確點擊 (Single Click Only)：
        嚴格發送單次 mousedown + mouseup，絕不連擊以避免觸發全螢幕，並於 0.02 秒內復原游標
        """
        if HAS_WIN32:
            try:
                orig_x, orig_y = win32api.GetCursorPos()
                win32api.SetCursorPos((x, y))
                time.sleep(0.015)
                win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, x, y, 0, 0)
                time.sleep(0.02)
                win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, x, y, 0, 0)
                time.sleep(0.02)
                win32api.SetCursorPos((orig_x, orig_y))
            except Exception:
                try:
                    import pyautogui
                    orig_x, orig_y = pyautogui.position()
                    pyautogui.click(x, y)
                    time.sleep(0.02)
                    pyautogui.moveTo(orig_x, orig_y)
                except Exception:
                    pass
        else:
            try:
                import pyautogui
                orig_x, orig_y = pyautogui.position()
                pyautogui.click(x, y)
                time.sleep(0.02)
                pyautogui.moveTo(orig_x, orig_y)
            except Exception:
                pass

        threading.Thread(target=self._play_chime, daemon=True).start()

    def _play_chime(self):
        try:
            winsound.Beep(1200, 70)
            winsound.Beep(1600, 100)
        except Exception:
            pass

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._worker_loop, daemon=True)
        self.thread.start()
        print("[AdSkipper] 廣告自動略過背景守護已啟動 (多尺度高感度旗艦版)！")

    def stop(self):
        self.running = False

    def _worker_loop(self):
        while self.running:
            try:
                self.scan_and_click()
            except Exception:
                pass
            time.sleep(self.check_interval)


if __name__ == "__main__":
    print("=" * 65)
    print("   YouTube 智慧自動略過廣告守護小精靈 (多尺度高感度旗艦版)")
    print("   按 [Q] 或 [S] 可立即強制跳過廣告！按 Ctrl+C 退出。")
    print("=" * 65)

    skipper = AdSkipperEngine(check_interval=0.5)
    skipper.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        skipper.stop()
        print("\n[AdSkipper] 守護程式已安全退出。")
