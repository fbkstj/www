@echo off
pushd "%~dp0"
title AirTouch Gesture Remote - Edge AI
echo ============================================================
echo Starting AirTouch Gesture Remote Control...
echo ============================================================
python airtouch_gesture_control.py
if errorlevel 1 (
    echo.
    echo Application exited with error.
    pause
)
popd
