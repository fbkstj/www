﻿# UTF-8 Encoding
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$LogOutputFile = "C:\123\eset_monitor.log"

function Log-Message ($msg, $color = "White") {
    $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $fullMsg = "[$time] $msg"
    Write-Host $fullMsg -ForegroundColor $color
    Add-Content -Path $LogOutputFile -Value $fullMsg -Encoding UTF8 -ErrorAction SilentlyContinue
}

Clear-Host
Log-Message "==========================================================================" "Cyan"
Log-Message "  [ESET 企業端授權啟用與防護即時監控] 正在持續監控階段 4 授權派送與啟用..." "Green"
Log-Message "  監控目標：中控伺服器 (163.30.0.169) 派發授權、WebActivationState、WMI 266240" "White"
Log-Message "  紀錄檔路徑: $LogOutputFile" "DarkGray"
Log-Message "  按 Ctrl + C 可隨時停止監控" "Yellow"
Log-Message "==========================================================================" "Cyan"

# 1. 檔案與日誌變更監聽 (FileSystemWatcher)
$LogFolder1 = "C:\ProgramData\ESET\ESET Security\Logs"
$LogFolder2 = "C:\ProgramData\ESET\RemoteAdministrator\Agent\EraAgentApplicationData\Logs"

function Register-FolderWatcher ($path, $sourceIdentifier) {
    if (Test-Path $path) {
        $fsw = New-Object System.IO.FileSystemWatcher
        $fsw.Path = $path
        $fsw.IncludeSubdirectories = $true
        $fsw.EnableRaisingEvents = $true

        $action = {
            $changeType = $Event.SourceEventArgs.ChangeType
            $name = $Event.SourceEventArgs.Name
            $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"

            $desc = "[日誌更新] $name ($changeType)"
            $color = "Magenta"
            if ($name -like "*eScan*") {
                $desc = "[掃描觸發] 偵測到 ESET 磁碟/檔案掃描任務正在執行"
                $color = "Cyan"
            } elseif ($name -like "*updatelog*") {
                $desc = "[病毒庫更新] ESET 正在更新病毒定義檔與安全防護模組"
                $color = "Green"
            } elseif ($name -like "*virlog*") {
                $desc = "[威脅告警] ESET 偵測到惡意威脅或攔截項目！"
                $color = "Red"
            } elseif ($name -like "*warnlog*") {
                $desc = "[系統事件] ESET 系統事件/警告日誌更新"
                $color = "Yellow"
            } elseif ($name -like "*trace.log*") {
                $desc = "[中控通訊] ESET Management Agent 與中控伺服器正在通訊複寫"
                $color = "DarkCyan"
            }

            $msg = "[$time] $desc (檔案: $name)"
            Write-Host $msg -ForegroundColor $color
            Add-Content -Path "C:\123\eset_monitor.log" -Value $msg -Encoding UTF8 -ErrorAction SilentlyContinue
        }

        $reg = Register-ObjectEvent $fsw "Changed" -SourceIdentifier "${sourceIdentifier}_Changed" -Action $action
        $regCreated = Register-ObjectEvent $fsw "Created" -SourceIdentifier "${sourceIdentifier}_Created" -Action $action
        return @($fsw, $reg, $regCreated)
    }
    return $null
}

$fswList1 = Register-FolderWatcher $LogFolder1 "ESET_SecLogs"
$fswList2 = Register-FolderWatcher $LogFolder2 "ESET_AgentLogs"

# 2. 初始狀態檢查
$initialActivation = (Get-ItemProperty "HKLM:\SOFTWARE\ESET\ESET Security\CurrentVersion\Info" -ErrorAction SilentlyContinue).WebActivationState
$isActivated = ($initialActivation -ne $null -and $initialActivation -ne 0)

if ($isActivated) {
    Log-Message "目前狀態：【產品已啟用】 (WebActivationState = $initialActivation)" "Green"
} else {
    Log-Message "目前狀態：【等待授權派發中】 (WebActivationState = 0) - Agent 持續連線中控伺服器等待工作..." "Yellow"
}

# 3. 處理程序與狀態輪詢
$knownPids = [System.Collections.Generic.HashSet[int]]::new()
Get-Process | Where-Object { $_.ProcessName -match "eset|ekrn|egui|ecls|sysinspector" } | ForEach-Object {
    [void]$knownPids.Add($_.Id)
}

$lastWscState = 0

try {
    while ($true) {
        # A. 檢查是否已被觸發啟用 (WebActivationState 變更)
        $regInfo = Get-ItemProperty "HKLM:\SOFTWARE\ESET\ESET Security\CurrentVersion\Info" -ErrorAction SilentlyContinue
        $currentActivation = if ($regInfo) { $regInfo.WebActivationState } else { 0 }
        
        if (-not $isActivated -and $currentActivation -ne $null -and $currentActivation -ne 0) {
            $isActivated = $true
            Log-Message "==========================================================================" "Green"
            Log-Message "【 ESET 產品已成功接收授權並完成啟用！】" "Green"
            Log-Message "   啟用時間: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" "Green"
            Log-Message "   授權狀態碼: WebActivationState = $currentActivation" "Green"
            Log-Message "   授權結果: $($regInfo.LastActivationResult)" "Green"
            Log-Message "==========================================================================" "Green"
        }

        # B. 檢查 WMI SecurityCenter 狀態碼
        $wscEset = Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntivirusProduct -ErrorAction SilentlyContinue | Where-Object { $_.displayName -match "ESET" }
        if ($wscEset -and $wscEset.productState -ne $lastWscState) {
            $lastWscState = $wscEset.productState
            $hexState = "0x{0:X6}" -f $lastWscState
            if ($lastWscState -eq 266240) {
                Log-Message "[WMI 防護生效] ESET 安全中心狀態碼: $lastWscState ($hexState) - 即時防護已開啟且病毒庫最新！" "Green"
            } else {
                Log-Message "[WMI 狀態變更] ESET 安全中心狀態碼: $lastWscState ($hexState)" "Cyan"
            }
        }

        # C. 檢查 ESET 相關處理程序
        $currentProcs = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match "eset|ekrn|egui|ecls|sysinspector" }
        $currentPidSet = [System.Collections.Generic.HashSet[int]]::new()

        foreach ($p in $currentProcs) {
            [void]$currentPidSet.Add($p.Id)
            if (-not $knownPids.Contains($p.Id)) {
                Log-Message "[模組啟動] 偵測到 ESET 處理程序被呼叫啟動: $($p.ProcessName) (PID: $($p.Id))" "Cyan"
                [void]$knownPids.Add($p.Id)
            }
        }

        $knownPids.RemoveWhere([System.Predicate[int]]{ param($id) -not $currentPidSet.Contains($id) })

        Start-Sleep -Seconds 2
    }
}
finally {
    Log-Message "正在停止監控..." "Yellow"
    Unregister-Event -SourceIdentifier "ESET_SecLogs_Changed" -ErrorAction SilentlyContinue
    Unregister-Event -SourceIdentifier "ESET_SecLogs_Created" -ErrorAction SilentlyContinue
    Unregister-Event -SourceIdentifier "ESET_AgentLogs_Changed" -ErrorAction SilentlyContinue
    Unregister-Event -SourceIdentifier "ESET_AgentLogs_Created" -ErrorAction SilentlyContinue
    Log-Message "監控已結束。" "Green"
}
