---
name: eset-deployment-and-activation
description: >-
  ESET Endpoint Antivirus 與 ESMC/PROTECT Agent 校園/企業端安裝、內外網環境識別、VPN 即時觸發授權與四大階段生命週期診斷手冊。
---

# ESET Endpoint Antivirus & Management Agent 部署與觸發啟用指南 (SKILL)

本知識包整合了校園/企業環境中 ESET 端點防毒軟體與中控代理程式（Management Agent）的標準安裝順序、內外網連線機制、VPN 環境下的「0 秒即時觸發啟用」技巧與四大階段診斷 SOP。

---

## 1. 軟體角色與建議安裝順序

套件包含兩個核心安裝檔：

| 檔案名稱 | 角色與功能 | 系統服務/核心處理程序 |
| :--- | :--- | :--- |
| **`楊梅區楊梅高中_ESMC_Agent_x64`** | **ESET Management Agent（中控代理）**<br>內含校園專屬憑證，負責與中控台通訊、接收政策與派送授權。 | `EraAgentSvc` (`ESET Management Agent`) |
| **`eea_nt64-13.0`** | **ESET Endpoint Antivirus（防毒主程式）**<br>提供即時檔案防護、網路防護、掃描引擎與病毒碼更新。 | `ekrn.exe` (核心) / `egui.exe` (介面) |

### 推薦安裝順序：
1. **第一步：先安裝【ESET Management Agent】** (`楊梅區楊梅高中_ESMC_Agent_x64`)
   * 優先建立與學校中控伺服器的安全通訊管道，並完成本機憑證註冊。
2. **第二步：再安裝【ESET Endpoint Antivirus】** (`eea_nt64-13.0`)
   * 主程式安裝完成後，Agent 可立即識別到防毒軟體，並向中控台請求「產品啟用工作（Activation Task）」。

> [!NOTE]
> 若順序顛倒安裝亦可運作，但需待 Agent 啟動並完成與伺服器複寫（Replication）後，防毒軟體才會由未啟用狀態轉為綠色受保護狀態。

---

## 2. 網路環境差異與觸發機制

ESMC Agent 與中控台透過 **TCP Port 2222** 進行雙向複寫（Replication）：

### A. 校園內網環境（Intranet）
* **連線特性**：電腦直接處於校園網段（如 `192.168.x.x` 或 `163.30.x.x`）。
* **觸發行為**：
  * Agent 啟動後可直接連通中控主機。
  * 電腦會自動註冊至中控台，並在下一個排程週期（通常為 10~20 分鐘）自動接收授權與原則。

### B. 家中 / 外部網路環境（Extranet via VPN）
* **連線特性**：外網 IP 無法直接存取校內中控主機（TCP 2222），**必須依賴校園 VPN 連線**。
* **卡住原因（排程時間差）**：
  * 開機時 VPN 尚未連線，Agent 嘗試連線失敗後會進入休眠/退避重試等待（可能需等 10～20 分鐘以上）。
  * 若連上 VPN 後只是被動等待，會感覺「防毒軟體一直沒有被觸發啟用」。

---

## 3. VPN 環境下的「0 秒即時觸發啟用」SOP

當在家中或外部網路完成安裝後，請依以下 SOP 進行手動即時觸發：

```mermaid
flowchart TD
    A["1. 開機 / 連上家中 Wi-Fi"] --> B["2. 建立並連通學校 VPN"]
    B --> C["3. 以系統管理員身分重啟 EraAgentSvc 服務"]
    C --> D["4. Agent 立即向中控台發起 TCP 2222 複寫"]
    D --> E["5. 中控台下發啟用任務 & 寫入註冊表"]
    E --> F["6. ESET Endpoint Antivirus 顯示綠色完整保護"]
```

### 操作步驟：

1. **連上學校 VPN**：確認 VPN 客戶端已連線且取得校內網路路由。
2. **強制重啟 Agent 服務**（任選一種方式）：
   * **方式一（快捷批次檔）**：
     滑鼠右鍵點擊 [重啟ESET中控同步.bat](file:///c:/123/重啟ESET中控同步.bat) $\to$ 選擇 **「以系統管理員身分執行」**。
   * **方式二（指令命令提示字元）**：
     以管理員身分開啟 CMD / PowerShell，依序執行：
     ```cmd
     net stop EraAgentSvc
     timeout /t 3 /nobreak > nul
     net start EraAgentSvc
     ```
   * **方式三（Windows 服務視窗）**：
     按 <kbd>Win</kbd> + <kbd>R</kbd> $\to$ 輸入 `services.msc` $\to$ 找到 `ESET Management Agent` $\to$ 點右鍵「重新啟動」。
3. **等待 1～2 分鐘**：Agent 會立即向中控伺服器報到並抓取授權，防毒軟體右下角圖示即會由橘/紅轉為綠色「您受到完整保護」。

---

## 4. 四大階段架構診斷與排錯清單

若執行重啟後依然無法啟用，可使用 PowerShell 執行 [check_eset_phases.ps1](file:///c:/123/check_eset_phases.ps1) 進行分層排查：

### 階段 1：架構與網路連線診斷
* **防毒核心**：檢查 `ekrn.exe` 是否正在運行。
* **中控代理**：檢查 `EraAgentSvc` 服務狀態是否為 `Running`。
* **通訊埠測試**：測試中控伺服器（`163.30.0.169:2222` 或 `192.168.1.189:2222`）是否可連通。

### 階段 2：憑證與安裝包驗證
* 開啟狀態日誌：`C:\ProgramData\ESET\RemoteAdministrator\Agent\EraAgentApplicationData\Logs\status.html`
* 確認 `Peer Certificate: OK`（代表校園專屬憑證載入成功且有效）。

### 階段 3：排程複寫與伺服器註冊
* 檢視 `C:\ProgramData\ESET\RemoteAdministrator\Agent\EraAgentApplicationData\Logs\trace.log`。
* 檢查 `Next replication will occur at` 時間戳記，確認 Agent 與中控台保持同步。

### 階段 4：授權套用與防護狀態
* **註冊表狀態**：
  路徑 `HKLM:\SOFTWARE\ESET\ESET Security\CurrentVersion\Info`
  * `WebActivationState != 0` 代表已成功取得授權啟用。
* **Windows 安全中心 (WSC)**：
  * ProductState 代碼為 `266240` (0x041000) 即代表防護已開啟且病毒定義檔處於最新狀態。
