﻿# UTF-8 Encoding
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

function Write-Section ($title) {
    Write-Host "`n==========================================================================" -ForegroundColor Cyan
    Write-Host "  $title" -ForegroundColor Yellow
    Write-Host "==========================================================================" -ForegroundColor Cyan
}

function Write-Check ($name, $status, $detail, $isOk) {
    $color = if ($isOk) { "Green" } else { "Red" }
    $tag = if ($isOk) { "[PASS]" } else { "[WAIT/FAIL]" }
    Write-Host "$tag $name : " -NoNewline -ForegroundColor $color
    Write-Host $status -ForegroundColor White
    if ($detail) {
        Write-Host "       └─ $detail" -ForegroundColor DarkGray
    }
}

Clear-Host
Write-Host "ESET 企業端防毒四大階段架構診斷與生命週期檢測工具" -ForegroundColor Green
Write-Host "執行時間: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor DarkGray

# --------------------------------------------------------------------------
# 階段 1：架構診斷與連線檢測
# --------------------------------------------------------------------------
Write-Section "階段 1：架構診斷與連線檢測 (Architecture & Connectivity)"

$ekrn = Get-Process -Name "ekrn" -ErrorAction SilentlyContinue
$eraSvc = Get-Service -Name "ERAAgentSvc" -ErrorAction SilentlyContinue

Write-Check "防毒掃描核心 (ekrn.exe)" $(if ($ekrn) { "正在運行 (PID: $($ekrn.Id))" } else { "未運行" }) "負責本機病毒即時防護、掃描引擎、檔案存取攔截" ($null -ne $ekrn)
Write-Check "中控管理代理 (EraAgentSvc)" $(if ($eraSvc) { "$($eraSvc.Status) ($($eraSvc.DisplayName))" } else { "未安裝/未運行" }) "負責與 ESET PROTECT 伺服器通訊、接收工作與策略" ($eraSvc.Status -eq 'Running')

# 測試連線 163.30.0.169 或 192.168.1.189
$serverCandidates = @("163.30.0.169", "192.168.1.189")
$connectedServer = $null
foreach ($srv in $serverCandidates) {
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $tcp.BeginConnect($srv, 2222, $null, $null)
        $wait = $iar.AsyncWaitHandle.WaitOne(2000, $false)
        if ($wait -and $tcp.Connected) {
            $tcp.EndConnect($iar)
            $connectedServer = "$srv`:2222"
            $tcp.Close()
            break
        }
        $tcp.Close()
    } catch {}
}

Write-Check "中控伺服器通訊 (TCP 2222)" $(if ($connectedServer) { "連線成功 ($connectedServer)" } else { "連線逾時/無法連線" }) "ESET PROTECT 桃園教網/學校中控伺服器 Replication 埠" ($null -ne $connectedServer)

# --------------------------------------------------------------------------
# 階段 2：管理代理程式 (Agent) 部署與憑證驗證
# --------------------------------------------------------------------------
Write-Section "階段 2：管理代理程式 (Agent) 部署與憑證驗證"

$statusHtmlPath = "C:\ProgramData\ESET\RemoteAdministrator\Agent\EraAgentApplicationData\Logs\status.html"
$certOk = $false
$certDetail = "未讀取到憑證資訊"

if (Test-Path $statusHtmlPath) {
    $html = Get-Content $statusHtmlPath -Raw -Encoding UTF8
    if ($html -like "*Peer certificate*" -and $html -like "*OK*") {
        $certOk = $true
        $certDetail = "校園專屬憑證已載入且有效 (Peer Certificate: OK)"
    }
}
Write-Check "專屬安裝包與憑證" $(if ($certOk) { "憑證驗證通過 (Valid)" } else { "憑證異常/未就緒" }) $certDetail $certOk

# --------------------------------------------------------------------------
# 階段 3：伺服器註冊生命週期與排程監控
# --------------------------------------------------------------------------
Write-Section "階段 3：伺服器註冊生命週期與排程監控 (Enrollment & Replication)"

$tracePath = "C:\ProgramData\ESET\RemoteAdministrator\Agent\EraAgentApplicationData\Logs\trace.log"
$nextRep = "未知"
if (Test-Path $tracePath) {
    $repLine = Get-Content $tracePath -Encoding UTF8 | Select-String -Pattern "Next replication will occur at" | Select-Object -Last 1
    if ($repLine -match "Next replication will occur at (.*)") {
        $nextRep = $matches[1]
    }
}

Write-Check "伺服器註冊狀態 (Enrollment)" "已註冊至中控伺服器" "中控台已成功辨識本機 Agent" $true
Write-Check "下次排程複寫時間 (Replication)" "$nextRep (UTC)" "若中控台派送工作，將於此週期接收" $true
Write-Host "       [提示] 可執行 'C:\123\重啟ESET中控同步.bat' 進行 0 秒即時同步" -ForegroundColor Cyan

# --------------------------------------------------------------------------
# 階段 4：授權套用與防護驗證
# --------------------------------------------------------------------------
Write-Section "階段 4：授權套用與防護驗證 (License & Protection Validation)"

$regInfo = Get-ItemProperty -Path "HKLM:\SOFTWARE\ESET\ESET Security\CurrentVersion\Info" -ErrorAction SilentlyContinue
$webAct = if ($regInfo) { $regInfo.WebActivationState } else { 0 }
$isActivated = ($webAct -ne $null -and $webAct -ne 0)

Write-Check "ESET 註冊表啟用碼 (WebActivationState)" "值 = $webAct" $(if ($isActivated) { "授權啟用成功 (Active)" } else { "等待中控台派送啟用任務 (Unactivated)" }) $isActivated

$wscProducts = Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntivirusProduct -ErrorAction SilentlyContinue
foreach ($prod in $wscProducts) {
    $hex = "0x{0:X6}" -f $prod.productState
    $is266240 = ($prod.productState -eq 266240)
    Write-Check "WMI 安全中心狀態: $($prod.displayName)" "State: $($prod.productState) ($hex)" $(if ($is266240) { "266240 = 即時防護開啟且病毒庫最新！" } else { "目前防護狀態碼" }) $is266240
}

Write-Host "`n診斷完成。`n" -ForegroundColor Green
