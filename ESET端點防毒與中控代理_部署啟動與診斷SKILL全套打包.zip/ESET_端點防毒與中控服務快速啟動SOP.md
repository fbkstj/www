# ESET 端點防毒與中控服務快速啟動與授權啟用 SOP 手冊

本手冊提供 **ESET Endpoint Antivirus** 與 **ESET Management Agent (EraAgentSvc)** 在各種環境（校內/企業內網、VPN 外網、服務掛起）下的 **快速啟動、強制同步與授權啟用標準流程**。

---

## 🎯 適用情境與對照表

| 使用情境 | 建議操作方式 | 預期結果 |
| :--- | :--- | :--- |
| **VPN 連線後防毒顯示未啟用 / 橘紅燈** | 執行 **一鍵重啟同步批次檔** | 1~2 分鐘內自動取得授權並轉為綠色正常狀態 |
| **開機後防毒圖示未出現 / 介面關閉** | 執行 **開啟 ESET 主程式介面** | 喚醒 `egui.exe` 並顯示操作介面 |
| **防毒服務被關閉 / 無法即時防護** | 執行 **PowerShell 啟動核心服務** | 重新啟動 `ekrn.exe` 與 `EraAgentSvc` |
| **連線異常 / 授權持續無法派發** | 執行 **四大階段診斷檢測** | 輸出各階層（服務、憑證、網路 TCP 2222）詳細診斷報告 |

---

## 🚀 一、 快速啟動與授權啟用操作 SOP

### 1. 一鍵強制重啟與授權同步（最推薦 / VPN外網0秒觸發）

當您在校外/家中連上 VPN 後，或剛安裝完防毒軟體需要**立即取得授權**時使用：

#### 🔹 方式 A：使用內建批次檔（最簡單）
1. 開啟專案資料夾：`j:\我的雲端硬碟\antigravity\ESET\`
2. 找到 [重啟ESET中控同步.bat](file:///j:/我的雲端硬碟/antigravity/ESET/重啟ESET中控同步.bat)
3. 點擊滑鼠右鍵 $\to$ 選擇 **「以系統管理員身分執行」**。

#### 🔹 方式 B：使用指令列 (CMD / PowerShell)
1. 按 <kbd>Win</kbd> + <kbd>X</kbd> 鍵，選擇 **「終端機 (管理員)」** 或 **「PowerShell (管理員)」**。
2. 貼上並執行以下指令：
```cmd
net stop EraAgentSvc && net start EraAgentSvc
```

> [!NOTE]
> 重啟 `EraAgentSvc` 後，Agent 會中斷休眠並**立即向中控伺服器（163.30.0.169:2222）發起 TCP 複寫**。約 1 ~ 2 分鐘內，右下角防毒圖示即會恢復綠色「您受到完整保護」。

---

### 2. 開啟 ESET 主程式桌面介面 (GUI)

若防毒軟體正常運行但右下角圖示未顯示，或需要開啟主視窗掃描：

1. 按 <kbd>Win</kbd> + <kbd>S</kbd> 搜尋 `ESET`，選擇 **ESET Endpoint Antivirus**。
2. 或按 <kbd>Win</kbd> + <kbd>R</kbd> 開啟「執行」視窗，貼上以下路徑回車：
```cmd
"C:\Program Files\ESET\ESET Security\egui.exe"
```

---

### 3. 透過 PowerShell 啟動全套核心服務

若系統服務遭誤關閉，可透過管理員 PowerShell 重新啟動全套防毒服務：

```powershell
# 1. 啟動防毒掃描與即時防護核心 (ekrn.exe)
Start-Service -Name "ekrn" -ErrorAction SilentlyContinue

# 2. 啟動中控通訊代理 (EraAgentSvc)
Start-Service -Name "EraAgentSvc"

# 3. 確認服務狀態
Get-Service -Name "ekrn", "EraAgentSvc" | Select-Object Name, DisplayName, Status
```

---

## 🩺 二、 快速診斷與健康檢查 SOP

若執行重啟後防毒軟體依然無法轉為綠色正常狀態，請執行專案診斷腳本：

### 執行階段診斷腳本
1. 以管理員開啟 PowerShell。
2. 執行 [check_eset_phases.ps1](file:///j:/我的雲端硬碟/antigravity/ESET/check_eset_phases.ps1) 診斷工具：
```powershell
powershell -ExecutionPolicy Bypass -File "j:\我的雲端硬碟\antigravity\ESET\check_eset_phases.ps1"
```

### 診斷重點指標說明
* **階段 1 (網絡與服務)**：`ekrn.exe` 運行中、`EraAgentSvc` 運行中、`TCP 2222` 通暢。
* **階段 2 (憑證)**：確認 `status.html` 顯示 `Peer Certificate: OK`。
* **階段 3 (同步時間)**：確認 `trace.log` 顯示已完成 `Replication`。
* **階段 4 (授權與防護)**：`WebActivationState` 為已啟用，WMI 狀態碼為 `266240` (綠色全防護)。

---

## 🛠️ 三、 系統檔案與 Log 關鍵路徑

維護或排錯時可調閱以下關鍵檔案路徑：

| 項目 | 檔案與目錄路徑 |
| :--- | :--- |
| **Agent 通訊狀態日誌** | `C:\ProgramData\ESET\RemoteAdministrator\Agent\EraAgentApplicationData\Logs\status.html` |
| **Agent 詳細診斷日誌** | `C:\ProgramData\ESET\RemoteAdministrator\Agent\EraAgentApplicationData\Logs\trace.log` |
| **防毒主程式 Log** | `C:\ProgramData\ESET\ESET Security\Logs\` |
| **專案監控輸出 Log** | [eset_monitor.log](file:///j:/我的雲端硬碟/antigravity/ESET/eset_monitor.log) |
| **重啟同步批次檔** | [重啟ESET中控同步.bat](file:///j:/我的雲端硬碟/antigravity/ESET/重啟ESET中控同步.bat) |
| **架構診斷腳本** | [check_eset_phases.ps1](file:///j:/我的雲端硬碟/antigravity/ESET/check_eset_phases.ps1) |

---

> [!IMPORTANT]
> **維護提醒**：在 VPN 外網環境下，必須確保 VPN 保持連線且路由正確，重啟中控同步服務方能成功連通中控台派發授權。
