﻿@echo off
chcp 65001 > nul
:: 自動取得系統管理員權限
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo 正在請求系統管理員權限...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
    if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
    pushd "%CD%"
    CD /D "%~dp0"

echo ==========================================================================
echo   [ESET Management Agent] 正在強制重啟服務以進行 0 秒即時中控同步...
echo ==========================================================================

net stop EraAgentSvc
timeout /t 3 /nobreak > nul
net start EraAgentSvc

echo.
echo ==========================================================================
echo   服務重啟完成！正在檢測啟用狀態與通訊...
echo ==========================================================================
powershell -ExecutionPolicy Bypass -File "C:\123\check_eset_phases.ps1"
pause
