@echo off
title AI Chrome Launcher
echo ========================================================
echo   Starting AI Study Chrome (Port 9222)...
echo ========================================================
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --user-data-dir="%LOCALAPPDATA%\Google\Chrome\AI_Profile" "https://elearning.taipei/mpage/"
echo [OK] Chrome started! Please log in and open your course.
pause
