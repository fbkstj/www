@echo off
chcp 65001 >nul
title 教學影片自動化：上傳 YouTube
cd /d "%~dp0"
if not exist yt_token.json (
  echo 第一次使用：先授權 YouTube 帳號...
  python youtube_auth.py
)
echo 先列出要上傳的內容：
python upload.py --dry-run
echo.
set /p OK=確定要上傳嗎？（輸入 y 後按 Enter）：
if /i not "%OK%"=="y" exit /b 0
python upload.py
pause
