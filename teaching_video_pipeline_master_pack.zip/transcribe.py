"""階段二：語音辨識（Faster-Whisper）→ 逐字時間戳 → 台灣繁體

防止「重複幻覺」（字幕一直重複同一句、或把提示詞當成字幕）的關鍵設定：
  condition_on_previous_text=False   不讓上一段的結果影響下一段（最重要，錯一次不會一路錯下去）
  vad_filter=True                    先把沒講話的部分濾掉，Whisper 就不會對著空白亂編
  hallucination_silence_threshold    講話中間有長停頓時，跳過可能是幻覺的片段（需要 word_timestamps）
  compression_ratio_threshold 2.4    一段文字重複度太高（像在跳針）就重試或丟掉
  initial_prompt 要短               只放一句情境；專有名詞改放 hotwords
注意：compute_type 用 int8 或 float16 只影響速度和記憶體，跟幻覺無關。

用法：
  python transcribe.py                 全部集數
  python transcribe.py --episodes 1,3  只做第 1、3 集
  python transcribe.py --force         已經有結果也重做
  python transcribe.py --model small   臨時換模型（測試用）
"""
import argparse
import json
import os
import time

from common import load_config, out, pick_episodes, source_video

PROMPT_LEAK_MARKERS = ("專有名詞：", "這是台灣高職")


def load_model(wcfg, model_override=None):
    from faster_whisper import WhisperModel
    name = model_override or wcfg.get("model", "medium")
    device = wcfg.get("device", "auto")
    if device in ("auto", "cuda"):
        try:
            m = WhisperModel(name, device="cuda", compute_type="float16")
            print(f"[Whisper] {name}，使用 GPU（float16）")
            return m
        except Exception as e:
            if device == "cuda":
                raise
            print(f"[Whisper] 沒有可用的 GPU（{str(e)[:60]}），改用 CPU")
    m = WhisperModel(name, device="cpu", compute_type="int8")
    print(f"[Whisper] {name}，使用 CPU（int8；只影響速度，不影響準確度）")
    return m


def transcribe_file(model, path, wcfg, converter):
    segments, info = model.transcribe(
        path,
        language=wcfg.get("language", "zh"),
        beam_size=wcfg.get("beam_size", 5),
        initial_prompt=wcfg.get("initial_prompt") or None,
        hotwords=wcfg.get("hotwords") or None,
        condition_on_previous_text=False,
        word_timestamps=True,                 # 沒開就拿不到逐字時間，字幕只能用猜的切
        vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=1000, speech_pad_ms=400),
        hallucination_silence_threshold=2.0,
        compression_ratio_threshold=2.4,
        no_speech_threshold=0.6,
    )
    data, recent = [], []
    t0 = time.time()
    for s in segments:
        text = converter.convert(s.text.strip()) if converter else s.text.strip()
        if not text:
            continue
        if any(m in text for m in PROMPT_LEAK_MARKERS):      # 提示詞被當成字幕吐出來
            continue
        if recent.count(text) >= 2:                          # 同一句連續出現第三次＝跳針
            continue
        recent = (recent + [text])[-3:]
        words = [{"start": round(w.start, 2), "end": round(w.end, 2),
                  "word": converter.convert(w.word) if converter else w.word}
                 for w in (s.words or [])]
        data.append({"start": round(s.start, 2), "end": round(s.end, 2), "text": text, "words": words})
        if info.duration:
            print(f"\r   進度 {s.end / info.duration * 100:5.1f}%（{s.end:7.1f}/{info.duration:.0f} 秒，"
                  f"已花 {time.time() - t0:.0f} 秒）", end="", flush=True)
    print()
    return data, info


def run(cfg, selector=None, force=False, model_override=None):
    wcfg = cfg.get("whisper", {})
    converter = None
    if wcfg.get("opencc"):
        import opencc
        converter = opencc.OpenCC(wcfg["opencc"])
    model = None
    results = {}
    for ep in pick_episodes(cfg, selector):
        path = source_video(cfg, ep)
        json_path = out(cfg, "transcriptions", f"{ep['id']}.json")
        if os.path.exists(json_path) and not force:
            print(f"[{ep['id']}] 已有辨識結果，略過（要重做加 --force）")
            results[ep["id"]] = json_path
            continue
        if not os.path.exists(path):
            print(f"[{ep['id']}] 找不到影片：{path}")
            continue
        model = model or load_model(wcfg, model_override)
        print(f"[{ep['id']}] 辨識中：{os.path.basename(path)}")
        t0 = time.time()
        data, info = transcribe_file(model, path, wcfg, converter)
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump({"source": path, "duration": info.duration, "segments": data}, f, ensure_ascii=False, indent=1)
        words = sum(len(s["words"]) for s in data)
        print(f"[{ep['id']}] 完成：{len(data)} 段、{words} 個字詞，花 {time.time() - t0:.0f} 秒 → {json_path}")
        if not data:
            print(f"[{ep['id']}] 警告：沒有任何字幕！請先用 30 秒的片段測試音量與參數")
        results[ep["id"]] = json_path
    return results


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--episodes")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--model")
    a = ap.parse_args()
    run(load_config(a.config), a.episodes, a.force, a.model)


if __name__ == "__main__":
    main()
