"""共用工具：讀設定檔、路徑、時間格式、執行 ffmpeg。

所有課程相關的東西（影片檔名、標題、日期、術語）都寫在 config.json，
程式本身不寫死任何一門課，換一門課只要換設定檔。
"""
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

if hasattr(sys.stdout, "reconfigure"):          # Windows 終端機預設 cp950，改成 UTF-8 才印得出所有字
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass


def load_config(path=None):
    path = path or os.path.join(HERE, "config.json")
    if not os.path.exists(path):
        raise SystemExit(f"找不到設定檔 {path}（可以複製 config.example.json 改名成 config.json）")
    with open(path, encoding="utf-8") as f:
        cfg = json.load(f)
    base = os.path.dirname(os.path.abspath(path))
    cfg["_config_dir"] = base
    cfg["course_dir"] = os.path.abspath(os.path.join(base, cfg.get("course_dir", ".")))
    cfg["output_dir"] = os.path.abspath(os.path.join(cfg["course_dir"], cfg.get("output_dir", "output")))
    for sub in ("transcriptions", "subtitles", "covers", "final_videos", "trimmed", "logs"):
        os.makedirs(os.path.join(cfg["output_dir"], sub), exist_ok=True)
    for i, ep in enumerate(cfg.get("episodes", []), 1):
        ep.setdefault("id", f"ep{i:02d}")
    return cfg


def out(cfg, *parts):
    return os.path.join(cfg["output_dir"], *parts)


def source_video(cfg, ep):
    """如果做過靜音裁切，就用裁切後的版本。"""
    trimmed = out(cfg, "trimmed", f"{ep['id']}_trimmed.mp4")
    if os.path.exists(trimmed):
        return trimmed
    return os.path.join(cfg["course_dir"], ep["file"])


def pick_episodes(cfg, selector):
    """selector：None＝全部；'1,3' 或 'ep01,ep03'。"""
    eps = cfg.get("episodes", [])
    if not selector:
        return eps
    want = set()
    for s in selector.split(","):
        s = s.strip()
        want.add(f"ep{int(s):02d}" if s.isdigit() else s)
    return [e for e in eps if e["id"] in want]


def srt_time(t):
    t = max(0.0, t)
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def ass_time(t):
    t = max(0.0, t)
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360_000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def need_ffmpeg():
    for tool in ("ffmpeg", "ffprobe"):
        if not shutil.which(tool):
            raise SystemExit(f"找不到 {tool}：請安裝 FFmpeg（winget install Gyan.FFmpeg），並重開終端機")


def run_ffmpeg(args, log_path=None, cwd=None):
    """執行 ffmpeg；失敗時把最後 20 行錯誤印出來（舊版把錯誤都丟掉，壓壞了也不知道）。"""
    cmd = ["ffmpeg", "-hide_banner", "-y"] + args
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if log_path:
        with open(log_path, "w", encoding="utf-8") as f:
            f.write(" ".join(cmd) + "\n\n" + r.stderr)
    if r.returncode != 0:
        tail = "\n".join(r.stderr.strip().splitlines()[-20:])
        raise RuntimeError(f"ffmpeg 失敗（完整紀錄：{log_path}）\n{tail}")
    return r


def probe(path):
    """回傳 (影片秒數, 有沒有聲音, 寬, 高, fps)。"""
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                        "format=duration:stream=codec_type,width,height,avg_frame_rate",
                        "-of", "json", path], capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0:
        raise RuntimeError(f"讀不到影片資訊：{path}\n{r.stderr[-500:]}")
    info = json.loads(r.stdout)
    dur = float(info["format"]["duration"])
    streams = info.get("streams", [])
    has_audio = any(s.get("codec_type") == "audio" for s in streams)
    v = next((s for s in streams if s.get("codec_type") == "video"), {})
    fps = 0.0
    if v.get("avg_frame_rate", "0/0") != "0/0":
        a, b = v["avg_frame_rate"].split("/")
        fps = float(a) / float(b) if float(b) else 0.0
    return dur, has_audio, v.get("width", 0), v.get("height", 0), fps
