﻿憑證檔說明
==========
本技能包不附 client_secrets.json 與 yt_token.json（個人 YouTube API 憑證，等於密碼，不可公開）。

1. 到 Google Cloud Console 建立專案，啟用「YouTube Data API v3」。
2. 設定 OAuth 同意畫面：
   - 發布狀態若是「測試中（Testing）」，授權 7 天後一定失效；自用建議改成「正式發布（In production）」。
     正式發布但未送審時，授權畫面會出現「Google 尚未驗證這個應用程式」，按「進階 → 前往」即可（上限 100 位使用者）。
3. 建立 OAuth 用戶端 ID，類型選「桌面應用程式」，下載 JSON，改名為 client_secrets.json，放在與腳本相同的資料夾。
4. 執行 python youtube_auth.py，瀏覽器授權後會自動產生 yt_token.json。
   瀏覽器開不起來時用 python youtube_auth.py --manual。
5. 注意：2020/7/28 之後建立、且未通過 YouTube API 稽核的專案，用 API 上傳的影片會被鎖成「私人」。
   要公開或不公開發布，請申請 API 稽核，或上傳後到 YouTube 工作室手動確認。

這兩個檔案請勿上傳到 GitHub、放進壓縮檔或分享給他人。
