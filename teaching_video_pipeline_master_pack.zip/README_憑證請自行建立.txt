﻿憑證檔說明
==========
本技能包不附 client_secrets.json 與 yt_token.json（個人 YouTube API 憑證，不可公開）。
請到 Google Cloud Console 建立自己的 OAuth 用戶端（桌面應用程式），下載後命名為 client_secrets.json，
放在與腳本相同的資料夾。第一次執行上傳腳本時會開瀏覽器授權，並自動產生 yt_token.json。
這兩個檔案請勿上傳到 GitHub 或分享給他人。
