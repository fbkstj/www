@echo off
chcp 65001 >nul
title 教學影片自動化：辨識、字幕、壓製
cd /d "%~dp0"
if not exist config.json (
  echo 找不到 config.json：請先把 config.example.json 複製一份改名成 config.json，填好影片資料夾與集數
  pause
  exit /b 1
)
echo [1/2] 檢查套件...
python -m pip install -q -r requirements.txt
echo [2/2] 開始處理（不會自動上傳）...
python run_pipeline.py %*
echo.
echo 完成。請先看過 output\final_videos 的影片與 output\subtitles 的字幕，確認後再雙擊「2_上傳YouTube.bat」
pause
