---
name: teaching-video-pipeline
description: >-
  教學影片後製與 YouTube 發布：長時間空白偵測（先報告再裁切）、Faster-Whisper 語音辨識（防重複幻覺、
  逐字時間戳、專有名詞 hotwords、台灣繁體）、單行字幕重組（不重疊、不超寬）、1080p 片頭圖卡、
  FFmpeg 壓製（CC 或燒字幕）、YouTube API 上傳＋CC 字幕＋播放清單（可續傳、可中斷再跑）。
  使用者說「剪課程影片」「上字幕」「上傳 YouTube」「做成播放清單」時使用。
---

# 教學影片後製與 YouTube 發布（Teaching Video Pipeline）

所有課程資料都寫在 `config.json`（從 `config.example.json` 複製），程式不寫死任何一門課。

## 流程與腳本

| 階段 | 腳本 | 產出 |
|---|---|---|
| 1. 長空白偵測（選用） | `trim_silence.py`（預設只出報告，`--apply` 才裁切） | `output/trimmed/epXX_trimmed.mp4` |
| 2. 語音辨識 | `transcribe.py` | `output/transcriptions/epXX.json`（含逐字時間） |
| 3. 單行字幕 | `subtitles.py` | `epXX.srt`（已加片頭秒數，給 CC）、`epXX.ass`（未加，燒字幕用） |
| 4. 片頭＋壓製 | `render.py` | `output/final_videos/epXX_final.mp4`（或 `_burned.mp4`） |
| 5. 上傳 | `upload.py`（先 `--dry-run`） | YouTube 影片、CC、播放清單；狀態記在 `output/uploads.json` |
| 授權 | `youtube_auth.py`（`--manual` 備用） | `yt_token.json` |
| 一鍵 | `run_pipeline.py`（預設不上傳） | 以上 1～4 |

```powershell
python run_pipeline.py --episodes 1        # 第一次先做一集
python run_pipeline.py                     # 全部
python upload.py --dry-run; python upload.py
python tests/test_subtitles.py             # 字幕規則自我測試（21 項）
python tests/smoke_test.py                 # 端到端測試：自己產生假課程影片跑完整流程（11 項）
```

## 必須遵守的規則（都是實際踩過的坑）

1. **語音辨識防幻覺**：`condition_on_previous_text=False`、`vad_filter=True`、`word_timestamps=True`、
   `hallucination_silence_threshold`、`compression_ratio_threshold=2.4`。`initial_prompt` 只放一句情境，
   專有名詞放 `hotwords`。int8／float16 只影響速度，與幻覺無關。新設定先拿 30 秒片段測試。
2. **字幕永遠單行且不重疊**：寬度上限 `max_chars`（英數算半形），停留時間跟著講話走
   （`min_duration`～`max_duration`、每秒不超過 `max_cps` 字），延長時絕不蓋到下一句；
   被寬度逼著斷行時往回找標點或停頓，不把詞切開。ASS 加 `WrapStyle: 2`。
3. **片頭秒數只加一次**：SRT 對齊成品（已加片頭），ASS 對齊原始影片，在接片頭「之前」燒進去。
4. **壓製一律重新編碼並統一規格**：1920×1080、`setsar=1`、`fps=30` 固定影格率、48 kHz 雙聲道；
   片頭要有靜音音軌；最終版 `preset medium`、`yuv420p`、`+faststart`。不可用 `-c copy` 在非關鍵影格切。
5. **不要一律剪掉沒聲音的片段**：可能在寫板書或示範操作。只抓長空白（預設 8 秒），先看報告再 `--apply`。
6. **字幕二選一**：`subtitle_mode=cc`（建議，可搜尋可關閉）或 `burn`；兩者都做觀眾開 CC 會看到兩份。
7. **OAuth**：同意畫面在「測試中」時 refresh token 7 天失效，程式自動續期救不了，要改成「正式發布」。
   正式發布後仍可能因撤銷、半年未用而失效，屆時執行 `youtube_auth.py`。
8. **YouTube API 稽核**：2020/7/28 後建立、未通過稽核的專案，API 上傳的影片會被鎖成私人；
   `upload.py` 上傳後會檢查並提醒。每日配額預設 10,000 單位，上傳最耗，超過隔天再跑（已上傳的不會重傳）。
9. **憑證**：`client_secrets.json`、`yt_token.json` 等於密碼，不可放進 zip、GitHub、報告。

## 交付前檢查

- `subtitles.py` 報告「重疊 0 處、超寬 0 行」
- `render.py` 報告成品長度＝片頭＋正片
- 抽看成品：片頭、第一句字幕出現的時間、中段、結尾各一處
- 上傳前 `upload.py --dry-run`
