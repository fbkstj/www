"""階段一（選用）：找出長時間沒聲音的片段，先出報告，確認後才裁切

為什麼預設只出報告？
  課堂影片「沒聲音」不等於「沒內容」：老師可能在寫板書、學生在操作、畫面在示範。
  所以只抓很長的空白（預設 8 秒以上），列出時間點讓你先看過；確定要剪再加 --apply。

裁切一定「重新編碼」並鎖定固定影格率（fps=30）：
  用 -c copy 在非關鍵影格的位置切，會造成聲音和畫面不同步；
  沒鎖定影格率，多次重新編碼後畫面會慢慢落後聲音。

用法：
  python trim_silence.py                     每集列出可以剪的空白（不改任何檔案）
  python trim_silence.py --episodes 3 --apply   確認後真的剪，產生 output/trimmed/ep03_trimmed.mp4
  python trim_silence.py --min-silence 5        改成 5 秒以上就算
之後的辨識、壓製都會自動改用裁切後的檔案。
"""
import argparse
import json
import os
import re
import subprocess

from common import load_config, need_ffmpeg, out, pick_episodes, probe, run_ffmpeg


def detect_silences(path, noise_db, min_silence):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-vn",
                        "-af", f"silencedetect=noise={noise_db}dB:d={min_silence}", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    starts = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", r.stderr)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r.stderr)]
    dur = probe(path)[0]
    if len(ends) < len(starts):              # 影片最後一段是空白
        ends.append(dur)
    return [(max(0.0, a), b) for a, b in zip(starts, ends)], dur


def keep_ranges(silences, dur, pad):
    """把要保留的區段算出來：空白頭尾各留 pad 秒，聽起來才不會太突兀。"""
    keeps, cur = [], 0.0
    for a, b in silences:
        cut_a, cut_b = a + pad, b - pad
        if cut_b - cut_a <= 0.2:
            continue
        if cut_a > cur:
            keeps.append((cur, cut_a))
        cur = cut_b
    if cur < dur:
        keeps.append((cur, dur))
    return keeps


def apply_trim(src, dst, keeps, fps, log):
    expr = "+".join(f"between(t,{a:.3f},{b:.3f})" for a, b in keeps)
    vf = f"fps={fps},select='{expr}',setpts=N/({fps}*TB)"
    af = f"aselect='{expr}',asetpts=N/SR/TB"
    run_ffmpeg(["-i", src, "-vf", vf, "-af", af, "-c:v", "libx264", "-preset", "medium", "-crf", "18",
                "-pix_fmt", "yuv420p", "-r", str(fps), "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
                "-movflags", "+faststart", dst], log_path=log)


def fmt(t):
    return f"{int(t // 60):02d}:{t % 60:05.2f}"


def run(cfg, selector=None, apply=False, min_silence=None):
    need_ffmpeg()
    tcfg = cfg.get("trim", {})
    noise = tcfg.get("noise_db", -35)
    min_s = min_silence or tcfg.get("min_silence", 8.0)
    pad = tcfg.get("keep_pad", 0.5)
    fps = cfg.get("render", {}).get("fps", 30)
    report = {}
    for ep in pick_episodes(cfg, selector):
        src = os.path.join(cfg["course_dir"], ep["file"])
        if not os.path.exists(src):
            print(f"[{ep['id']}] 找不到影片：{src}")
            continue
        silences, dur = detect_silences(src, noise, min_s)
        keeps = keep_ranges(silences, dur, pad)
        kept = sum(b - a for a, b in keeps)
        print(f"[{ep['id']}] 影片 {fmt(dur)}，找到 {len(silences)} 段 {min_s:g} 秒以上的空白，"
              f"剪掉後約 {fmt(kept)}（少 {dur - kept:.0f} 秒）")
        for a, b in silences:
            print(f"     {fmt(a)} ～ {fmt(b)}（{b - a:.1f} 秒）  ← 請先看這段畫面有沒有板書或示範")
        report[ep["id"]] = {"duration": dur, "silences": silences, "keep": keeps}
        if apply and silences:
            dst = out(cfg, "trimmed", f"{ep['id']}_trimmed.mp4")
            print(f"[{ep['id']}] 裁切並重新編碼中（fps={fps}）…")
            apply_trim(src, dst, keeps, fps, out(cfg, "logs", f"{ep['id']}_trim.log"))
            new_dur = probe(dst)[0]
            print(f"[{ep['id']}] 完成：{dst}（{fmt(new_dur)}；預期 {fmt(kept)}）")
    with open(out(cfg, "logs", "trim_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=1)
    if not apply:
        print("\n（只是報告，沒有改任何檔案。確認後加 --apply 才會真的剪）")
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--episodes")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--min-silence", type=float)
    a = ap.parse_args()
    run(load_config(a.config), a.episodes, a.apply, a.min_silence)


if __name__ == "__main__":
    main()
