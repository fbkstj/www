"""端到端測試：自己做一段「假的上課影片」，把整條流程跑一遍（不會上傳 YouTube）

做法：
  1. 用 Windows 內建的中文語音（SAPI）念兩段課程內容，中間空白 10 秒
  2. 用 ffmpeg 做一段 1280×720 的測試畫面，合成 lecture.mp4（故意不是 1920×1080，測試縮放）
  3. 依序執行：靜音裁切 → 語音辨識 → 單行字幕 → 片頭＋壓製（CC 版與燒字幕版）→ 上傳試跑
  4. 檢查：裁切後少了約 9 秒、辨識得到字、字幕不重疊不超寬、成品長度＝片頭＋正片、
          燒字幕版在字幕時間點畫面底部真的有字、CC 版沒有

執行：python tests/smoke_test.py            （用 small 模型，約 1～3 分鐘）
     python tests/smoke_test.py --model medium
需要：ffmpeg、faster-whisper、Windows（產生語音用）
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import render  # noqa: E402
import subtitles  # noqa: E402
import transcribe  # noqa: E402
import trim_silence  # noqa: E402
import upload  # noqa: E402
from common import load_config, probe  # noqa: E402

TEXT1 = "各位同學好，今天我們要用 Python 和 Arduino 做一個物聯網專題。首先打開電腦，安裝開發環境，接著把 ESP32 開發板接上 USB。"
TEXT2 = "接下來我們請生成式 AI 幫忙寫程式，再把程式上傳到開發板，最後檢查序列埠的輸出結果。"
results = []


def ok(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(f"[{'OK' if cond else 'FAIL'}] {name}：{detail}")


def tts(text, wav):
    ps = ("Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
          "$v = $s.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Culture.Name -like 'zh-*' } | Select-Object -First 1; "
          "if ($v) { $s.SelectVoice($v.VoiceInfo.Name) }; $s.Rate = 0; "
          f"$s.SetOutputToWaveFile('{wav}'); $s.Speak([IO.File]::ReadAllText('{wav}.txt')); $s.Dispose()")
    with open(wav + ".txt", "w", encoding="utf-8") as f:
        f.write(text)
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True)
    return r.returncode == 0 and os.path.exists(wav) and os.path.getsize(wav) > 1000


def bottom_white(path, t):
    """抓 t 秒那一張，算畫面底部（字幕區）白色像素的比例。"""
    r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.2f}", "-i", path, "-frames:v", "1",
                        "-vf", "crop=1920:140:0:1080-160,format=gray", "-f", "rawvideo", "-"], capture_output=True)
    data = r.stdout
    return sum(1 for b in data if b > 235) / max(1, len(data))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="small")
    ap.add_argument("--keep", action="store_true", help="保留暫存資料夾")
    a = ap.parse_args()
    if not shutil.which("ffmpeg"):
        print("需要 ffmpeg")
        return 1
    work = tempfile.mkdtemp(prefix="tvp_smoke_")
    course = os.path.join(work, "course")
    os.makedirs(course)
    print("暫存資料夾：", work)

    # ---- 1～2. 做假影片 ----
    w1, w2 = os.path.join(work, "a.wav"), os.path.join(work, "b.wav")
    if not (tts(TEXT1, w1) and tts(TEXT2, w2)):
        print("無法產生中文語音（需要 Windows 與中文語音包），測試中止")
        return 1
    audio = os.path.join(work, "speech.wav")
    subprocess.run(["ffmpeg", "-hide_banner", "-v", "error", "-y", "-i", w1, "-i", w2, "-filter_complex",
                    "[0:a]aresample=48000,apad=pad_dur=10[a0];[1:a]aresample=48000[a1];[a0][a1]concat=n=2:v=0:a=1,"
                    "pan=stereo|c0=c0|c1=c0[a]", "-map", "[a]", audio], check=True)
    adur = probe(audio)[0]
    lecture = os.path.join(course, "lecture.mp4")
    subprocess.run(["ffmpeg", "-hide_banner", "-v", "error", "-y", "-f", "lavfi", "-i",
                    f"testsrc2=size=1280x720:rate=30:duration={adur:.2f}", "-i", audio,
                    "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", lecture],
                   check=True)
    src_dur = probe(lecture)[0]
    print(f"假影片 {src_dur:.1f} 秒（中間有 10 秒空白）")

    cfg_path = os.path.join(work, "config.json")
    example = json.load(open(os.path.join(ROOT, "config.example.json"), encoding="utf-8"))
    example.update({"course_dir": "course", "course_name": "測試課程", "course_tag": "流程測試", "date": "測試日",
                    "episodes": [{"file": "lecture.mp4", "title": "【測試】第 01 集：物聯網專題入門",
                                  "short_title": "第 01 集：物聯網專題入門", "description": "測試"}]})
    example["whisper"]["model"] = a.model
    example["whisper"]["device"] = "cpu"
    example["trim"].update({"enabled": True, "min_silence": 5.0, "keep_pad": 0.5})
    json.dump(example, open(cfg_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    cfg = load_config(cfg_path)

    # ---- 3. 流程 ----
    rep = trim_silence.run(cfg, apply=True)
    tdur = probe(os.path.join(cfg["output_dir"], "trimmed", "ep01_trimmed.mp4"))[0]
    ok("靜音裁切", len(rep["ep01"]["silences"]) == 1 and 8.0 <= src_dur - tdur <= 10.0,
       f"原本 {src_dur:.1f} 秒 → {tdur:.1f} 秒（少 {src_dur - tdur:.1f} 秒，預期約 9 秒）")
    fps = probe(os.path.join(cfg["output_dir"], "trimmed", "ep01_trimmed.mp4"))[4]
    ok("裁切後固定 30 fps", abs(fps - 30) < 0.01, f"{fps:.2f} fps")

    transcribe.run(cfg, model_override=a.model)
    data = json.load(open(os.path.join(cfg["output_dir"], "transcriptions", "ep01.json"), encoding="utf-8"))
    text = "".join(s["text"] for s in data["segments"])
    words = sum(len(s["words"]) for s in data["segments"])
    hits = [k for k in ("Python", "Arduino", "物聯網", "開發板", "程式") if k.lower() in text.lower()]
    ok("語音辨識有結果", len(text) > 30 and words > 20, f"{len(text)} 字、{words} 個逐字時間")
    ok("專有名詞", len(hits) >= 3, f"辨識到 {hits}")
    ok("繁體中文", "开发" not in text and "程序" not in text, text[:60] + "…")

    done = subtitles.run(cfg)
    st = done["ep01"][2]
    ok("字幕不重疊、不超寬", st["overlaps"] == 0 and st["too_wide"] == 0 and st["lines"] >= 4, str(st))
    srt = open(done["ep01"][0], encoding="utf-8").read()
    first_srt = srt.split("\n")[1].split(" --> ")[0]
    ass_lines = [l for l in open(done["ep01"][1], encoding="utf-8-sig") if l.startswith("Dialogue")]
    first_ass = ass_lines[0].split(",")[1]
    ok("SRT 已加片頭秒數、ASS 沒加", first_srt[:8] >= "00:00:04" and first_ass.startswith("0:00:0"),
       f"SRT 第一句 {first_srt}；ASS 第一句 {first_ass}")

    cc = render.run(cfg, mode="cc")["ep01"]
    burn = render.run(cfg, mode="burn")["ep01"]
    for name, path in (("CC 版", cc), ("燒字幕版", burn)):
        d, has_a, w, h, f = probe(path)
        ok(f"{name}長度與規格", abs(d - (tdur + 4.0)) < 0.5 and (w, h) == (1920, 1080) and abs(f - 30) < 0.01 and has_a,
           f"{d:.1f} 秒（預期 {tdur + 4:.1f}）、{w}x{h}、{f:.0f} fps")

    # 第一句字幕中間的時間點：燒字幕版底部要有白字、CC 版沒有；片頭期間兩者都沒有
    h_, m_, rest = first_ass.split(":")
    t_first = int(h_) * 3600 + int(m_) * 60 + float(rest)
    end_parts = ass_lines[0].split(",")[2].split(":")
    t_end = int(end_parts[0]) * 3600 + int(end_parts[1]) * 60 + float(end_parts[2])
    t_check = 4.0 + (t_first + t_end) / 2
    wb, wc, wi = bottom_white(burn, t_check), bottom_white(cc, t_check), bottom_white(burn, 2.0)
    ok("燒字幕時間對齊", wb > 0.01 and wc < wb / 3 and wi < 0.01,
       f"第 {t_check:.1f} 秒：燒字幕版白色 {wb:.3f}、CC 版 {wc:.3f}；片頭第 2 秒 {wi:.3f}")

    upload.run(cfg, dry_run=True)
    ok("上傳試跑", True, "只列出計畫，沒有連線")

    fails = [r for r in results if not r[1]]
    print(f"\n總結：OK {len(results) - len(fails)}、FAIL {len(fails)}")
    if a.keep or fails:
        print("暫存資料夾保留在：", work)
    else:
        shutil.rmtree(work, ignore_errors=True)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
