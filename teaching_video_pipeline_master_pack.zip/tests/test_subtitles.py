"""字幕重組規則的自我測試（不用影片、不用模型）。執行：python tests/test_subtitles.py"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from subtitles import build_lines, check_lines, clean_text, width  # noqa: E402

RULES = {"max_chars": 20, "min_duration": 1.2, "max_duration": 6.0, "max_cps": 8, "gap_split": 0.8,
         "replacements": {"拍森": "Python"}}
passed, failed = 0, []


def check(name, cond, detail=""):
    global passed
    if cond:
        passed += 1
    else:
        failed.append(f"{name} {detail}")


def seg_from_text(text, start, per_char=0.2, gap_after=None):
    """做一段假的辨識結果：每個字 per_char 秒。"""
    words, t = [], start
    for ch in text:
        words.append({"word": ch, "start": round(t, 3), "end": round(t + per_char, 3)})
        t += per_char
    return {"start": start, "end": t, "text": text, "words": words}


# 1. 舊版的問題：很多短碎句、硬拉到 3 秒 → 會和下一句重疊
old_bug = [seg_from_text("好", 0.0), seg_from_text("我們來看", 0.4), seg_from_text("這個電路", 1.4),
           seg_from_text("接地", 2.4), seg_from_text("然後", 3.0)]
lines = build_lines(old_bug, RULES)
st = check_lines(lines, RULES)
check("碎句不重疊", st["overlaps"] == 0, str(st))

# 2. 長句一定切成多行，而且每行不超寬
long_text = "今天我們要介紹如何使用生成式人工智慧來協助撰寫程式並且自動產生測試資料與報告格式"
lines = build_lines([seg_from_text(long_text, 0.0, 0.15)], RULES)
st = check_lines(lines, RULES)
check("長句切多行", st["lines"] >= 2, str(st))
check("每行不超寬", st["too_wide"] == 0, str(st))
check("長句不重疊", st["overlaps"] == 0, str(st))
check("文字沒有遺失", "".join(l["text"] for l in lines) == long_text, str([l["text"] for l in lines]))

# 3. 停頓超過 gap_split 一定斷開
lines = build_lines([seg_from_text("第一句話", 0.0), seg_from_text("第二句話", 3.0)], RULES)
check("停頓會斷句", len(lines) == 2, str(lines))

# 4. 短句至少停留 min_duration，但不能蓋到下一句
lines = build_lines([seg_from_text("好的", 0.0, 0.2), seg_from_text("下一個", 1.5, 0.2)], RULES)
check("最短停留", round(lines[0]["end"] - lines[0]["start"], 2) >= 1.2, str(lines))
check("延長不蓋到下一句", lines[0]["end"] <= lines[1]["start"], str(lines))

# 5. 下一句緊接著來：寧可短一點也不能重疊
lines = build_lines([seg_from_text("這是一句已經快要到達寬度上限的句子", 0.0, 0.05),
                     seg_from_text("緊接著下一句", 0.9, 0.2)], RULES)
check("第二句另起一行", len(lines) == 2, str(lines))
check("緊接時不重疊", lines[0]["end"] <= lines[1]["start"], str(lines))

# 6. 在標點斷句，句尾標點去掉、句中逗號變空白
seg = seg_from_text("首先打開軟體，接著建立新專案。然後選擇開發板型號，", 0.0, 0.18)
lines = build_lines([seg], RULES)
check("標點處斷句", lines[0]["text"].startswith("首先打開軟體") and len(lines) >= 2, str([l["text"] for l in lines]))
check("句尾標點去掉", all(l["text"][-1] not in "，。" for l in lines), str([l["text"] for l in lines]))
check("問號保留", clean_text("這樣對嗎？", {}) == "這樣對嗎？")

# 7. 英文單字之間要有空白、寬度算半形
words = [{"word": w, "start": i * 0.4, "end": i * 0.4 + 0.35} for i, w in enumerate(["用", " Python", " and", " ESP32"])]
lines = build_lines([{"start": 0, "end": 1.6, "text": "", "words": words}], RULES)
check("英文有空白", lines[0]["text"] == "用 Python and ESP32", repr(lines[0]["text"]))
check("英文算半形", width("Python") < 4)

# 8. 同音字替換
lines = build_lines([seg_from_text("學拍森很簡單", 0.0)], RULES)
check("同音字替換", "Python" in lines[0]["text"], lines[0]["text"])

# 9. 沒有逐字時間也能用（按字數平均分配）
lines = build_lines([{"start": 0.0, "end": 8.0, "text": "這一段沒有逐字時間戳記但是還是要能夠正確切成單行字幕才行", "words": []}], RULES)
st = check_lines(lines, RULES)
check("沒有逐字時間也能切", st["lines"] >= 2 and st["too_wide"] == 0 and st["overlaps"] == 0, str(st))

# 10. 超長英文詞串硬切
w = [{"word": " Supercalifragilisticexpialidocious_and_more_letters_here", "start": 0, "end": 3}]
lines = build_lines([{"start": 0, "end": 3, "text": "", "words": w}], RULES)
check("超長詞硬切", check_lines(lines, RULES)["too_wide"] == 0, str(lines))

# 11. 小模型的半形逗號也要處理
check("半形逗號", clean_text("安裝開發環境,接著接上開發板,", {}) == "安裝開發環境　接著接上開發板", repr(clean_text("安裝開發環境,接著接上開發板,", {})))

# 12. 同一個英文字被拆成好幾塊時不能插空白（ESP32 不能變 ES P 32），中英交界要有空白
words = [{"word": w, "start": i * 0.3, "end": i * 0.3 + 0.28} for i, w in enumerate(["把", " ES", "P", "32", "接上", " USB"])]
lines = build_lines([{"start": 0, "end": 2, "text": "", "words": words}], RULES)
check("ESP32 不拆開", lines[0]["text"] == "把 ESP32 接上 USB", repr(lines[0]["text"]))

# 13. 被寬度逼著斷行時，往回找標點斷，不要把詞切開、留下很短的尾巴
seg = seg_from_text("再把程式上傳到開發板，最後檢查序列埠的輸出結果", 0.0, 0.2)
lines = build_lines([seg], RULES)
texts = [l["text"] for l in lines]
check("回頭找標點斷行", texts == ["再把程式上傳到開發板", "最後檢查序列埠的輸出結果"], str(texts))

print(f"通過 {passed} 項，失敗 {len(failed)} 項")
for f in failed:
    print("  X", f)
sys.exit(1 if failed else 0)
