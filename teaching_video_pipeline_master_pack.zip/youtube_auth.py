"""YouTube 授權：產生（或重新產生）yt_token.json

什麼時候要執行：
  第一次使用、換電腦、或上傳時出現 invalid_grant（授權被撤銷或過期）

用法：
  python youtube_auth.py            自動開瀏覽器，授權完自動存檔（最簡單）
  python youtube_auth.py --manual   瀏覽器開不起來、或在遠端電腦時：複製網址到瀏覽器，
                                    授權後把「網址列整串網址」貼回來

關於「7 天就失效」：
  Google Cloud 的 OAuth 同意畫面如果還在「測試中（Testing）」，refresh token 7 天後一定失效，
  程式怎麼寫都救不了（自動續期只能換短效的 access token）。
  改成「正式發布（In production）」後就沒有 7 天限制；個人自用可以不送審，
  但授權時會看到「Google 尚未驗證這個應用程式」，按「進階 → 前往」即可，且最多 100 位使用者。
  即使正式發布，自己撤銷授權、半年沒用、或同一帳號授權太多次，refresh token 仍會失效，那時再執行本程式。

舊版的 exchange_code_direct.py 已移除：它用另一個 Flow 物件換 token，
會遇到 PKCE code_verifier 不符，而且 http:// 的回傳網址會被 oauthlib 拒絕。
"""
import argparse
import os
import sys
from urllib.parse import parse_qs, urlparse

from common import HERE, load_config

SCOPES = ["https://www.googleapis.com/auth/youtube.upload",
          "https://www.googleapis.com/auth/youtube.force-ssl"]


def paths(cfg):
    y = cfg.get("youtube", {}) if cfg else {}
    base = cfg["_config_dir"] if cfg else HERE
    return (os.path.join(base, y.get("client_secrets", "client_secrets.json")),
            os.path.join(base, y.get("token", "yt_token.json")))


def authorize(secret, token, manual=False):
    from google_auth_oauthlib.flow import InstalledAppFlow
    if not os.path.exists(secret):
        raise SystemExit(f"找不到 {secret}：請到 Google Cloud Console 建立「桌面應用程式」OAuth 用戶端並下載")
    flow = InstalledAppFlow.from_client_secrets_file(secret, SCOPES)
    if manual:
        # 同一個 flow 物件產生網址、也用它換 token，PKCE 驗證碼才對得上
        flow.redirect_uri = "http://127.0.0.1:8080/"
        url, _ = flow.authorization_url(prompt="consent", access_type="offline")
        print("請用瀏覽器打開下面的網址並授權：\n" + url)
        print("\n授權後瀏覽器會跳到 127.0.0.1（顯示無法連線是正常的），把網址列整串複製貼上：")
        pasted = input("> ").strip()
        code = parse_qs(urlparse(pasted).query).get("code", [pasted])[0]   # 也接受只貼 code
        flow.fetch_token(code=code)      # 直接用 code 換，不經過 http 網址檢查
        creds = flow.credentials
    else:
        creds = flow.run_local_server(port=0, prompt="consent", access_type="offline",
                                      authorization_prompt_message="已開啟瀏覽器，請完成授權…")
    if not creds.refresh_token:
        print("警告：沒有拿到 refresh token，之後可能要常常重新授權")
    with open(token, "w", encoding="utf-8") as f:
        f.write(creds.to_json())
    print(f"已儲存 {token}（這個檔案等於密碼，不要上傳或分享）")
    return creds


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--manual", action="store_true")
    a = ap.parse_args()
    cfg = load_config(a.config) if (a.config or os.path.exists(os.path.join(HERE, "config.json"))) else None
    secret, token = paths(cfg)
    creds = authorize(secret, token, a.manual)
    from googleapiclient.discovery import build
    items = build("youtube", "v3", credentials=creds).channels().list(part="snippet", mine=True).execute().get("items", [])
    print("綁定的頻道：" + (items[0]["snippet"]["title"] if items else "（這個帳號沒有 YouTube 頻道）"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
