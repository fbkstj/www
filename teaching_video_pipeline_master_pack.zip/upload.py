"""階段五：YouTube 上傳、CC 字幕、播放清單

特色：
  - 可以中斷後再跑：已上傳的集數記在 output/uploads.json，不會重複上傳
  - 可續傳上傳＋遇到 5xx／網路中斷自動重試（2、4、8…秒）
  - 上傳後檢查隱私狀態：未通過 YouTube API 稽核的專案，影片會被鎖成「私人」，這裡會明確提醒
  - 字幕：subtitle_mode 是 cc／both 才上傳 CC；燒字幕（burn）就不上傳，避免觀眾看到兩份
  - 播放清單：加入失敗時重試（剛上傳的影片有時要等幾秒才查得到）

配額（每個專案每天預設 10,000 單位，實際數字以 Google 官方配額表為準）：
  上傳影片是最貴的操作，一天通常只能傳個位數支；字幕、播放清單也會消耗。超過會出現 quotaExceeded，隔天再跑即可。

用法：
  python upload.py --dry-run        只列出要做的事，不連線
  python upload.py                  全部集數
  python upload.py --episodes 2,3
"""
import argparse
import json
import os
import random
import time

from common import load_config, out, pick_episodes
from youtube_auth import SCOPES, paths

RETRY_STATUS = {500, 502, 503, 504}


def credentials(cfg):
    from google.auth.exceptions import RefreshError
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    secret, token = paths(cfg)
    if not os.path.exists(token):
        raise SystemExit(f"找不到 {token}，請先執行：python youtube_auth.py")
    creds = Credentials.from_authorized_user_file(token, SCOPES)
    if not creds.valid:
        if not creds.refresh_token:
            raise SystemExit("授權檔沒有 refresh token，請重新執行：python youtube_auth.py")
        try:
            creds.refresh(Request())          # 只能換新的「短效」access token
        except RefreshError as e:
            raise SystemExit(
                f"授權已失效（{e}）。\n"
                "  若 OAuth 同意畫面還在「測試中」，refresh token 7 天就會失效，程式自動續期也救不了；\n"
                "  請到 Google Cloud Console 把發布狀態改成「正式發布」，再執行：python youtube_auth.py")
        with open(token, "w", encoding="utf-8") as f:
            f.write(creds.to_json())
    return creds


def with_retry(fn, what, tries=6):
    from googleapiclient.errors import HttpError
    for i in range(tries):
        try:
            return fn()
        except HttpError as e:
            code = e.resp.status
            text = str(e)
            if "quotaExceeded" in text:
                raise SystemExit("今天的 API 配額用完了（quotaExceeded），明天再執行即可，已上傳的不會重傳")
            if code in RETRY_STATUS or (code in (404, 409) and what.startswith("playlist")):
                wait = 2 ** (i + 1) + random.random()
                print(f"   {what} 暫時失敗（{code}），{wait:.0f} 秒後重試…")
                time.sleep(wait)
                continue
            raise
        except (ConnectionError, TimeoutError, OSError) as e:
            wait = 2 ** (i + 1) + random.random()
            print(f"   {what} 連線問題（{e}），{wait:.0f} 秒後重試…")
            time.sleep(wait)
    raise RuntimeError(f"{what} 重試多次仍失敗")


def upload_video(yt, path, ep, ycfg):
    from googleapiclient.errors import HttpError
    from googleapiclient.http import MediaFileUpload
    body = {"snippet": {"title": ep["title"][:100], "description": ep.get("description", ""),
                        "tags": ycfg.get("tags", []), "categoryId": ycfg.get("category_id", "27"),
                        "defaultLanguage": "zh-TW", "defaultAudioLanguage": "zh-TW"},
            "status": {"privacyStatus": ycfg.get("privacy", "unlisted"), "selfDeclaredMadeForKids": False}}
    media = MediaFileUpload(path, chunksize=16 * 1024 * 1024, resumable=True)
    req = yt.videos().insert(part="snippet,status", body=body, media_body=media)
    resp, fails = None, 0
    while resp is None:
        try:
            status, resp = req.next_chunk()
            fails = 0
            if status:
                pct = int(status.progress() * 100)
                print(f"\r   上傳進度 [{'#' * (pct // 5):<20}] {pct}%", end="", flush=True)
        except HttpError as e:
            if e.resp.status not in RETRY_STATUS or fails >= 6:
                raise
            fails += 1
            time.sleep(2 ** fails)
        except (ConnectionError, TimeoutError, OSError):
            if fails >= 6:
                raise
            fails += 1
            print(f"\n   網路中斷，{2 ** fails} 秒後從斷點續傳…")
            time.sleep(2 ** fails)
    print()
    return resp["id"]


def check_privacy(yt, vid, wanted):
    items = yt.videos().list(part="status", id=vid).execute().get("items", [])
    actual = items[0]["status"]["privacyStatus"] if items else "?"
    if actual != wanted:
        print(f"   ⚠ 影片隱私狀態是「{actual}」，不是設定的「{wanted}」。\n"
              "     2020/7/28 之後建立、且未通過 YouTube API 稽核的專案，用 API 上傳的影片會被鎖成私人；\n"
              "     請申請 API 稽核，或到 YouTube 工作室手動確認。")
    return actual


def run(cfg, selector=None, dry_run=False):
    ycfg = cfg.get("youtube", {})
    mode = cfg.get("render", {}).get("subtitle_mode", "cc")
    state_path = out(cfg, "uploads.json")
    state = json.load(open(state_path, encoding="utf-8")) if os.path.exists(state_path) else {"videos": {}}
    eps = pick_episodes(cfg, selector)
    burned = mode in ("burn", "both")

    plan = []
    for ep in eps:
        video = out(cfg, "final_videos", f"{ep['id']}_final{'_burned' if burned else ''}.mp4")
        srt = out(cfg, "subtitles", f"{ep['id']}.srt")
        plan.append((ep, video, srt))
        done = ep["id"] in state["videos"]
        print(f"[{ep['id']}] {'已上傳，略過' if done else '要上傳'}：{os.path.basename(video)}"
              f"{'（找不到檔案！）' if not os.path.exists(video) else ''}；"
              f"CC 字幕：{'上傳' if mode in ('cc', 'both') else '不上傳（已燒進畫面）'}")
    print(f"播放清單：{ycfg.get('playlist_id') or state.get('playlist_id') or '新建「' + ycfg.get('playlist_title', '') + '」'}")
    if dry_run:
        print("（--dry-run：沒有連線，也沒有上傳）")
        return state

    from googleapiclient.discovery import build
    yt = build("youtube", "v3", credentials=credentials(cfg))
    for ep, video, srt in plan:
        if ep["id"] in state["videos"] or not os.path.exists(video):
            continue
        print(f"[{ep['id']}] 上傳 {ep['title']}（{os.path.getsize(video) / 1024 / 1024:.0f} MB）")
        vid = upload_video(yt, video, ep, ycfg)
        state["videos"][ep["id"]] = {"id": vid, "url": f"https://youtu.be/{vid}"}
        json.dump(state, open(state_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)   # 每傳完一支就存
        print(f"   完成：https://youtu.be/{vid}")
        check_privacy(yt, vid, ycfg.get("privacy", "unlisted"))
        if mode in ("cc", "both") and os.path.exists(srt):
            from googleapiclient.http import MediaFileUpload
            with_retry(lambda: yt.captions().insert(
                part="snippet",
                body={"snippet": {"videoId": vid, "language": "zh-TW", "name": "繁體中文", "isDraft": False}},
                media_body=MediaFileUpload(srt, mimetype="application/x-subrip")).execute(), "caption")
            print("   CC 字幕已上傳")

    # 播放清單：沒有就建一個，然後依集數順序加入（不指定 position，避免剛上傳的影片還查不到時出錯）
    pl = ycfg.get("playlist_id") or state.get("playlist_id")
    if not pl:
        resp = with_retry(lambda: yt.playlists().insert(part="snippet,status", body={
            "snippet": {"title": ycfg.get("playlist_title", cfg.get("course_name", "課程")),
                        "description": ycfg.get("playlist_description", ""), "defaultLanguage": "zh-TW"},
            "status": {"privacyStatus": ycfg.get("privacy", "unlisted")}}).execute(), "playlist create")
        pl = state["playlist_id"] = resp["id"]
        json.dump(state, open(state_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"已建立播放清單：https://www.youtube.com/playlist?list={pl}")
    existing = set()
    token = None
    while True:
        r = yt.playlistItems().list(part="contentDetails", playlistId=pl, maxResults=50, pageToken=token).execute()
        existing |= {i["contentDetails"]["videoId"] for i in r.get("items", [])}
        token = r.get("nextPageToken")
        if not token:
            break
    for ep in cfg.get("episodes", []):
        v = state["videos"].get(ep["id"])
        if not v or v["id"] in existing:
            continue
        time.sleep(2)
        with_retry(lambda: yt.playlistItems().insert(part="snippet", body={"snippet": {
            "playlistId": pl, "resourceId": {"kind": "youtube#video", "videoId": v["id"]}}}).execute(),
            f"playlist add {ep['id']}")
        print(f"   {ep['id']} 已加入播放清單")
    print(f"全部完成：https://www.youtube.com/playlist?list={pl}")
    return state


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--episodes")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    run(load_config(a.config), a.episodes, a.dry_run)


if __name__ == "__main__":
    main()
