"""一鍵流程：裁切報告 → 語音辨識 → 單行字幕 → 片頭＋壓製 →（確認後）上傳

預設「不會」自動上傳：先看過成品影片和字幕，確認沒問題再加 --upload（或雙擊「2_上傳YouTube.bat」）。

用法：
  python run_pipeline.py                         全部集數，做到壓製完成
  python run_pipeline.py --episodes 1            只做第 1 集（第一次用建議先試一集）
  python run_pipeline.py --stages subtitles,render   只重做某幾個階段（例如改了字幕規則）
  python run_pipeline.py --upload                壓製後直接上傳
階段名稱：trim、transcribe、subtitles、render、upload
"""
import argparse
import time

import render
import subtitles
import transcribe
import trim_silence
import upload
from common import load_config

ALL = ["trim", "transcribe", "subtitles", "render"]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--episodes")
    ap.add_argument("--stages", help="逗號分隔，預設全部（不含 upload）")
    ap.add_argument("--upload", action="store_true", help="最後也上傳 YouTube")
    ap.add_argument("--force", action="store_true", help="語音辨識已有結果也重做")
    ap.add_argument("--model", help="臨時換 Whisper 模型")
    a = ap.parse_args()

    cfg = load_config(a.config)
    stages = a.stages.split(",") if a.stages else list(ALL)
    if a.upload and "upload" not in stages:
        stages.append("upload")
    t0 = time.time()
    print(f"課程：{cfg.get('course_name')}　集數：{a.episodes or '全部'}　階段：{' → '.join(stages)}\n")

    if "trim" in stages:
        tcfg = cfg.get("trim", {})
        print("== 靜音裁切 ==")
        trim_silence.run(cfg, a.episodes, apply=bool(tcfg.get("enabled")))
    if "transcribe" in stages:
        print("\n== 語音辨識 ==")
        transcribe.run(cfg, a.episodes, a.force, a.model)
    if "subtitles" in stages:
        print("\n== 單行字幕 ==")
        subtitles.run(cfg, a.episodes)
    if "render" in stages:
        print("\n== 片頭與壓製 ==")
        render.run(cfg, a.episodes)
    if "upload" in stages:
        print("\n== 上傳 YouTube ==")
        upload.run(cfg, a.episodes)
    print(f"\n全部完成，共 {time.time() - t0:.0f} 秒。成品在 {cfg['output_dir']}")
    if "upload" not in stages:
        print("請先看過成品影片與字幕，確認後再執行：python upload.py")


if __name__ == "__main__":
    main()
