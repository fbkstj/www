"""階段四：片頭圖卡＋4 秒片頭＋接上課程影片＋（選擇性）燒字幕＋壓製

修正舊版的幾個問題：
  1. 字幕燒在「原始課程影片」上、接片頭之前（舊版燒在接好之後，範例沒加片頭秒數就會整條提早 4 秒）
  2. 片頭和課程影片先統一：1920×1080、像素比例 1:1（setsar=1）、固定 30 fps、48 kHz 雙聲道，
     不一致時 concat 會失敗或造成聲音畫面漸漸不同步
  3. 片頭一定有靜音音軌（用圖片做的片頭沒有聲音，concat 需要每一段都有聲音）
  4. 最終版用 preset medium（ultrafast 同畫質檔案大很多），加 yuv420p 與 faststart
  5. ffmpeg 錯誤不再被丟掉，失敗會顯示原因
  6. 字幕檔路徑的冒號、反斜線不用手動轉義：直接在字幕資料夾裡執行 ffmpeg

用法：
  python render.py                 全部集數
  python render.py --episodes 1
  python render.py --mode burn     這次改成燒字幕（預設看 config.json 的 render.subtitle_mode）
"""
import argparse
import os

from common import load_config, need_ffmpeg, out, pick_episodes, probe, run_ffmpeg, source_video

FONT_CANDIDATES = [r"C:\Windows\Fonts\msjh.ttc", r"C:\Windows\Fonts\msjhbd.ttc",
                   "/System/Library/Fonts/PingFang.ttc", "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"]


def font(size):
    from PIL import ImageFont
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def fit_text(draw, text, size, max_w):
    """標題太長就把字縮小，不要超出畫面。"""
    while size > 24:
        f = font(size)
        if draw.textlength(text, font=f) <= max_w:
            return f
        size -= 2
    return font(size)


def make_cover(cfg, ep, path):
    from PIL import Image, ImageDraw
    img = Image.new("RGB", (1920, 1080), (18, 28, 45))
    d = ImageDraw.Draw(img)
    d.rectangle([40, 40, 1880, 1040], outline=(60, 140, 230), width=6)
    d.rectangle([52, 52, 1868, 1028], outline=(100, 180, 255), width=2)
    tag = cfg.get("course_tag", cfg.get("course_name", ""))
    f_tag = fit_text(d, tag, 36, 900)
    tw = d.textlength(tag, font=f_tag)
    d.rounded_rectangle([960 - tw / 2 - 40, 120, 960 + tw / 2 + 40, 190], radius=15, fill=(60, 140, 230))
    d.text((960, 155), tag, font=f_tag, fill=(255, 255, 255), anchor="mm")
    d.text((960, 340), ep["title"], font=fit_text(d, ep["title"], 56, 1700), fill=(255, 230, 150), anchor="mm")
    d.rounded_rectangle([300, 520, 1620, 880], radius=20, fill=(28, 40, 65), outline=(80, 120, 180), width=3)
    f_sub = font(36)
    d.text((960, 600), f"課程名稱：{cfg.get('course_name', '')}", font=f_sub, fill=(255, 255, 255), anchor="mm")
    d.text((960, 690), f"上課日期：{cfg.get('date', '')}", font=f_sub, fill=(212, 175, 55), anchor="mm")
    nxt = f"即將開始：{ep.get('short_title', ep['title'])}"
    d.text((960, 780), nxt, font=fit_text(d, nxt, 36, 1200), fill=(180, 210, 255), anchor="mm")
    d.text((960, 970), cfg.get("producer", ""), font=font(26), fill=(160, 180, 210), anchor="mm")
    img.save(path)


def make_intro(cfg, ep):
    sec = float(cfg.get("intro", {}).get("seconds", 4.0))
    fps = cfg.get("render", {}).get("fps", 30)
    png = out(cfg, "covers", f"{ep['id']}_cover.png")
    mp4 = out(cfg, "covers", f"{ep['id']}_intro.mp4")
    make_cover(cfg, ep, png)
    run_ffmpeg(["-loop", "1", "-framerate", str(fps), "-i", png,
                "-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000",
                "-t", f"{sec}", "-vf", "setsar=1", "-c:v", "libx264", "-preset", "medium", "-crf", "18",
                "-pix_fmt", "yuv420p", "-r", str(fps), "-c:a", "aac", "-ar", "48000", "-ac", "2", mp4],
               log_path=out(cfg, "logs", f"{ep['id']}_intro.log"))
    return mp4


def render_episode(cfg, ep, mode):
    rcfg = cfg.get("render", {})
    fps = rcfg.get("fps", 30)
    src = source_video(cfg, ep)
    if not os.path.exists(src):
        print(f"[{ep['id']}] 找不到影片：{src}")
        return None
    dur, has_audio, _, _, _ = probe(src)
    if not has_audio:
        print(f"[{ep['id']}] 這支影片沒有聲音軌，無法接片頭（請確認錄影設定）")
        return None
    intro = make_intro(cfg, ep)
    burn = mode in ("burn", "both")
    ass_name = f"{ep['id']}.ass"
    sub_dir = out(cfg, "subtitles")
    if burn and not os.path.exists(os.path.join(sub_dir, ass_name)):
        print(f"[{ep['id']}] 沒有字幕檔 {ass_name}，先執行 subtitles.py")
        return None
    norm = f"scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps}"
    aud = "aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo"
    main_v = f"[1:v]{norm}" + (f",ass={ass_name}" if burn else "") + "[v1]"   # 字幕燒在課程影片上，時間不用加片頭秒數
    fc = (f"[0:v]{norm}[v0];{main_v};[0:a]{aud}[a0];[1:a]{aud}[a1];"
          f"[v0][a0][v1][a1]concat=n=2:v=1:a=1[outv][outa]")
    suffix = "_burned" if burn else ""
    final = out(cfg, "final_videos", f"{ep['id']}_final{suffix}.mp4")
    print(f"[{ep['id']}] 壓製中（{'燒字幕' if burn else '不燒字幕，字幕另外上傳 CC'}，preset {rcfg.get('preset', 'medium')}）…")
    run_ffmpeg(["-i", intro, "-i", src, "-filter_complex", fc, "-map", "[outv]", "-map", "[outa]",
                "-c:v", "libx264", "-preset", rcfg.get("preset", "medium"), "-crf", str(rcfg.get("crf", 20)),
                "-pix_fmt", "yuv420p", "-r", str(fps), "-c:a", "aac", "-b:a", rcfg.get("audio_bitrate", "192k"),
                "-ar", "48000", "-ac", "2", "-movflags", "+faststart", final],
               log_path=out(cfg, "logs", f"{ep['id']}_render.log"), cwd=sub_dir)
    got = probe(final)[0]
    want = dur + float(cfg.get("intro", {}).get("seconds", 4.0))
    ok = abs(got - want) < 0.5
    print(f"[{ep['id']}] 完成 {final}（{got:.1f} 秒，預期 {want:.1f} 秒{'' if ok else '，長度不對，請檢查紀錄檔'}；"
          f"{os.path.getsize(final) / 1024 / 1024:.1f} MB）")
    return final


def run(cfg, selector=None, mode=None):
    need_ffmpeg()
    mode = mode or cfg.get("render", {}).get("subtitle_mode", "cc")
    if mode == "both":
        print("提醒：subtitle_mode=both 會同時燒字幕又上傳 CC，觀眾打開 CC 會看到兩份字幕")
    return {ep["id"]: render_episode(cfg, ep, mode) for ep in pick_episodes(cfg, selector)}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--episodes")
    ap.add_argument("--mode", choices=["cc", "burn", "both"])
    a = ap.parse_args()
    run(load_config(a.config), a.episodes, a.mode)


if __name__ == "__main__":
    main()
