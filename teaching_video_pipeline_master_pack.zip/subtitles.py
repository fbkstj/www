"""階段三：用逐字時間戳重組「單行字幕」，輸出 SRT（上傳 CC 用）與 ASS（燒進畫面用）

規則（都可以在 config.json 的 subtitles 區塊調整）：
  1. 永遠單行：每行寬度不超過 max_chars 個中文字（英文字母算半個字寬）
  2. 優先在標點、講話停頓處斷句；停頓超過 gap_split 秒一定斷開
  3. 停留時間跟著講話走：最少 min_duration 秒、最多 max_duration 秒；
     講太快（每秒超過 max_cps 字）就把字幕延長一點，讓人讀得完
  4. 絕對不和下一句重疊（重疊時畫面會疊成兩行，違反規則 1）

兩個檔案的時間軸不一樣，這是刻意的：
  epXX.srt  已經加上片頭秒數（intro.seconds），對齊「加了片頭的成品影片」，給 YouTube CC 用
  epXX.ass  沒有加片頭秒數，對齊「原始課程影片」，在接片頭之前就燒進畫面

用法：
  python subtitles.py                  全部集數
  python subtitles.py --episodes 2
"""
import argparse
import json
import os
import re

from common import ass_time, load_config, out, pick_episodes, srt_time

BREAK_PUNCT = "，。！？；：、,.!?;:"
END_STRIP = "，。、；：,.;:"
KEEP_END = "？！?!"


def char_width(ch):
    if ch.isspace():
        return 0.3
    return 0.55 if ord(ch) < 0x2E80 else 1.0     # 英數半形約半個中文字寬


def width(text):
    return sum(char_width(c) for c in text)


def is_ascii_word(s):
    return bool(s) and all(ord(c) < 128 for c in s.strip()) and any(c.isalnum() for c in s)


def join_tokens(tokens):
    """接起來：Whisper 的英文新單字前面會帶空白（" Python"），同一個字拆成好幾塊時不帶（"ES" "P" "32"），
    照這個規則補空白，ESP32 才不會變成 ES P 32；中英文交界再補一個空白，比較好讀。"""
    text = ""
    for t in tokens:
        raw = t["w"]
        w = raw.strip()
        if not w:
            continue
        if text and raw[:1].isspace() and not text.endswith(" "):
            text += " "
        text += w
    text = re.sub(r"(?<=[一-鿿])(?=[A-Za-z0-9])", " ", text)
    text = re.sub(r"(?<=[A-Za-z0-9])(?=[一-鿿])", " ", text)
    return text


def tokens_from_segments(segments):
    """把每一段的逐字時間攤平成 token；沒有逐字時間的段落，就按字數平均分配時間。"""
    toks = []
    for s in segments:
        words = s.get("words") or []
        if words:
            for w in words:
                if w["word"].strip():
                    toks.append({"w": w["word"], "start": float(w["start"]), "end": float(w["end"])})
        else:
            chars = [c for c in s["text"] if not c.isspace()]
            if not chars:
                continue
            step = (s["end"] - s["start"]) / len(chars)
            for i, c in enumerate(chars):
                toks.append({"w": c, "start": s["start"] + i * step, "end": s["start"] + (i + 1) * step})
    toks.sort(key=lambda t: t["start"])
    return toks


def best_split(cur, max_chars):
    """在 cur 裡找斷點 k（前 k 個 token 當一行）。只考慮前半行至少 40% 寬的位置；
    優先選標點後面，其次選兩個字之間停頓最長的地方；都沒有就整行送出。"""
    best_k, best_score = len(cur), -1.0
    for k in range(1, len(cur)):
        if width(join_tokens(cur[:k])) < max_chars * 0.4:
            continue
        gap = cur[k]["start"] - cur[k - 1]["end"]
        score = gap + (10.0 if cur[k - 1]["w"].strip()[-1:] in BREAK_PUNCT else 0.0)
        if score > best_score:
            best_k, best_score = k, score
    return best_k if best_score >= 0.15 else len(cur)


def clean_text(text, replacements):
    for a, b in (replacements or {}).items():
        text = text.replace(a, b)
    text = text.strip()
    while text and text[-1] in END_STRIP and text[-1] not in KEEP_END:
        text = text[:-1].rstrip()
    while text and text[0] in END_STRIP:
        text = text[1:].lstrip()
    text = re.sub(r"[，。、；：](?=.)", "　", text)      # 句中的逗號句號改成全形空白（字幕慣例）
    text = re.sub(r"\s*,\s*(?=.)", "　", text)            # 小模型常輸出半形逗號
    text = re.sub(r"(?<=[一-鿿])\.\s*(?=.)", "　", text)
    text = re.sub(r" ?　 ?", "　", text)
    text = re.sub(r"\s{2,}", " ", text)
    return text


def build_lines(segments, rules):
    max_chars = rules.get("max_chars", 20)
    gap_split = rules.get("gap_split", 0.8)
    max_dur = rules.get("max_duration", 6.0)
    min_dur = rules.get("min_duration", 1.2)
    max_cps = rules.get("max_cps", 8)
    repl = rules.get("replacements", {})

    groups, cur = [], []
    for tok in tokens_from_segments(segments):
        if cur:
            gap = tok["start"] - cur[-1]["end"]
            too_wide = width(join_tokens(cur + [tok])) > max_chars
            too_long = tok["end"] - cur[0]["start"] > max_dur
            at_punct = cur[-1]["w"].strip()[-1:] in BREAK_PUNCT and width(join_tokens(cur)) >= max_chars * 0.55
            if gap > gap_split or at_punct:
                groups.append(cur)
                cur = []
            elif too_wide or too_long:
                # 被寬度或長度逼著斷：往回找比較好的斷點（標點＞停頓最長處），
                # 避免把「輸出」切成「…的輸」「出結果」這種斷在詞中間的情形
                k = best_split(cur, max_chars)
                groups.append(cur[:k])
                cur = cur[k:]
                if cur and (width(join_tokens(cur + [tok])) > max_chars or tok["end"] - cur[0]["start"] > max_dur):
                    groups.append(cur)
                    cur = []
        cur.append(tok)
    if cur:
        groups.append(cur)

    # 單一個 token 就超寬（很長的英文詞串），按字元硬切
    fixed = []
    for g in groups:
        if width(join_tokens(g)) <= max_chars:
            fixed.append(g)
            continue
        text, t0, t1 = join_tokens(g), g[0]["start"], g[-1]["end"]
        pieces, piece = [], ""
        for ch in text:
            if width(piece + ch) > max_chars:
                pieces.append(piece)
                piece = ""
            piece += ch
        pieces.append(piece)
        total = sum(len(p) for p in pieces)
        acc = 0
        for p in pieces:
            a = t0 + (t1 - t0) * acc / total
            acc += len(p)
            fixed.append([{"w": p, "start": a, "end": t0 + (t1 - t0) * acc / total}])

    lines = []
    for g in fixed:
        text = clean_text(join_tokens(g), repl)
        if not text:
            continue
        lines.append({"start": g[0]["start"], "end": g[-1]["end"], "text": text})

    # 太短的碎句（例如只有「好」「嗯」）併到前一句，前提是合起來不超寬、間隔很短
    merged = []
    for ln in lines:
        if (merged and width(ln["text"]) < 3 and ln["start"] - merged[-1]["end"] < 0.4
                and width(merged[-1]["text"] + ln["text"]) <= max_chars):
            merged[-1]["text"] += ln["text"]
            merged[-1]["end"] = ln["end"]
        else:
            merged.append(ln)
    lines = merged

    # 停留時間：至少 min_dur、讀得完；但不超過 max_dur，也絕不蓋到下一句
    for i, ln in enumerate(lines):
        need = max(min_dur, width(ln["text"]) / max_cps)
        end = max(ln["end"], ln["start"] + need)
        end = min(end, ln["start"] + max(max_dur, ln["end"] - ln["start"]))
        if i + 1 < len(lines):
            end = min(end, lines[i + 1]["start"] - 0.04)
        ln["end"] = max(end, ln["start"] + 0.3)
        if i + 1 < len(lines) and ln["end"] > lines[i + 1]["start"]:   # 兩句幾乎同時開始：前一句讓出來
            ln["end"] = lines[i + 1]["start"]
    return lines


def check_lines(lines, rules):
    """回傳統計，給測試和終端機報告用。"""
    overlaps = sum(1 for a, b in zip(lines, lines[1:]) if a["end"] > b["start"] + 1e-6)
    widest = max((width(l["text"]) for l in lines), default=0)
    durs = [l["end"] - l["start"] for l in lines]
    cps = [width(l["text"]) / max(0.01, d) for l, d in zip(lines, durs)]
    return {"lines": len(lines), "overlaps": overlaps, "widest": round(widest, 1),
            "too_wide": sum(1 for l in lines if width(l["text"]) > rules.get("max_chars", 20) + 1e-6),
            "avg_dur": round(sum(durs) / len(durs), 2) if durs else 0,
            "max_cps": round(max(cps), 1) if cps else 0}


def ass_header(cfg, title):
    s = cfg.get("subtitles", {})
    return f"""[Script Info]
Title: {title}
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{s.get('font', 'Microsoft JhengHei')},{s.get('font_size', 46)},&H00FFFFFF,&H000000FF,&H00181818,&H80000000,-1,0,0,0,100,100,0,0,1,{s.get('outline', 3)},{s.get('shadow', 2)},2,40,40,{s.get('margin_v', 65)},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def write_files(cfg, ep, lines):
    offset = float(cfg.get("intro", {}).get("seconds", 0))
    srt_path = out(cfg, "subtitles", f"{ep['id']}.srt")
    ass_path = out(cfg, "subtitles", f"{ep['id']}.ass")
    with open(srt_path, "w", encoding="utf-8") as f:
        for i, ln in enumerate(lines, 1):
            f.write(f"{i}\n{srt_time(ln['start'] + offset)} --> {srt_time(ln['end'] + offset)}\n{ln['text']}\n\n")
    with open(ass_path, "w", encoding="utf-8-sig") as f:
        f.write(ass_header(cfg, ep.get("title", ep["id"])))
        for ln in lines:
            text = ln["text"].replace("{", "｛").replace("}", "｝")
            f.write(f"Dialogue: 0,{ass_time(ln['start'])},{ass_time(ln['end'])},Default,,0,0,0,,{text}\n")
    return srt_path, ass_path


def run(cfg, selector=None):
    rules = cfg.get("subtitles", {})
    done = {}
    for ep in pick_episodes(cfg, selector):
        jp = out(cfg, "transcriptions", f"{ep['id']}.json")
        if not os.path.exists(jp):
            print(f"[{ep['id']}] 還沒有辨識結果，先執行 transcribe.py")
            continue
        with open(jp, encoding="utf-8") as f:
            data = json.load(f)
        segs = data["segments"] if isinstance(data, dict) else data
        lines = build_lines(segs, rules)
        srt_path, ass_path = write_files(cfg, ep, lines)
        st = check_lines(lines, rules)
        print(f"[{ep['id']}] {len(segs)} 段 → {st['lines']} 行單行字幕；最寬 {st['widest']} 字、"
              f"平均停留 {st['avg_dur']} 秒、重疊 {st['overlaps']} 處、超寬 {st['too_wide']} 行")
        done[ep["id"]] = (srt_path, ass_path, st)
    return done


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config")
    ap.add_argument("--episodes")
    a = ap.parse_args()
    run(load_config(a.config), a.episodes)


if __name__ == "__main__":
    main()
