@echo off
pushd "%~dp0"
python app_yolo11_edge.py
if errorlevel 1 (
    echo.
    echo Application exited with error.
    pause
)
popd
