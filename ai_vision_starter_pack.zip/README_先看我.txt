﻿AI 視覺創客小學堂 - 學生入門知識包
====================================

【事前準備】
1. 安裝 Google Antigravity（免費 AI 程式助手）：https://antigravity.google/download
   用 Google 帳號登入，再用「開啟資料夾」打開這個解壓縮後的資料夾。
   教學網頁上的 5 步提示語，就是貼到 Antigravity 的 AI 對話面板使用。
   （免費方案每週有使用額度，用完要等額度恢復。）
   也可以改用 Claude Code（需 Claude 付費方案）：Claude 桌面版的「Code」分頁選擇這個資料夾，
   或在 PowerShell 執行 irm https://claude.ai/install.ps1 | iex 後，到資料夾執行 claude。提示語不用修改。
2. 安裝 Python 3.10 以上版本（安裝時勾選 Add Python to PATH）。
3. 準備一顆 USB 網路攝影機。
4. 不透過 AI 自己安裝套件時，開啟命令提示字元執行：
   pip install ultralytics opencv-python
   （app_yolo11_edge.py 另需：pip install customtkinter pillow）

【開始使用】
- 雙擊 run_ai.bat：開啟即時辨識視窗。
  按 1 物件偵測、2 人體骨架、3 影像分割、q 離開。
- 第一次執行時，程式會自動從網路下載 YOLO11 Nano 模型檔（每個約 6 MB），請保持連線。
- 雙擊 run_yolo11.bat：開啟圖形介面版本。

【檔案說明】
- webcam_ai_detect.py：即時辨識主程式
- app_yolo11_edge.py：圖形介面版本
- 學生實作入門教學提示語指南.md：5 步闖關提示語
- AI_Webcam_實戰教學講義與專題發想指南.md：講義與專題點子
- 專題報告寫作範本_智慧心情咖啡機.md：書面報告格式範本（數據為示範用，並非真實實驗結果）

教學網頁：https://fbkstj.github.io/www/#page/ai_vision_course_guide
