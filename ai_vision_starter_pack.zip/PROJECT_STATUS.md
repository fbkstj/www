# 📌 專案進度與記憶交接日誌 (PROJECT_STATUS.md)

> **專案名稱**：Logi C270 AI 視訊與邊緣推論入門實作  
> **工作區路徑**：`j:\我的雲端硬碟\antigravity\115-09-12-webcam`  
> **最後更新時間**：2026-09-13  
> **適用角色**：開發者、授課教師、學生、接續任務之 AI 助手

---

## 🎯 專案目前階段與進度
* [x] **階段 1：硬體檢測與訊號最佳化**
  * 攝影機：Logi C270 (1280x720 30FPS, MJPEG 模式) 運作正常。
  * 麥克風：系統音量已由 82% 校準至 92%（-18.8 dB 最佳動態範圍）。
  * 語音輸入：已診斷出 Windows 語音套件與繁體中文 Big5 設定。
* [x] **階段 2：AI 視覺核心與環境建置**
  * 已配置 Python 3.14 + OpenCV + PyTorch + Ultralytics YOLO11 + CustomTkinter 6.0.0。
  * 已下載三套輕量化模型：`yolo11n.pt` (物件)、`yolo11n-pose.pt` (骨架)、`yolo11n-seg.pt` (分割)。
* [x] **階段 3：即時實作與除錯突破**
  * 已完成純 OpenCV 極速視窗 [`webcam_ai_detect.py`](webcam_ai_detect.py)，支援 `1`、`2`、`3` 熱鍵切換，實測 25~35 FPS 流暢運行。
  * 已解決 Windows Session 0 視窗隔離、Google Drive UNC 路徑、Big5 中文編碼閃退三大坑點。
  * 已建立純 ASCII 防閃退一鍵啟動檔 [`run_opencv_yolo.bat`](run_opencv_yolo.bat) 與 [`run_ai.bat`](run_ai.bat)。
* [ ] **階段 4：下一步預計進行的任務**
  * 任務 A：挑選一個生活實用主題（如：手勢免碰遙控、坐姿駝背提醒、手機摸魚警報）。
  * 任務 B：在目前辨識核心中加入邏輯判斷與警報音效。
  * 任務 C：製作整合 CustomTkinter 深色現代化儀表板。

---

## 📂 專案重要檔案清單
1. [`webcam_ai_detect.py`](webcam_ai_detect.py)：主力實時 AI 辨識程式（按 1 物件、2 骨架、3 去背、q 離開）。
2. [`run_opencv_yolo.bat`](run_opencv_yolo.bat) / [`run_ai.bat`](run_ai.bat)：雙擊即開防閃退啟動腳本。
3. [`app_yolo11_edge.py`](app_yolo11_edge.py)：CustomTkinter 桌面儀表板版。
4. [`AI_Webcam_實戰教學講義與專題發想指南.md`](AI_Webcam_實戰教學講義與專題發想指南.md)：包含 10 大生活專題與完整除錯教學之學生講義。
5. [`學生實作入門教學提示語指南.md`](學生實作入門教學提示語指南.md)：學生零踩坑 5 步提示語手冊。
6. `yolo11n.pt` / `yolo11n-pose.pt` / `yolo11n-seg.pt`：YOLO11 輕量模型權重。

---

## 💡 下次啟動備忘錄與開發原則 (Rules of Engagement)
1. **先測試、後回報原則（極重要）**：
   * 每次開發或修改新功能後，AI 必須**先在背景自動進行語法編譯與功能冒煙測試 (Smoke Test)**。
   * 確認程式能 100% 正常執行、無閃退、無缺漏套件後，**再向使用者回報並展示測試成果與功能亮點**。
2. **接關指引**：
   * 下次對話開始時，AI 請直接讀取本檔案掌握進度，並優先詢問使用者要進行「階段 4」的哪一項任務。
