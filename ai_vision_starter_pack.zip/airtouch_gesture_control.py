# -*- coding: utf-8 -*-
"""
專題 12：AirTouch 無接觸手勢智慧遙控
=====================================================
核心功能：
1. 🖐️ 手掌張開懸停 (Dwell)     -> 暫停 / 播放 (發送 Space 鍵)
2. 👉 食指快速右揮 (Swipe Right) -> 簡報下一頁 (發送 Right 鍵)
3. 👈 食指快速左揮 (Swipe Left)  -> 簡報上一頁 (發送 Left 鍵)
4. 👍 大拇指朝上 (Thumbs Up)    -> 電腦音量增加 (發送 Volume Up)
5. 👎 大拇指朝下 (Thumbs Down)  -> 電腦音量降低 (發送 Volume Down)
6. 👌 捏合手勢 (Pinch)          -> 靜音開關 (發送 Volume Mute)

安全與防抖設計：
- 時序防抖動 (Debounce) 與冷卻計時器，避免手晃連續誤觸。
- 鏡頭鏡像翻轉，操作直覺符合人體工學。
- 熱鍵 [M] 可一鍵切換「實體鍵盤模擬 ON / 演示模式 OFF」，防止誤觸背景軟體。
- 按 [Q] 或 [ESC] 退出程式。
"""

import time
import math
import collections
import numpy as np
import cv2
import pyautogui
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
from PIL import Image, ImageDraw, ImageFont
import os

# 停用 pyautogui 故障安全保護避免鼠標移到角落拋錯 (我們只模擬鍵盤)
pyautogui.FAILSAFE = False

# 中文字型載入
FONT_PATH = r"C:\Windows\Fonts\msjh.ttc"
if not os.path.exists(FONT_PATH):
    FONT_PATH = r"C:\Windows\Fonts\simhei.ttf"

def draw_chinese_text(img, text, pos, font_size=22, color=(255, 255, 255)):
    """在 OpenCV 影像上繪製繁體中文字串"""
    try:
        font = ImageFont.truetype(FONT_PATH, font_size)
        img_pil = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(img_pil)
        draw.text(pos, text, font=font, fill=color)
        return cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    except Exception:
        # Fallback to cv2.putText if PIL font fails
        cv2.putText(img, text, pos, cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        return img

# 手指關節連線定義 (MediaPipe 21 Landmark Hand Topology)
HAND_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),           # 拇指
    (0, 5), (5, 6), (6, 7), (7, 8),           # 食指
    (5, 9), (9, 10), (10, 11), (11, 12),      # 中指
    (9, 13), (13, 14), (14, 15), (15, 16),    # 無名指
    (13, 17), (17, 18), (18, 19), (19, 20),   # 小指
    (0, 17)                                   # 手掌基部
]

class AirTouchController:
    def __init__(self, model_path="hand_landmarker.task"):
        # 1. 初始化 MediaPipe HandLandmarker
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"找不到模型檔 {model_path}，請確認檔案路徑！")

        base_options = python.BaseOptions(model_asset_path=model_path)
        options = vision.HandLandmarkerOptions(
            base_options=base_options,
            running_mode=vision.RunningMode.IMAGE,
            num_hands=1,
            min_hand_detection_confidence=0.6,
            min_hand_presence_confidence=0.6,
            min_tracking_confidence=0.6
        )
        self.detector = vision.HandLandmarker.create_from_options(options)

        # 2. 手勢追蹤狀態與防抖佇列
        self.index_tip_history = collections.deque(maxlen=8) # 記錄食指尖 (x, y, timestamp)
        self.hover_counter = 0                               # 手掌懸停幀數計數器
        self.hover_required_frames = 20                      # 懸停觸發門檻 (約 0.65 秒)
        
        # 3. 動作冷卻時間記錄
        self.last_action_time = 0.0
        self.cooldown_seconds = 0.8                          # 動作觸發冷卻時間 (秒)
        self.volume_last_time = 0.0
        self.volume_cooldown = 0.22                          # 音量連續微調間隔 (秒)

        # 4. 系統操作模式
        self.simulate_os_keys = True                         # True: 實體發送按鍵 / False: 僅展示
        self.last_triggered_text = "等待手勢指令..."
        self.trigger_toast_until = 0.0

    def trigger_action(self, action_name, key_to_press=None, cooldown=0.8):
        """觸發鍵盤事件與介面回饋"""
        now = time.time()
        self.last_action_time = now
        self.cooldown_seconds = cooldown
        self.last_triggered_text = f"【觸發】{action_name}"
        self.trigger_toast_until = now + 1.2
        self.hover_counter = 0
        self.index_tip_history.clear()

        if self.simulate_os_keys and key_to_press:
            try:
                pyautogui.press(key_to_press)
            except Exception as e:
                print(f"[Key Error] {e}")

    def process_frame(self, frame):
        h, w, _ = frame.shape
        now = time.time()

        # 轉 RGB 供 MediaPipe 辨識
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
        detection_result = self.detector.detect(mp_image)

        is_cooling_down = (now - self.last_action_time) < self.cooldown_seconds
        gesture_detected = "無手部動態"
        hover_progress = 0.0

        if detection_result.hand_landmarks:
            landmarks = detection_result.hand_landmarks[0]
            pts = [(int(lm.x * w), int(lm.y * h)) for lm in landmarks]

            # 繪製手骨架 (科技藍綠漸層)
            for (p1_idx, p2_idx) in HAND_CONNECTIONS:
                cv2.line(frame, pts[p1_idx], pts[p2_idx], (255, 200, 0), 2, cv2.LINE_AA)
            for i, (px, py) in enumerate(pts):
                if i in [4, 8, 12, 16, 20]:
                    cv2.circle(frame, (px, py), 7, (0, 255, 255), -1, cv2.LINE_AA) # 指尖金色
                else:
                    cv2.circle(frame, (px, py), 4, (0, 255, 128), -1, cv2.LINE_AA) # 關節綠色

            # --- 手指數位特徵判斷 ---
            # 食指、中指、無名指、小指：指尖 y < PIP 關節 y (向上伸展)
            is_index_up = landmarks[8].y < landmarks[6].y
            is_middle_up = landmarks[12].y < landmarks[10].y
            is_ring_up = landmarks[16].y < landmarks[14].y
            is_pinky_up = landmarks[20].y < landmarks[18].y

            # 大拇指朝上 / 朝下判定
            # 拇指尖 (4) 相對 MCP (2) 與 CMC (1)
            thumb_vec_y = landmarks[4].y - landmarks[2].y
            is_thumb_up = (thumb_vec_y < -0.06) and (landmarks[4].y < landmarks[8].y)
            is_thumb_down = (thumb_vec_y > 0.06) and (landmarks[4].y > landmarks[8].y)

            # 拇指與食指距離 (捏合檢測)
            pinch_dist = math.hypot(landmarks[4].x - landmarks[8].x, landmarks[4].y - landmarks[8].y)

            # 食指尖座標
            index_x, index_y = landmarks[8].x, landmarks[8].y
            self.index_tip_history.append((index_x, index_y, now))

            # 掌心位置 (取手腕與中指根部中點)
            palm_x = int((pts[0][0] + pts[9][0]) / 2)
            palm_y = int((pts[0][1] + pts[9][1]) / 2)

            # --- 手勢識別邏輯 ---

            # 手勢 1：🖐️ 五指全開 (手掌懸停 Dwell -> 暫停/播放)
            if is_index_up and is_middle_up and is_ring_up and is_pinky_up:
                gesture_detected = "🖐️ 手掌張開 (懸停鎖定中)"
                if not is_cooling_down:
                    self.hover_counter += 1
                    hover_progress = min(1.0, self.hover_counter / self.hover_required_frames)
                    
                    # 在掌心繪製環狀進度條
                    cv2.circle(frame, (palm_x, palm_y), 32, (100, 100, 100), 4, cv2.LINE_AA)
                    angle = int(hover_progress * 360)
                    cv2.ellipse(frame, (palm_x, palm_y), (32, 32), 0, -90, -90 + angle, (0, 255, 255), 4, cv2.LINE_AA)

                    if self.hover_counter >= self.hover_required_frames:
                        self.trigger_action("🖐️ 手掌懸停：播放 / 暫停", key_to_press='space', cooldown=1.2)
                else:
                    self.hover_counter = 0

            # 手勢 2：👉 食指單指伸出 (滑動翻頁檢測)
            elif is_index_up and not is_middle_up and not is_ring_up and not is_pinky_up:
                self.hover_counter = 0
                gesture_detected = "👉 食指待命 (左右揮動翻頁)"

                # 繪製食指尖軌跡光暈
                cv2.circle(frame, pts[8], 12, (0, 165, 255), 2, cv2.LINE_AA)

                # 滑動速度判定：計算歷史佇列中最舊與最新的 X 軸位移
                if len(self.index_tip_history) >= 4 and not is_cooling_down:
                    old_x, _, old_t = self.index_tip_history[0]
                    dx = index_x - old_x
                    dt = now - old_t

                    # 水平位移 threshold: 0.16 (約畫面寬度的 16%) 且在 0.35 秒內完成
                    if dt <= 0.35:
                        if dx > 0.15: # 鏡像後，畫面往右 = 食指右揮
                            self.trigger_action("👉 食指右揮：下一頁 (Next Slide)", key_to_press='right', cooldown=0.8)
                        elif dx < -0.15: # 畫面往左 = 食指左揮
                            self.trigger_action("👈 食指左揮：上一頁 (Prev Slide)", key_to_press='left', cooldown=0.8)

            # 手勢 3：👍 大拇指朝上 (調大音量)
            elif is_thumb_up and not is_index_up and not is_middle_up and not is_ring_up and not is_pinky_up:
                self.hover_counter = 0
                gesture_detected = "👍 大拇指朝上 (調大音量)"
                if (now - self.volume_last_time) > self.volume_cooldown:
                    self.volume_last_time = now
                    self.trigger_action("👍 音量增加 (+)", key_to_press='volumeup', cooldown=0.2)

            # 手勢 4：👎 大拇指朝下 (調小音量)
            elif is_thumb_down and not is_index_up and not is_middle_up and not is_ring_up and not is_pinky_up:
                self.hover_counter = 0
                gesture_detected = "👎 大拇指朝下 (調小音量)"
                if (now - self.volume_last_time) > self.volume_cooldown:
                    self.volume_last_time = now
                    self.trigger_action("👎 音量降低 (-)", key_to_press='volumedown', cooldown=0.2)

            # 手勢 5：👌 食指拇指捏合 (靜音開關)
            elif pinch_dist < 0.05 and not is_middle_up and not is_ring_up:
                self.hover_counter = 0
                gesture_detected = "👌 捏合手勢 (靜音開關)"
                if not is_cooling_down:
                    self.trigger_action("👌 靜音切換 (Mute)", key_to_press='volumemute', cooldown=1.2)

            else:
                self.hover_counter = 0

        else:
            self.hover_counter = 0
            self.index_tip_history.clear()

        # --- 繪製現代化 HUD 儀表介面 ---
        # 頂部半透明狀態列
        overlay = frame.copy()
        cv2.rectangle(overlay, (0, 0), (w, 85), (15, 23, 42), -1)
        # 底部狀態列
        cv2.rectangle(overlay, (0, h - 55), (w, h), (15, 23, 42), -1)
        cv2.addWeighted(overlay, 0.75, frame, 0.25, 0, frame)

        # 頂部資訊：品牌與當前偵測狀態
        frame = draw_chinese_text(frame, "AirTouch 無接觸手勢智慧遙控", (16, 10), font_size=20, color=(255, 215, 0))
        status_color = (0, 255, 255) if "待命" in gesture_detected or "懸停" in gesture_detected else (200, 200, 200)
        frame = draw_chinese_text(frame, f"當前狀態: {gesture_detected}", (16, 42), font_size=17, color=status_color)

        # 模擬模式標籤
        mode_text = "鍵盤模擬 [ON]" if self.simulate_os_keys else "演示模式 [OFF]"
        mode_color = (0, 255, 128) if self.simulate_os_keys else (180, 180, 180)
        frame = draw_chinese_text(frame, mode_text, (w - 170, 12), font_size=16, color=mode_color)
        frame = draw_chinese_text(frame, "[M] 切換模式 | [Q] 退出", (w - 200, 42), font_size=13, color=(160, 160, 160))

        # 底部 Toast 動作反饋 (高亮提示)
        if now < self.trigger_toast_until:
            toast_overlay = frame.copy()
            cv2.rectangle(toast_overlay, (20, h - 50), (w - 20, h - 10), (16, 185, 129), -1)
            cv2.addWeighted(toast_overlay, 0.85, frame, 0.15, 0, frame)
            frame = draw_chinese_text(frame, f"{self.last_triggered_text}  ⚡ 系統指令已執行", (32, h - 45), font_size=18, color=(255, 255, 255))
        else:
            frame = draw_chinese_text(frame, "🖐️ 懸停播放 | 👉 右揮下一頁 | 👈 左揮上一頁 | 👍 音量大 | 👎 音量小", (20, h - 42), font_size=14, color=(200, 200, 200))

        return frame

def main():
    print("=" * 65)
    print("【專題 12】AirTouch 無接觸手勢智慧遙控 啟動中...")
    print("=" * 65)
    print("手勢操作指南：")
    print("  1. 🖐️ 手掌張開懸停 0.7 秒  -> 播放 / 暫停 (Space)")
    print("  2. 👉 食指快速往右滑動     -> 簡報下一頁 (Right Arrow)")
    print("  3. 👈 食指快速往左滑動     -> 簡報上一頁 (Left Arrow)")
    print("  4. 👍 豎起大拇指           -> 調大電腦音量 (Volume Up)")
    print("  5. 👎 大拇指朝下           -> 調小電腦音量 (Volume Down)")
    print("  6. 👌 食指拇指捏合         -> 靜音開關 (Mute)")
    print("-" * 65)
    print("鍵盤熱鍵控制：")
    print("  [M] 鍵：切換『鍵盤模擬 ON / 演示模式 OFF』")
    print("  [Q] 或 [ESC] 鍵：安全退出程式")
    print("=" * 65)

    controller = AirTouchController(model_path="hand_landmarker.task")

    # 尋找可用攝影機 (優先 0，備選 1, 2)
    cap = None
    for cam_idx in [0, 1, 2]:
        temp_cap = cv2.VideoCapture(cam_idx, cv2.CAP_DSHOW)
        if temp_cap.isOpened():
            ret, _ = temp_cap.read()
            if ret:
                cap = temp_cap
                print(f"[系統] 成功連接 WebCam 攝影機 (索引: {cam_idx})")
                break
            temp_cap.release()

    if cap is None:
        print("[錯誤] 找不到任何可用的攝影機！請檢查 USB 鏡頭連線或隱私權設定。")
        input("請按 Enter 鍵結束...")
        return

    # 設定鏡頭解析度 640x480 (低延遲、高幀率)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    cv2.namedWindow("AirTouch Gesture Remote", cv2.WINDOW_AUTOSIZE)

    prev_time = time.time()
    fps = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            print("[警告] 無法讀取影像幀！")
            break

        # 水平鏡像翻轉 (Mirror) - 讓使用者的右手對應畫面右手邊
        frame = cv2.flip(frame, 1)

        # 核心手勢運算與 HUD 繪製
        processed_frame = controller.process_frame(frame)

        # 計算 FPS
        curr_time = time.time()
        fps = int(1.0 / (curr_time - prev_time + 1e-6))
        prev_time = curr_time
        cv2.putText(processed_frame, f"FPS: {fps}", (processed_frame.shape[1] - 85, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)

        cv2.imshow("AirTouch Gesture Remote", processed_frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q') or key == ord('Q') or key == 27: # Q 或 ESC 退出
            print("[系統] 使用者結束程式。")
            break
        elif key == ord('m') or key == ord('M'):
            controller.simulate_os_keys = not controller.simulate_os_keys
            state_str = "開啟 (ON)" if controller.simulate_os_keys else "關閉 (OFF，僅視覺演示)"
            print(f"[模式切換] 實體鍵盤模擬已 {state_str}")

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
