@echo off
pushd "%~dp0"
python webcam_ai_detect.py
if errorlevel 1 (
    echo.
    echo Application exited with error.
    pause
)
popd
