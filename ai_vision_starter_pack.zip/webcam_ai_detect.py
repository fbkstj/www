"""
Logi C270 實時 AI 影像辨識範例腳本
支援三種常用模型熱切換：
  [1] 物件偵測 (Object Detection - 80種物件)
  [2] 人體姿態骨架 (Pose Estimation - 17個關鍵關節點)
  [3] 影像分割去背 (Instance Segmentation - 輪廓分割)

按鍵說明：
  - 按 '1'：切換為物件偵測模型
  - 按 '2'：切換為人體骨架模型
  - 按 '3'：切換為語意分割模型
  - 按 'q' 或 'ESC'：關閉離開
"""

import cv2
import time
from ultralytics import YOLO

def main():
    print("正在載入 AI 模型...")
    models = {
        "1": (YOLO("yolo11n.pt"), "物件偵測 (Object Detection)"),
        "2": (YOLO("yolo11n-pose.pt"), "人體姿態 (Pose Estimation)"),
        "3": (YOLO("yolo11n-seg.pt"), "影像分割 (Segmentation)")
    }
    
    current_mode = "1"
    model, mode_name = models[current_mode]

    # 開啟 Logi C270 網路攝影機 (通常為 0)
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    
    # 設定攝影機解析度為 1280x720 (720p HD)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))

    if not cap.isOpened():
        print("錯誤：無法開啟攝影機！")
        return

    print("=" * 50)
    print("攝影機已啟動！")
    print("鍵盤按鍵：[1] 物件偵測 | [2] 人體姿態 | [3] 影像分割 | [q] 退出")
    print("=" * 50)

    prev_time = time.time()

    while True:
        ret, frame = cap.read()
        if not ret:
            print("無法讀取畫面串流！")
            break

        # 執行即時推論 (串流模式，推論極快)
        results = model(frame, verbose=False)
        annotated_frame = results[0].plot()

        # 計算即時 FPS
        curr_time = time.time()
        fps = 1.0 / (curr_time - prev_time) if (curr_time - prev_time) > 0 else 0
        prev_time = curr_time

        # 在畫面上繪製狀態資訊
        cv2.putText(annotated_frame, f"Mode: {mode_name}", (20, 40), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        cv2.putText(annotated_frame, f"FPS: {fps:.1f}", (20, 80), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)
        cv2.putText(annotated_frame, "Keys: [1] Detect  [2] Pose  [3] Seg  [q] Quit", (20, 120), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1)

        # 顯示即時視窗
        cv2.imshow("Logi C270 AI Vision", annotated_frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q') or key == 27:
            break
        elif chr(key) in models:
            current_mode = chr(key)
            model, mode_name = models[current_mode]
            print(f"切換模式為：{mode_name}")

    cap.release()
    cv2.destroyAllWindows()
    print("辨識已結束。")

if __name__ == "__main__":
    main()
