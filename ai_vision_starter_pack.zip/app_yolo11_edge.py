"""
YOLO11 CPU 邊緣推論實時物件偵測桌面應用
專為 Logi C270 網路攝影機與 CPU 輕量化推論最佳化

特色功能：
  1. 採用 YOLO11 Nano (yolo11n.pt)，CPU 輕量級即時推論 (25~35 FPS)。
  2. CustomTkinter 現代深色主題 UI 介面，支援多執行緒流暢更新。
  3. 內建完整 80 種 COCO 物件之繁體中文對照字典。
  4. 實時顯示 CPU 推論延遲 (ms) 與畫面 FPS。
  5. 支援動態信心度門檻調整滑桿與一鍵截圖存檔。
"""

import os
import sys
import time
import threading
from datetime import datetime
import cv2
from PIL import Image, ImageTk
import customtkinter as ctk
from ultralytics import YOLO

# 設定 CustomTkinter 外觀
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

# COCO 80 種物件英文名稱對應之標準繁體中文翻譯字典
COCO_CLASSES_ZH = {
    "person": "人", "bicycle": "腳踏車", "car": "汽車", "motorcycle": "機車",
    "airplane": "飛機", "bus": "公車", "train": "火車", "truck": "卡車", "boat": "船",
    "traffic light": "紅綠燈", "fire hydrant": "消防栓", "stop sign": "停車標誌",
    "parking meter": "停車收費表", "bench": "長椅", "bird": "鳥", "cat": "貓",
    "dog": "狗", "horse": "馬", "sheep": "羊", "cow": "牛", "elephant": "大象",
    "bear": "熊", "zebra": "斑馬", "giraffe": "長頸鹿", "backpack": "背包",
    "umbrella": "雨傘", "handbag": "手提包", "tie": "領帶", "suitcase": "行李箱",
    "frisbee": "飛盤", "skis": "滑雪板", "snowboard": "單板滑雪", "sports ball": "運動球類",
    "kite": "風箏", "baseball bat": "棒球棒", "baseball glove": "棒球手套", "skateboard": "滑板",
    "surfboard": "衝浪板", "tennis racket": "網球拍", "bottle": "水瓶/瓶子", "wine glass": "高腳杯",
    "cup": "水杯/馬克杯", "fork": "叉子", "knife": "刀子", "spoon": "湯匙", "bowl": "碗",
    "banana": "香蕉", "apple": "蘋果", "sandwich": "三明治", "orange": "橘子",
    "broccoli": "花椰菜", "carrot": "胡蘿蔔", "hot dog": "熱狗", "pizza": "披薩",
    "donut": "甜甜圈", "cake": "蛋糕", "chair": "椅子", "couch": "沙發",
    "potted plant": "盆栽/植栽", "bed": "床", "dining table": "餐桌", "toilet": "馬桶",
    "tv": "電視/螢幕", "laptop": "筆記型電腦", "mouse": "滑鼠", "remote": "遙控器",
    "keyboard": "鍵盤", "cell phone": "智慧型手機", "microwave": "微波爐", "oven": "烤箱",
    "toaster": "烤麵包機", "sink": "水槽", "refrigerator": "冰箱", "book": "書籍/書本",
    "clock": "時鐘", "vase": "花瓶", "scissors": "剪刀", "teddy bear": "泰迪熊",
    "hair drier": "吹風機", "toothbrush": "牙刷"
}

class YoloEdgeApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # 視窗基礎設定
        self.title("Logi C270 - YOLO11 CPU 邊緣推論實時偵測系統")
        self.geometry("1180x720")
        self.minsize(980, 640)

        # 建立截圖資料夾
        self.screenshot_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "screenshots")
        os.makedirs(self.screenshot_dir, exist_ok=True)

        # 狀態控制變數
        self.is_running = True
        self.is_paused = False
        self.conf_threshold = 0.45
        self.current_annotated_frame = None
        self.lock = threading.Lock()

        # 效能數據變數
        self.inference_time_ms = 0.0
        self.display_fps = 0.0
        self.detected_counts = {}

        # 1. 載入 YOLO11 模型
        print("正在載入 YOLO11 Nano 模型 (yolo11n.pt)...")
        self.model = YOLO("yolo11n.pt")
        print("YOLO11 模型載入成功！")

        # 2. 初始化攝影機 (Logi C270 720p HD)
        print("正在啟動 Logi C270 攝影機...")
        self.cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))

        if not self.cap.isOpened():
            print("警告：無法以 DSHOW 開啟攝影機，嘗試預設模式...")
            self.cap = cv2.VideoCapture(0)

        # 3. 建立 UI 佈局
        self._build_ui()

        # 確保視窗置頂彈出至前景
        self.lift()
        self.attributes('-topmost', True)
        self.after(500, lambda: self.attributes('-topmost', False))
        self.focus_force()

        # 4. 啟動背景推論執行緒
        self.worker_thread = threading.Thread(target=self._inference_loop, daemon=True)
        self.worker_thread.start()

        # 5. 啟動定時更新 UI 循環 (約 30 FPS)
        self._update_gui()

        # 關閉視窗處理
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self):
        # 主網格佈局：左側視訊顯示、右側控制儀表板
        self.grid_columnconfigure(0, weight=3)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # --- 左側視訊區域 ---
        self.video_frame = ctk.CTkFrame(self, corner_radius=12)
        self.video_frame.grid(row=0, column=0, padx=(15, 10), pady=15, sticky="nsew")
        self.video_frame.grid_rowconfigure(0, weight=1)
        self.video_frame.grid_columnconfigure(0, weight=1)

        self.video_label = ctk.CTkLabel(self.video_frame, text="正在啟動鏡頭串流...", font=("微軟正黑體", 16))
        self.video_label.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

        # --- 右側控制面板 ---
        self.control_panel = ctk.CTkFrame(self, corner_radius=12, width=320)
        self.control_panel.grid(row=0, column=1, padx=(10, 15), pady=15, sticky="nsew")
        self.control_panel.grid_propagate(False)

        # 標題
        title_label = ctk.CTkLabel(
            self.control_panel, 
            text="AI 邊緣推論監控儀表", 
            font=("微軟正黑體", 20, "bold")
        )
        title_label.pack(pady=(15, 10), padx=15, anchor="w")

        subtitle_label = ctk.CTkLabel(
            self.control_panel, 
            text="Model: YOLO11 Nano (CPU SOTA)", 
            text_color="gray",
            font=("Segoe UI", 12)
        )
        subtitle_label.pack(pady=(0, 15), padx=15, anchor="w")

        # --- 效能指標卡片 ---
        perf_card = ctk.CTkFrame(self.control_panel, corner_radius=8, fg_color=("gray85", "gray20"))
        perf_card.pack(fill="x", padx=15, pady=5)

        self.fps_label = ctk.CTkLabel(
            perf_card, 
            text="即時幀率：-- FPS", 
            font=("微軟正黑體", 14, "bold"),
            text_color="#10b981"
        )
        self.fps_label.pack(pady=(8, 2), padx=10, anchor="w")

        self.latency_label = ctk.CTkLabel(
            perf_card, 
            text="推論延遲：-- ms", 
            font=("微軟正黑體", 13),
            text_color="#38bdf8"
        )
        self.latency_label.pack(pady=(0, 8), padx=10, anchor="w")

        # --- 信心度門檻控制 ---
        slider_card = ctk.CTkFrame(self.control_panel, corner_radius=8, fg_color=("gray85", "gray20"))
        slider_card.pack(fill="x", padx=15, pady=10)

        self.conf_text_label = ctk.CTkLabel(
            slider_card, 
            text=f"信心度門檻：{int(self.conf_threshold * 100)}%", 
            font=("微軟正黑體", 13, "bold")
        )
        self.conf_text_label.pack(pady=(8, 2), padx=10, anchor="w")

        self.conf_slider = ctk.CTkSlider(
            slider_card, 
            from_=0.10, 
            to=0.90, 
            number_of_steps=80, 
            command=self._on_slider_change
        )
        self.conf_slider.set(self.conf_threshold)
        self.conf_slider.pack(fill="x", padx=10, pady=(2, 8))

        # --- 偵測物品清單統計 ---
        stat_title = ctk.CTkLabel(
            self.control_panel, 
            text="即時偵測物品統計：", 
            font=("微軟正黑體", 14, "bold")
        )
        stat_title.pack(pady=(10, 5), padx=15, anchor="w")

        self.stat_box = ctk.CTkTextbox(
            self.control_panel, 
            height=180, 
            corner_radius=8,
            font=("微軟正黑體", 13)
        )
        self.stat_box.pack(fill="both", expand=True, padx=15, pady=(0, 10))
        self.stat_box.insert("1.0", "尚未偵測到物件...")
        self.stat_box.configure(state="disabled")

        # --- 控制按鈕區 ---
        btn_frame = ctk.CTkFrame(self.control_panel, fg_color="transparent")
        btn_frame.pack(fill="x", padx=15, pady=(5, 15))

        self.pause_btn = ctk.CTkButton(
            btn_frame, 
            text="⏸️ 暫停畫面", 
            command=self._toggle_pause,
            fg_color="#3b82f6",
            hover_color="#2563eb",
            font=("微軟正黑體", 13)
        )
        self.pause_btn.pack(fill="x", pady=4)

        self.snapshot_btn = ctk.CTkButton(
            btn_frame, 
            text="📸 截圖存檔", 
            command=self._take_snapshot,
            fg_color="#10b981",
            hover_color="#059669",
            font=("微軟正黑體", 13)
        )
        self.snapshot_btn.pack(fill="x", pady=4)

        self.tip_label = ctk.CTkLabel(
            self.control_panel, 
            text="截圖將儲存於專案 screenshots 目錄", 
            text_color="gray",
            font=("微軟正黑體", 11)
        )
        self.tip_label.pack(pady=(0, 10))

    def _on_slider_change(self, val):
        self.conf_threshold = float(val)
        self.conf_text_label.configure(text=f"信心度門檻：{int(self.conf_threshold * 100)}%")

    def _toggle_pause(self):
        self.is_paused = not self.is_paused
        if self.is_paused:
            self.pause_btn.configure(text="▶️ 繼續串流", fg_color="#f59e0b", hover_color="#d97706")
        else:
            self.pause_btn.configure(text="⏸️ 暫停畫面", fg_color="#3b82f6", hover_color="#2563eb")

    def _take_snapshot(self):
        with self.lock:
            if self.current_annotated_frame is not None:
                filename = f"detection_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
                save_path = os.path.join(self.screenshot_dir, filename)
                cv2.imwrite(save_path, self.current_annotated_frame)
                self.tip_label.configure(text=f"✅ 已存檔：{filename}", text_color="#10b981")
                # 3 秒後復原提示
                self.after(3000, lambda: self.tip_label.configure(
                    text="截圖將儲存於專案 screenshots 目錄", text_color="gray"
                ))

    def _inference_loop(self):
        """背景影像讀取與 YOLO11 推論循環"""
        prev_time = time.time()

        while self.is_running:
            if self.is_paused:
                time.sleep(0.05)
                continue

            ret, frame = self.cap.read()
            if not ret:
                time.sleep(0.02)
                continue

            # 記錄推論起始時間
            t_start = time.perf_counter()

            # 執行 YOLO11 推論
            results = self.model(frame, conf=self.conf_threshold, verbose=False)
            t_end = time.perf_counter()

            # 計算單幀推論延遲 (ms)
            latency = (t_end - t_start) * 1000.0

            # 計算綜合顯示 FPS
            curr_time = time.time()
            fps = 1.0 / (curr_time - prev_time) if (curr_time - prev_time) > 0 else 0
            prev_time = curr_time

            # 統計當前幀所偵測到的各類別數量
            counts = {}
            annotated = frame.copy()
            boxes = results[0].boxes

            if boxes is not None and len(boxes) > 0:
                for box in boxes:
                    cls_id = int(box.cls[0].item())
                    conf_val = float(box.conf[0].item())
                    class_en = self.model.names[cls_id]
                    class_zh = COCO_CLASSES_ZH.get(class_en, class_en)
                    counts[class_zh] = counts.get(class_zh, 0) + 1

                    # 取得座標 [x1, y1, x2, y2]
                    xyxy = box.xyxy[0].cpu().numpy().astype(int)
                    x1, y1, x2, y2 = xyxy

                    # 繪製邊界框與半透明標籤底色
                    color = (0, 220, 110) # 翡翠綠
                    cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)

                    # 標籤文字 (英文類別 + 繁中名稱 + 信心度)
                    label_text = f"{class_zh} {int(conf_val * 100)}%"
                    (w, h), _ = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 1)
                    cv2.rectangle(annotated, (x1, y1 - 22), (x1 + w + 10, y1), color, -1)
                    cv2.putText(annotated, label_text, (x1 + 5, y1 - 6),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 1, cv2.LINE_AA)

            with self.lock:
                self.current_annotated_frame = annotated
                self.inference_time_ms = latency
                self.display_fps = fps
                self.detected_counts = counts

            time.sleep(0.005) # 讓出微小 CPU 時間

    def _update_gui(self):
        """定時將最新推論幀渲染至 CustomTkinter 視窗"""
        frame_to_render = None
        latency = 0.0
        fps = 0.0
        counts = {}

        with self.lock:
            if self.current_annotated_frame is not None:
                frame_to_render = self.current_annotated_frame.copy()
                latency = self.inference_time_ms
                fps = self.display_fps
                counts = self.detected_counts.copy()

        if frame_to_render is not None:
            # 取得視訊容器大小進行比例縮放，保證初次載入即有適當預設值
            vf_w = self.video_frame.winfo_width()
            vf_h = self.video_frame.winfo_height()

            disp_w = vf_w - 20 if vf_w > 200 else 720
            disp_h = vf_h - 20 if vf_h > 200 else 405

            h, w, _ = frame_to_render.shape
            scale = min(disp_w / w, disp_h / h)
            new_w = max(int(w * scale), 320)
            new_h = max(int(h * scale), 240)
            resized = cv2.resize(frame_to_render, (new_w, new_h), interpolation=cv2.INTER_AREA)

            # 轉換 BGR ➜ RGB ➜ CTkImage
            rgb_img = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
            pil_img = Image.fromarray(rgb_img)
            ctk_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(new_w, new_h))
            self.video_label.configure(image=ctk_img, text="")
            self.video_label.image = ctk_img  # 保留引用避免被垃圾回收

            # 更新數值面板
            self.fps_label.configure(text=f"即時幀率：{fps:.1f} FPS")
            self.latency_label.configure(text=f"推論延遲：{latency:.1f} ms")

            # 更新統計清單
            self.stat_box.configure(state="normal")
            self.stat_box.delete("1.0", "end")
            if counts:
                total_items = sum(counts.values())
                summary_text = f"【目前畫面上共 {total_items} 個目標】\n"
                summary_text += "-" * 26 + "\n"
                for item_name, count in counts.items():
                    summary_text += f"• {item_name}：{count}\n"
                self.stat_box.insert("1.0", summary_text)
            else:
                self.stat_box.insert("1.0", "無偵測目標 (可嘗試調低信心度)")
            self.stat_box.configure(state="disabled")

        if self.is_running:
            # 每 33 毫秒更新一次 (約 30 FPS)
            self.after(33, self._update_gui)

    def on_close(self):
        """安全關閉資源"""
        print("正在關閉程式並釋放攝影機...")
        self.is_running = False
        time.sleep(0.1)
        if self.cap and self.cap.isOpened():
            self.cap.release()
        self.destroy()
        sys.exit(0)

if __name__ == "__main__":
    app = YoloEdgeApp()
    app.mainloop()
