# 筆電＋USB 攝影機版：影像物聯網與 AI 視覺（兩天 12 單元）程式包

把原本用 AMB82-Mini 開發板做的兩天課程，全部改成「筆電＋USB 攝影機」就能做。
完整講義（課程規劃、操作步驟、AI 提示語、情境模擬動畫）：https://fbkstj.github.io/www/#page/laptop_cam_course_guide

## 一、第一次使用（約 15 分鐘，請在家或課前做完）
```
pip install -r requirements.txt
python tools/download_models.py        下載 YOLO、人臉、姿態模型（約 50 MB）
python tools/make_demo_media.py        產生示範影片（不用開鏡頭也能練習）
python tests/run_all_tests.py          一鍵驗收：12 單元應該全部 OK
```
影像串流（d1_02）另外需要 ffmpeg：`winget install Gyan.FFmpeg`，裝完重開終端機。

## 二、每支程式都有的共同參數
| 參數 | 意思 |
|---|---|
| `--source 0` | 用第 0 支攝影機（USB 攝影機通常是 1；用 `python tools/list_cameras.py` 查） |
| `--source demo/street.mp4` | 用影片代替攝影機（同一段影片每次結果都一樣，最適合測試與比較） |
| `--no-window` | 不開視窗 |
| `--max-frames 300` | 跑 300 張就停 |
| `--out result.mp4` | 把畫好框的畫面存成影片（交報告用） |
視窗裡按 `q` 或 `Esc` 結束。

## 三、12 個單元
| 程式 | 單元 | 做出什麼 | 原 AMB82 版 |
|---|---|---|---|
| `d1_01_snapshot.py` | 第 1 天第 1 節 | 定時拍照存檔、按 s 手動拍 | 01_camera_snapshot |
| `d1_02_stream.py` | 第 1 天第 2 節 | 用 ffmpeg 送出 RTP／TCP／RTSP 串流，VLC 觀看 | 02_rtsp_stream |
| `d1_03_web_cam.py` | 第 1 天第 3 節 | 手機瀏覽器看即時畫面、遙控虛擬 LED（可設 key） | 03_ap_web_snapshot |
| `d1_04_cloud_upload.py` | 第 1 天第 4 節 | 有人經過就拍照上傳雲端硬碟＋試算表（可推 LINE） | 04_cloud_upload |
| `d1_05_record.py` | 第 1 天第 5 節 | 錄 MP4（含觸發前 2 秒）、TFT 狀態小視窗 | 05_record_mp4_tft |
| `d1_06_telegram_bot.py` | 第 1 天第 6 節 | Telegram 指令：/photo /clip /status /led /alarm | 06_telegram_bot |
| `d2_01a_motion.py` | 第 2 天第 1 節 | 格子比對移動偵測 | 01a_motion_detect |
| `d2_01b_qr_gate.py` | 第 2 天第 1 節 | QR 白名單門禁＋簽到紀錄 | 01b_qr_scan |
| `d2_02_face_door.py` | 第 2 天第 2 節 | YuNet＋SFace 人臉門禁（防尾隨） | 02_face_door |
| `d2_03_fence_mqtt.py` | 第 2 天第 3 節 | YOLO11 電子圍籬（滑鼠畫禁區）＋MQTT 通報 | 03_fence_mqtt |
| `d2_04_train_custom.py` | 第 2 天第 4 節 | 檢查資料集 → 訓練 → 驗證 → 接到圍籬 | 04_custom_model |
| `d2_05_pose.py` | 第 2 天第 5 節 | MediaPipe 33 點姿態辨識 | pc_pose/pose_basics |
| `d2_06_pose_to_device.py`＋`d2_06_virtual_device.py` | 第 2 天第 6 節 | 用姿勢透過 MQTT 遙控虛擬裝置 | pose_to_mqtt＋06_mqtt_actuator |

## 四、工具
| 檔案 | 用途 |
|---|---|
| `tools/mini_broker.py` | 自己筆電上的 MQTT 轉送站（學校擋 1883、或不想用公開伺服器時） |
| `tools/mqtt_check.py` | 訂閱／送出 MQTT 訊息 |
| `tools/fake_appscript.py` | 本機假的 Apps Script，不用 Google 帳號也能練習上傳 |
| `tools/dataset_check.py` | 訓練前檢查 YOLO 資料集 |
| `tools/make_demo_dataset.py` | 產生練習用資料集（三角錐／球） |
| `tools/list_cameras.py` | 列出可用的攝影機編號與解析度 |
| `apps_script/Code.gs` | Google Apps Script 接收端（和 AMB82 版共用） |

## 五、隱私與安全
- 程式打開攝影機前會先提醒；**開鏡頭前請先告訴鏡頭前的人**。練習優先用 `--source demo/...`。
- 人臉只存 128 個數字（`faces/face_db.npz`），不存照片；**下課前執行** `python d2_02_face_door.py --reset`。
- Apps Script 網址、Telegram Token 等於密碼：不要寫進程式交出去、不要貼到報告或 GitHub，改用環境變數。
- `d1_03_web_cam.py` 要用 ngrok 對外時一定要加 `--key`，課後關掉。
- 預設 MQTT 連自己筆電（127.0.0.1），不會把訊息送到公開伺服器。

## 六、常見狀況
| 狀況 | 先檢查 |
|---|---|
| 打不開攝影機 | 換 `--source 1`；關掉 Teams／Meet；Windows 設定 → 隱私權 → 相機 |
| 畫面很卡 | `--size 640x480`；關掉其他程式；YOLO 在沒有顯示卡的筆電約每秒 7～15 張 |
| 中文路徑存不了檔 | 程式已用 `imencode＋tofile` 處理；自己寫的程式也要這樣 |
| QR 一直讀不到 | 不要鏡像（這支預設不鏡像）、拿近一點、避開反光 |
| MQTT 連不上 | 先開 `python tools/mini_broker.py`；其他裝置要填筆電 IP，並在防火牆允許 |
| 姿勢左右相反 | 要用「沒翻過」的畫面判斷，顯示時才鏡像（程式已這樣做） |
