"""第 1 天 第 2 節：把筆電攝影機變成串流來源（RTP／TCP／RTSP 三種都做一次）
（原 AMB82 版：02_rtsp_stream，板子當 RTSP 伺服器）

筆電本身不會「送影片」，這裡用 ffmpeg（免費的影音瑞士刀）幫忙：
  rtp   ffmpeg 直接把畫面一包一包丟到某台電腦（UDP），VLC 開 stream.sdp 播放
  tcp   ffmpeg 開一個 TCP 服務，VLC 連 tcp://筆電IP:5000 播放（會確認、會重送）
  rtsp  需要另外執行 MediaMTX（免費的 RTSP 伺服器），ffmpeg 把畫面推上去，
        大家用 rtsp://筆電IP:8554/cam 觀看（最接近原本板子的做法）

用法：
  python d1_02_stream.py --list                                  列出 ffmpeg 看得到的攝影機名稱
  python d1_02_stream.py --mode tcp --device "USB2.0 HD UVC WebCam"
  python d1_02_stream.py --mode tcp --file demo/street.mp4       不開鏡頭，用示範影片練習
  python d1_02_stream.py --mode rtp --file demo/street.mp4 --to 192.168.1.23
  python d1_02_stream.py --mode rtsp --device "USB Camera"       先開好 MediaMTX
  python d1_02_stream.py --mode tcp --file demo/street.mp4 --print-only   只印出指令、不執行
觀看端：VLC → 媒體 → 開啟網路串流，網址看程式印出來的那一行
"""
import os
import re
import shutil
import socket
import subprocess
import sys

from camlib import HERE, new_parser


def lan_ip():
    """找出筆電在區網的 IP（不會真的送封包出去）。"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def list_cameras():
    if not shutil.which("ffmpeg"):
        print("找不到 ffmpeg，請先安裝：winget install Gyan.FFmpeg（裝完重開終端機）")
        return 1
    r = subprocess.run(["ffmpeg", "-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    names = re.findall(r'"([^"]+)"\s+\(video\)', r.stderr)
    if not names:
        print("沒找到攝影機（或不是 Windows）。ffmpeg 回應：")
        print(r.stderr[-800:])
        return 1
    print("ffmpeg 看得到的攝影機：")
    for n in names:
        print(f'  --device "{n}"')
    return 0


def build_command(args):
    """組出 ffmpeg 指令。回傳 (指令清單, 給觀看端的網址說明)。"""
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "warning"]
    if args.file:
        path = args.file if os.path.exists(args.file) else os.path.join(HERE, args.file)
        cmd += ["-re", "-stream_loop", "-1", "-i", path]          # -re：照影片原本的速度送
    else:
        cmd += ["-f", "dshow", "-video_size", args.size, "-framerate", str(args.fps),
                "-i", f"video={args.device}"]
    # 低延遲 H.264：ultrafast＋zerolatency；-g 每秒一張關鍵畫面，觀看端比較快出現畫面
    # repeat-headers：每張關鍵畫面都附上解碼設定，中途才加入的觀看端也能馬上出畫面
    cmd += ["-an", "-c:v", "libx264", "-preset", "ultrafast", "-tune", "zerolatency",
            "-x264-params", "repeat-headers=1",
            "-pix_fmt", "yuv420p", "-b:v", args.bitrate, "-g", str(args.fps)]
    ip = lan_ip()
    if args.mode == "tcp":
        url = f"tcp://0.0.0.0:{args.port}?listen=1"
        cmd += ["-f", "mpegts", url]
        watch = f"tcp://{ip}:{args.port}"
    elif args.mode == "rtp":
        sdp = os.path.join(HERE, "stream.sdp")
        cmd += ["-f", "rtp", "-sdp_file", sdp, f"rtp://{args.to}:{args.port}"]
        watch = f"VLC 開啟檔案 {sdp}（要在 {args.to} 那台電腦上開）"
    else:
        cmd += ["-f", "rtsp", "-rtsp_transport", args.transport, f"rtsp://127.0.0.1:8554/{args.path}"]
        watch = f"rtsp://{ip}:8554/{args.path}"
    return cmd, watch


def main(argv=None):
    ap = new_parser(__doc__)
    ap.add_argument("--list", action="store_true", help="列出攝影機名稱")
    ap.add_argument("--mode", choices=["tcp", "rtp", "rtsp"], default="tcp")
    ap.add_argument("--device", help="攝影機名稱（用 --list 查）")
    ap.add_argument("--file", help="用影片檔代替攝影機")
    ap.add_argument("--size", default="1280x720")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--bitrate", default="2M", help="位元率：1M 比較順，4M 比較清楚")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--to", default="127.0.0.1", help="rtp 模式：要收看的那台電腦 IP")
    ap.add_argument("--transport", choices=["udp", "tcp"], default="tcp", help="rtsp 模式推流用的傳輸方式")
    ap.add_argument("--path", default="cam", help="rtsp 模式的路徑名稱")
    ap.add_argument("--print-only", action="store_true", help="只印出 ffmpeg 指令")
    args = ap.parse_args(argv)

    if args.list:
        return list_cameras()
    if not args.file and not args.device:
        print("請指定 --device \"攝影機名稱\"（用 --list 查），或用 --file demo/street.mp4 練習")
        return 1
    cmd, watch = build_command(args)
    print("ffmpeg 指令：")
    print("  " + " ".join(f'"{c}"' if " " in c else c for c in cmd))
    print(f"\n觀看方式：{watch}")
    if args.mode == "rtsp":
        print("（rtsp 模式要先執行 MediaMTX；沒開的話 ffmpeg 會馬上顯示 Connection refused）")
    if args.print_only:
        return 0
    if not shutil.which("ffmpeg"):
        print("找不到 ffmpeg，請先安裝：winget install Gyan.FFmpeg（裝完重開終端機）")
        return 1
    if not args.file:
        print("[注意] 即將打開攝影機，請先確認鏡頭前的人都知道。")
    print("串流中，按 Ctrl+C 結束")
    try:
        while True:
            code = subprocess.call(cmd)
            if args.mode != "tcp":
                return code
            # tcp 模式一次只服務一個觀看端，對方關掉 VLC 後 ffmpeg 會結束，這裡自動重開
            print("觀看端離線了，重新等待下一個連線…（Ctrl+C 結束）")
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
