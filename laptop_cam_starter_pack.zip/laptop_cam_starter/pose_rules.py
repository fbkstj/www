"""姿態判斷規則（純計算，不開鏡頭、不需要安裝 mediapipe）

把 MediaPipe Pose 給的 33 個關節點座標，換成一個動作名稱。
分成兩層：
  classify_pose()  一張畫面 → 一個動作（只看幾何關係，寫死的規則）
  PoseTrigger      連續很多張畫面 → 穩定的觸發事件（防止手抖一下就送指令）

座標說明（和 MediaPipe 一樣）：
  x 0.0（畫面最左）～ 1.0（最右）
  y 0.0（畫面最上）～ 1.0（最下）  ← 注意 y 越小代表越「高」
  visibility 0.0～1.0，太低代表這個關節被擋住或跑出畫面

左右提醒：MediaPipe 的 LEFT 指的是「那個人自己的左邊」，前提是給它「沒翻過」的畫面。
如果先把畫面鏡像再丟給 MediaPipe，左右會對調；所以程式是先判斷、判斷完才鏡像顯示。
"""

# 用得到的關節點編號（MediaPipe Pose 共 33 點）
NOSE = 0
L_SHOULDER, R_SHOULDER = 11, 12
L_ELBOW, R_ELBOW = 13, 14
L_WRIST, R_WRIST = 15, 16
L_HIP, R_HIP = 23, 24
L_KNEE, R_KNEE = 25, 26
L_ANKLE, R_ANKLE = 27, 28

KEY_POINTS = (L_SHOULDER, R_SHOULDER, L_HIP, R_HIP)

# ====== 可以調整的門檻 ======
RAISE_MARGIN = 0.05      # 手腕要高過肩膀多少（畫面高度的比例）才算舉手
LEVEL_MARGIN = 0.08      # 手腕和肩膀差多少以內算「平舉」
ARM_OUT_MARGIN = 0.15    # 手腕離肩膀水平多遠才算「張開」
MIN_VISIBILITY = 0.5     # 關節點信心低於這個就當作看不到
SQUAT_RATIO = 1.2        # 蹲下判斷：腳踝到臀 < 肩到臀 × 這個倍數
# ============================

POSE_NAMES = {
    "none": "沒有動作",
    "no_person": "畫面裡沒有人",
    "raise_left": "舉左手",
    "raise_right": "舉右手",
    "both_up": "雙手舉高",
    "t_pose": "雙手平舉（T 字）",
    "squat": "蹲下",
    "fall": "倒下",
}


def _pt(landmarks, idx):
    """取出第 idx 個關節點，統一成 (x, y, visibility)。"""
    p = landmarks[idx]
    if isinstance(p, (list, tuple)):
        x, y = p[0], p[1]
        vis = p[2] if len(p) > 2 else 1.0
    else:  # mediapipe 的 NormalizedLandmark 物件
        x, y = p.x, p.y
        vis = getattr(p, "visibility", 1.0)
    return x, y, vis


def _visible(landmarks, idxs, min_vis=MIN_VISIBILITY):
    return all(_pt(landmarks, i)[2] >= min_vis for i in idxs)


def classify_pose(landmarks):
    """一張畫面的 33 個關節點 → 動作名稱字串。

    landmarks 可以是 mediapipe 的 landmark list，
    也可以是自己組的 [(x, y, visibility), ...]，方便寫測試。
    """
    if not landmarks or len(landmarks) < 29:
        return "no_person"
    if not _visible(landmarks, KEY_POINTS):
        return "no_person"

    lsx, lsy, _ = _pt(landmarks, L_SHOULDER)
    rsx, rsy, _ = _pt(landmarks, R_SHOULDER)
    lhx, lhy, _ = _pt(landmarks, L_HIP)
    rhx, rhy, _ = _pt(landmarks, R_HIP)

    shoulder_x = (lsx + rsx) / 2
    shoulder_y = (lsy + rsy) / 2
    hip_x = (lhx + rhx) / 2
    hip_y = (lhy + rhy) / 2

    # 1. 倒下：身體躺平時，肩膀到臀部「橫的距離」會大於「直的距離」
    if abs(hip_x - shoulder_x) > abs(hip_y - shoulder_y):
        return "fall"

    # 2. 手的動作
    lw_ok = _visible(landmarks, (L_WRIST,))
    rw_ok = _visible(landmarks, (R_WRIST,))
    lwx, lwy, _ = _pt(landmarks, L_WRIST)
    rwx, rwy, _ = _pt(landmarks, R_WRIST)

    left_up = lw_ok and lwy < lsy - RAISE_MARGIN
    right_up = rw_ok and rwy < rsy - RAISE_MARGIN

    if left_up and right_up:
        return "both_up"

    left_level = lw_ok and abs(lwy - lsy) < LEVEL_MARGIN and abs(lwx - lsx) > ARM_OUT_MARGIN
    right_level = rw_ok and abs(rwy - rsy) < LEVEL_MARGIN and abs(rwx - rsx) > ARM_OUT_MARGIN
    if left_level and right_level:
        return "t_pose"

    if left_up:
        return "raise_left"
    if right_up:
        return "raise_right"

    # 3. 蹲下：腳踝離臀部變近（大腿收起來了）
    if _visible(landmarks, (L_ANKLE, R_ANKLE)):
        ankle_y = (_pt(landmarks, L_ANKLE)[1] + _pt(landmarks, R_ANKLE)[1]) / 2
        torso = hip_y - shoulder_y
        if torso > 0 and (ankle_y - hip_y) < torso * SQUAT_RATIO:
            return "squat"

    return "none"


class PoseTrigger:
    """把每張畫面的判斷結果，變成穩定的「事件」。

    規則：
      - 最近 window 張畫面裡，同一個動作要出現超過一半（多數決，擋掉偶爾判錯的那一張）
      - 這個動作還要連續維持 hold 張畫面才送出（擋掉手隨便揮一下）
      - 送出後 cooldown 張畫面內不再送「同一個」動作（擋掉洗版）
        ※ 是分開計算的：舉左手的冷卻時間不會擋住接下來的蹲下
      - 動作要先回到 none 或換成別的動作，才能再觸發一次
    """

    def __init__(self, window=5, hold=6, cooldown=20):
        self.window = window
        self.hold = hold
        self.cooldown = cooldown
        self.history = []
        self.stable = "none"
        self.stable_frames = 0
        self.fired = None
        self.cool = {}    # 動作 → 還要等幾張畫面

    def _majority(self):
        if not self.history:
            return "none"
        counts = {}
        for name in self.history:
            counts[name] = counts.get(name, 0) + 1
        best, n = max(counts.items(), key=lambda kv: kv[1])
        return best if n * 2 > len(self.history) else self.stable

    def update(self, pose):
        """吃一張畫面的判斷結果；有事件才回傳動作名稱，否則回傳 None。"""
        self.history.append(pose)
        if len(self.history) > self.window:
            self.history.pop(0)
        for name in list(self.cool):
            self.cool[name] -= 1
            if self.cool[name] <= 0:
                del self.cool[name]

        now = self._majority()
        if now == self.stable:
            self.stable_frames += 1
        else:
            self.stable = now
            self.stable_frames = 1
            if now in ("none", "no_person"):
                self.fired = None    # 手放下了，下次可以再觸發

        if now in ("none", "no_person"):
            return None
        if self.stable_frames < self.hold:
            return None
        if self.fired == now or self.cool.get(now, 0) > 0:
            return None

        self.fired = now
        self.cool[now] = self.cooldown
        return now


# 動作 → 要送給板子的 MQTT 指令（可以自己改）
DEFAULT_COMMANDS = {
    "raise_left": "green_on",
    "raise_right": "green_off",
    "both_up": "blink",
    "t_pose": "open",
    "squat": "close",
    "fall": "blink",
}


def pose_to_command(pose, table=None):
    """動作名稱 → MQTT 指令字串；沒對應的動作回傳 None。"""
    return (table or DEFAULT_COMMANDS).get(pose)
