"""第 2 天 第 1 節（下半）：QR Code 門禁／簽到
（原 AMB82 版：01b_qr_scan）

拿 QR Code 給鏡頭看：內容在白名單（allow.txt）裡就亮綠燈「通過」，不在就亮藍燈「拒絕」，
每一筆都寫進 qr_log.csv（時間、內容、結果），就是一份簽到表。

用法：
  python d2_01b_qr_gate.py                               攝影機 0（QR 不要鏡像，否則讀不到）
  python d2_01b_qr_gate.py --source demo/qr.mp4          示範影片：S001、HACKER-01、S002、S001
  python d2_01b_qr_gate.py --allow S001,S002             直接指定白名單（不用 allow.txt）
QR 卡：demo/qr_cards/ 裡的圖可以印出來，或用手機打開給鏡頭看。
"""
import csv
import os
import sys
import time

import cv2
import numpy as np

from camlib import FrameLoop, add_source_args, led, new_parser, status_bar, HERE


def load_allow(arg):
    if arg:
        return {x.strip() for x in arg.split(",") if x.strip()}
    path = os.path.join(HERE, "allow.txt")
    if not os.path.exists(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write("# 一行一個允許通過的 QR 內容，# 開頭的是註解\nS001\nS002\nYMHS-306-01\n")
    with open(path, encoding="utf-8") as f:
        return {ln.strip() for ln in f if ln.strip() and not ln.startswith("#")}


def main(argv=None):
    ap = add_source_args(new_parser(__doc__), mirror=False)
    ap.add_argument("--allow", help="白名單，用逗號隔開（不給就讀 allow.txt）")
    ap.add_argument("--cooldown", type=float, default=3.0, help="同一張 QR 幾秒內不重複計")
    ap.add_argument("--log", default=os.path.join(HERE, "qr_log.csv"))
    args = ap.parse_args(argv)

    allow = load_allow(args.allow)
    print(f"白名單 {len(allow)} 筆：{', '.join(sorted(allow))}")
    detector = cv2.QRCodeDetector()
    loop = FrameLoop(args, "d2_01b qr gate", mirror_default=False)   # QR 鏡像後會讀不到
    last_code, last_seen = "", -1e9
    show_until, show_ok = -1.0, False
    passed = denied = 0
    new_log = not os.path.exists(args.log)
    logf = open(args.log, "a", newline="", encoding="utf-8-sig")
    writer = csv.writer(logf)
    if new_log:
        writer.writerow(["時間", "內容", "結果"])

    for frame in loop:
        now = loop.now()
        text, points, _ = detector.detectAndDecode(frame)
        view = frame.copy()
        if points is not None and len(points):
            cv2.polylines(view, [np.int32(points).reshape(-1, 1, 2)], True, (0, 255, 255), 3)
        text = (text or "").strip()
        if text:
            repeat = (text == last_code and now - last_seen < args.cooldown)
            last_seen = now
            if not repeat:
                last_code = text
                ok = text in allow
                passed += ok
                denied += (not ok)
                show_ok, show_until = ok, now + 1.0
                writer.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), text, "通過" if ok else "拒絕"])
                logf.flush()
                print(f"{'[通過]' if ok else '[拒絕]'} {text}　（影片時間 {now:4.1f} 秒；通過 {passed}／拒絕 {denied}）")
        lit = now < show_until
        status_bar(view, f"pass {passed}  deny {denied}   last: {last_code}")
        led(view, (view.shape[1] - 230, 60), lit and show_ok, (0, 220, 0), "PASS")
        led(view, (view.shape[1] - 110, 60), lit and not show_ok, (255, 120, 0), "DENY")
        loop.show(view)

    logf.close()
    print(f"結束：通過 {passed} 次、拒絕 {denied} 次，紀錄在 {args.log}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
