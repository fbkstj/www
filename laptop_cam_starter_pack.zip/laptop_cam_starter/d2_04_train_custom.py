"""第 2 天 第 4 節：用筆電訓練自己的 YOLO 模型，再拿來當電子圍籬的眼睛
（原 AMB82 版：04_custom_model，要 Colab 訓練＋線上轉 .nb＋放 SD 卡；筆電版一條指令就能跑完）

流程（這支程式一次做完）：
  1. 檢查資料集（tools/dataset_check.py）：類別編號、座標、缺標註
  2. 訓練（ultralytics YOLO11n，沒有獨立顯卡也能跑，只是慢一點）
  3. 驗證：印出 mAP50（找得到＋框得準的程度，0～1，越高越好）與每一類的成績
  4. 拿一張驗證圖實際偵測，存成 sample_pred.jpg 給你看
  5. 告訴你怎麼把模型接到 d2_03 電子圍籬

用法：
  python tools/make_demo_dataset.py                       先做一個練習用資料集（三角錐／球）
  python d2_04_train_custom.py --data datasets/demo_shapes --epochs 15
  python d2_04_train_custom.py --data D:/helmet_dataset --epochs 60 --imgsz 640   自己的資料集
資料集排法：images/train、images/val、labels/train、labels/val，外加 classes.txt 或 data.yaml
"""
import os
import sys

from camlib import HERE, imwrite_u, new_parser

sys.path.insert(0, os.path.join(HERE, "tools"))
import dataset_check  # noqa: E402


def ensure_yaml(data_dir):
    """沒有 data.yaml 就用 classes.txt 自動產生一份。"""
    yaml_path = os.path.join(data_dir, "data.yaml")
    if os.path.exists(yaml_path):
        return yaml_path
    classes = dataset_check.load_classes(data_dir, None)
    if not classes:
        raise SystemExit("找不到 data.yaml 也找不到 classes.txt，不知道有哪些類別")
    with open(yaml_path, "w", encoding="utf-8") as f:
        f.write(f"path: {os.path.abspath(data_dir).replace(os.sep, '/')}\ntrain: images/train\nval: images/val\nnames:\n")
        for i, c in enumerate(classes):
            f.write(f"  {i}: {c}\n")
    print("已自動產生", yaml_path)
    return yaml_path


def main(argv=None):
    ap = new_parser(__doc__)
    ap.add_argument("--data", required=True, help="資料集資料夾")
    ap.add_argument("--base", default=os.path.join(HERE, "models", "yolo11n.pt"), help="從哪個模型開始訓練")
    ap.add_argument("--epochs", type=int, default=30, help="訓練幾輪（練習用 15；正式專題 60～100）")
    ap.add_argument("--imgsz", type=int, default=320, help="訓練圖片大小（練習 320；正式 640）")
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--name", default="custom", help="結果存在 runs/<name>")
    ap.add_argument("--skip-check", action="store_true")
    args = ap.parse_args(argv)

    data_dir = args.data if os.path.isabs(args.data) else os.path.join(os.getcwd(), args.data)
    if not os.path.isdir(data_dir):
        data_dir = os.path.join(HERE, args.data)
    print("=" * 50, "\n步驟 1／4：檢查資料集\n" + "=" * 50)
    if not args.skip_check and dataset_check.check(data_dir, None) != 0:
        print("資料集有問題，先修好再訓練（或加 --skip-check 強制執行）")
        return 1
    yaml_path = ensure_yaml(data_dir)

    print("=" * 50, "\n步驟 2／4：訓練（每一輪會印一行進度）\n" + "=" * 50)
    from ultralytics import YOLO
    base = args.base if os.path.exists(args.base) else "yolo11n.pt"
    model = YOLO(base)
    project = os.path.join(HERE, "runs")
    # workers=0：Windows 上比較不會卡住；plots=False：少存一堆圖，比較快
    model.train(data=yaml_path, epochs=args.epochs, imgsz=args.imgsz, batch=args.batch,
                project=project, name=args.name, exist_ok=True, workers=0, plots=False, verbose=False)
    best = os.path.join(project, args.name, "weights", "best.pt")

    print("=" * 50, "\n步驟 3／4：驗證成績\n" + "=" * 50)
    trained = YOLO(best)
    metrics = trained.val(data=yaml_path, imgsz=args.imgsz, workers=0, plots=False, verbose=False)
    print(f"全部類別 mAP50 = {metrics.box.map50:.3f}　mAP50-95 = {metrics.box.map:.3f}")
    for i, c in trained.names.items():
        if i < len(metrics.box.ap50):
            print(f"  {c:<12} AP50 = {metrics.box.ap50[i]:.3f}")
    print("看法：mAP50 0.5 以上算堪用、0.8 以上算不錯；某一類特別低，通常是那一類照片太少或標得不一致。")

    print("=" * 50, "\n步驟 4／4：實際偵測一張驗證圖\n" + "=" * 50)
    val_dir = os.path.join(data_dir, "images", "val")
    sample = next((os.path.join(val_dir, f) for f in sorted(os.listdir(val_dir))
                   if f.lower().endswith((".jpg", ".png"))), None) if os.path.isdir(val_dir) else None
    if sample:
        r = trained(sample, verbose=False, imgsz=args.imgsz)[0]
        out = os.path.join(project, args.name, "sample_pred.jpg")
        imwrite_u(out, r.plot())
        found = [f"{trained.names[int(c)]} {s:.2f}" for c, s in zip(r.boxes.cls.tolist(), r.boxes.conf.tolist())]
        print(f"{os.path.basename(sample)} 偵測到：{', '.join(found) or '（沒有）'}")
        print("結果圖：", out)

    print("\n完成！模型在：", best)
    print("接到電子圍籬：")
    print(f'  python d2_03_fence_mqtt.py --model "{best}" --source 0')
    return 0


if __name__ == "__main__":
    sys.exit(main())
