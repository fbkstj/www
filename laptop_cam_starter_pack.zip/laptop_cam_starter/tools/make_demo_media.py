"""產生練習用的示範影片（不用開攝影機、不用拍同學，也能把每個單元測一遍）

執行：python tools/make_demo_media.py
會在 demo/ 資料夾產生：
  street.mp4        一個人從左走到右、走進右下角的禁區、停一下再離開（移動偵測、電子圍籬、錄影、串流用）
  qr.mp4            依序出現 S001、HACKER-01、S002、S001 四張 QR 卡（QR 門禁用）
  faces.mp4         先兩張臉同框、再只有 A、再只有 B（人臉門禁用）
  register_tom.jpg  A 的另一張照片，拿來「註冊」成 Tom
  qr_cards/*.png    可以印出來或用手機顯示的 QR 卡

素材來自 ultralytics 套件內附的兩張公開範例照片（bus.jpg、zidane.jpg）。
影片是用固定亂數種子產生的，所以每個人產生的影片都一模一樣，測試結果才能互相比對。
"""
import os
import sys

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from camlib import imread_u, imwrite_u  # noqa: E402

DEMO = os.path.join(ROOT, "demo")
W, H, FPS = 1280, 720, 30


def sample_image(name):
    """先找 ultralytics 內附的範例圖，找不到再上網下載。"""
    try:
        import ultralytics
        p = os.path.join(os.path.dirname(ultralytics.__file__), "assets", name)
        if os.path.exists(p):
            return imread_u(p)
    except ImportError:
        pass
    import urllib.request
    dest = os.path.join(DEMO, name)
    if not os.path.exists(dest):
        print(f"  下載範例圖 {name} …")
        urllib.request.urlretrieve(f"https://ultralytics.com/images/{name}", dest)
    return imread_u(dest)


def writer(name):
    path = os.path.join(DEMO, name)
    return path, cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), FPS, (W, H))


def add_noise(frame, rng, sigma=2.0):
    """真的攝影機畫面會有細小雜訊，移動偵測的門檻就是要能忽略這些。"""
    noise = rng.normal(0, sigma, frame.shape)
    return np.clip(frame.astype(np.int16) + noise, 0, 255).astype(np.uint8)


# ---------- 1. 走廊 ----------
def make_background():
    bg = np.zeros((H, W, 3), np.uint8)
    bg[:430] = (205, 215, 222)            # 牆
    bg[430:] = (150, 150, 155)            # 地板
    for x in range(-600, W + 600, 160):   # 地磚線（有一點透視）
        cv2.line(bg, (W // 2 + (x - W // 2) // 3, 430), (x, H), (135, 135, 140), 2)
    for y in (500, 590, 690):
        cv2.line(bg, (0, y), (W, y), (135, 135, 140), 2)
    cv2.rectangle(bg, (90, 150), (260, 430), (90, 120, 160), -1)      # 門
    cv2.circle(bg, (240, 300), 8, (40, 40, 40), -1)
    cv2.rectangle(bg, (980, 250), (1180, 430), (70, 80, 90), -1)      # 機櫃
    cv2.putText(bg, "LAB", (1030, 350), cv2.FONT_HERSHEY_SIMPLEX, 1.4, (230, 230, 230), 3)
    return bg


def paste(frame, sprite, x, y_bottom):
    h, w = sprite.shape[:2]
    x0, y0 = int(x), int(y_bottom - h)
    fx0, fy0 = max(0, x0), max(0, y0)
    fx1, fy1 = min(W, x0 + w), min(H, y0 + h)
    if fx1 <= fx0 or fy1 <= fy0:
        return
    frame[fy0:fy1, fx0:fx1] = sprite[fy0 - y0:fy1 - y0, fx0 - x0:fx1 - x0]


def make_street():
    bus = sample_image("bus.jpg")
    person = bus[400:904, 62:236]                     # bus.jpg 左邊那位（YOLO 框約 47,400～239,904）
    scale = 430 / person.shape[0]
    sprite = cv2.resize(person, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    bg = make_background()
    rng = np.random.default_rng(2026)
    path, vw = writer("street.mp4")
    total = 12 * FPS
    for i in range(total):
        t = i / FPS
        frame = bg.copy()
        if 2.0 <= t < 7.0:                      # 走進來：x 從 -150 走到 850
            x = -150 + (t - 2.0) / 5.0 * 1000
            bob = 6 * abs(np.sin(t * 6))
            paste(frame, sprite, x, 700 - bob)
        elif 7.0 <= t < 9.5:                    # 站在禁區裡不動
            paste(frame, sprite, 850, 700)
        elif 9.5 <= t < 11.0:                   # 往右走出去
            x = 850 + (t - 9.5) / 1.5 * 600
            paste(frame, sprite, x, 700 - 6 * abs(np.sin(t * 6)))
        vw.write(add_noise(frame, rng))
    vw.release()
    print(f"  street.mp4：12 秒，0～2 秒沒人、2～7 秒走進來、7～9.5 秒站在禁區、9.5～11 秒離開")
    return path


# ---------- 2. QR ----------
def qr_image(text, size=300):
    enc = cv2.QRCodeEncoder.create()
    m = enc.encode(text)
    m = cv2.resize(m, (size, size), interpolation=cv2.INTER_NEAREST)
    m = cv2.copyMakeBorder(m, 30, 30, 30, 30, cv2.BORDER_CONSTANT, value=255)
    return cv2.cvtColor(m, cv2.COLOR_GRAY2BGR)


def make_qr():
    os.makedirs(os.path.join(DEMO, "qr_cards"), exist_ok=True)
    codes = ["S001", "HACKER-01", "S002", "S001"]
    for c in sorted(set(codes)):
        imwrite_u(os.path.join(DEMO, "qr_cards", f"{c}.png"), qr_image(c, 400))
    desk = np.full((H, W, 3), (170, 190, 200), np.uint8)
    cv2.rectangle(desk, (0, 520), (W, H), (110, 130, 150), -1)
    rng = np.random.default_rng(7)
    path, vw = writer("qr.mp4")
    # 每張卡出現 2 秒、中間空 1 秒
    schedule = []
    t = 1.0
    for c in codes:
        schedule.append((t, t + 2.0, c))
        t += 3.0
    total = int((t + 0.5) * FPS)
    cards = {c: qr_image(c, 260) for c in set(codes)}
    for i in range(total):
        tt = i / FPS
        frame = desk.copy()
        for a, b, c in schedule:
            if a <= tt < b:
                card = cards[c]
                ch, cw = card.shape[:2]
                x = W // 2 - cw // 2 + int(8 * np.sin(tt * 3))
                y = H // 2 - ch // 2
                frame[y:y + ch, x:x + cw] = card
        vw.write(add_noise(frame, rng, 1.5))
    vw.release()
    print(f"  qr.mp4：{t + 0.5:.0f} 秒，依序出現 {' → '.join(codes)}")
    return path


# ---------- 3. 人臉 ----------
def crop_resize(img, cx, cy, cw):
    ch = int(cw * H / W)
    x0 = int(np.clip(cx - cw / 2, 0, img.shape[1] - cw))
    y0 = int(np.clip(cy - ch / 2, 0, img.shape[0] - ch))
    return cv2.resize(img[y0:y0 + ch, x0:x0 + cw], (W, H), interpolation=cv2.INTER_LINEAR)


def make_faces():
    img = sample_image("zidane.jpg")                 # 1280x720，兩張臉
    a = (917 + 136 / 2, 99 + 174 / 2)                # A：畫面右邊那位
    b = (555 + 101 / 2, 261 + 161 / 2)               # B：畫面左邊那位
    # 註冊照：A 的另一個尺度（和影片裡的不完全一樣，才像真的註冊）
    imwrite_u(os.path.join(DEMO, "register_tom.jpg"), crop_resize(img, a[0] + 10, a[1] + 50, 520))
    rng = np.random.default_rng(11)
    path, vw = writer("faces.mp4")
    for i in range(9 * FPS):
        t = i / FPS
        if t < 3:                                    # 兩張臉同框
            frame = crop_resize(img, 640, 360, int(1280 - 60 * t))
        elif t < 6:                                  # 只有 A
            frame = crop_resize(img, a[0] - 20 * (t - 3), a[1] + 40, 640)
        else:                                        # 只有 B
            frame = crop_resize(img, b[0] + 20 * (t - 6), b[1] + 30, 560)
        vw.write(add_noise(frame, rng, 1.5))
    vw.release()
    print("  faces.mp4：9 秒，0～3 秒兩人同框、3～6 秒只有 A、6～9 秒只有 B；register_tom.jpg 是 A")
    return path


def main():
    os.makedirs(DEMO, exist_ok=True)
    print("產生示範影片到", DEMO)
    make_street()
    make_qr()
    make_faces()
    print("完成。接著可以跑：python tests/run_all_tests.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
