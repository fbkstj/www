"""迷你 MQTT broker（轉送站）：在自己的筆電上跑，不用連外部的公開伺服器。

為什麼要自己跑一個？
  1. 學校網路常常擋住 1883 埠，連不到 test.mosquitto.org
  2. 公開伺服器上的訊息全世界都看得到；自己跑的只有同一個網路看得到
  3. 可以在終端機直接看到每一則訊息經過，最適合學 MQTT

支援 MQTT 3.1.1 的基本功能：連線、發佈（QoS 0／1）、訂閱（含 + 和 # 萬用字元）、保留訊息、心跳。
正式使用請改裝 Mosquitto；這支是教學用，不做帳號密碼與加密。

執行：
  python tools/mini_broker.py              監聽 0.0.0.0:1883，同網路的手機、板子也能連
  python tools/mini_broker.py --port 1884 --quiet
其他程式把 --broker 設成 127.0.0.1（同一台筆電）或終端機印出來的 IP（其他裝置）。
"""
import argparse
import asyncio
import socket
import sys
import time


def topic_matches(pattern, topic):
    """MQTT 萬用字元：+ 代表一層，# 代表這層以下全部。"""
    p, t = pattern.split("/"), topic.split("/")
    for i, part in enumerate(p):
        if part == "#":
            return True
        if i >= len(t):
            return False
        if part != "+" and part != t[i]:
            return False
    return len(p) == len(t)


def encode_length(n):
    out = bytearray()
    while True:
        byte = n % 128
        n //= 128
        out.append(byte | (0x80 if n else 0))
        if not n:
            return bytes(out)


def publish_packet(topic, payload, retain=False):
    t = topic.encode("utf-8")
    body = len(t).to_bytes(2, "big") + t + payload
    return bytes([0x30 | (1 if retain else 0)]) + encode_length(len(body)) + body


class Client:
    def __init__(self, reader, writer):
        self.reader, self.writer = reader, writer
        self.id = "?"
        self.subs = set()


class Broker:
    def __init__(self, quiet=False):
        self.clients = {}           # client id → Client
        self.retained = {}          # topic → payload
        self.quiet = quiet
        self.count = 0

    def log(self, text):
        if not self.quiet:
            print(time.strftime("%H:%M:%S"), text, flush=True)

    async def read_packet(self, reader):
        head = await reader.readexactly(1)
        mult, length = 1, 0
        while True:
            b = (await reader.readexactly(1))[0]
            length += (b & 0x7F) * mult
            if not b & 0x80:
                break
            mult *= 128
        body = await reader.readexactly(length) if length else b""
        return head[0], body

    def route(self, topic, payload, retain):
        self.count += 1
        if retain:
            if payload:
                self.retained[topic] = payload
            else:
                self.retained.pop(topic, None)
        text = payload.decode("utf-8", errors="replace")
        n = 0
        pkt = publish_packet(topic, payload)
        for c in list(self.clients.values()):
            if any(topic_matches(s, topic) for s in c.subs):
                c.writer.write(pkt)
                n += 1
        self.log(f"[訊息] {topic}  {text[:120]}  → 轉給 {n} 個訂閱者")

    async def handle(self, reader, writer):
        c = Client(reader, writer)
        peer = writer.get_extra_info("peername")
        try:
            while True:
                first, body = await self.read_packet(reader)
                kind = first >> 4
                if kind == 1:                                   # CONNECT
                    pos = 2 + int.from_bytes(body[0:2], "big")  # 協定名稱
                    pos += 1 + 1 + 2                            # 版本、旗標、心跳秒數
                    n = int.from_bytes(body[pos:pos + 2], "big")
                    c.id = body[pos + 2:pos + 2 + n].decode("utf-8", errors="replace") or f"anon-{id(c)}"
                    old = self.clients.get(c.id)
                    if old is not None:                         # 同一個 id 重複連線：踢掉舊的
                        self.log(f"[踢除] {c.id} 重複連線，舊的斷開")
                        old.writer.close()
                    self.clients[c.id] = c
                    writer.write(b"\x20\x02\x00\x00")           # CONNACK：接受
                    self.log(f"[連線] {c.id}  來自 {peer[0]}")
                elif kind == 3:                                 # PUBLISH
                    qos = (first >> 1) & 0x03
                    retain = bool(first & 0x01)
                    n = int.from_bytes(body[0:2], "big")
                    topic = body[2:2 + n].decode("utf-8", errors="replace")
                    pos = 2 + n
                    if qos:
                        pid = body[pos:pos + 2]
                        pos += 2
                        writer.write((b"\x40\x02" if qos == 1 else b"\x50\x02") + pid)   # PUBACK／PUBREC
                    self.route(topic, body[pos:], retain)
                elif kind == 6:                                 # PUBREL（QoS 2 第二步）
                    writer.write(b"\x70\x02" + body[0:2])       # PUBCOMP
                elif kind == 8:                                 # SUBSCRIBE
                    pid, pos, granted = body[0:2], 2, bytearray()
                    while pos < len(body):
                        n = int.from_bytes(body[pos:pos + 2], "big")
                        pattern = body[pos + 2:pos + 2 + n].decode("utf-8", errors="replace")
                        pos += 2 + n + 1
                        c.subs.add(pattern)
                        granted.append(0)
                        self.log(f"[訂閱] {c.id} 訂閱 {pattern}")
                    writer.write(bytes([0x90]) + encode_length(2 + len(granted)) + pid + bytes(granted))
                    for t, p in self.retained.items():          # 補送保留訊息
                        if any(topic_matches(s, t) for s in c.subs):
                            writer.write(publish_packet(t, p, retain=True))
                elif kind == 10:                                # UNSUBSCRIBE
                    pid, pos = body[0:2], 2
                    while pos < len(body):
                        n = int.from_bytes(body[pos:pos + 2], "big")
                        c.subs.discard(body[pos + 2:pos + 2 + n].decode("utf-8", errors="replace"))
                        pos += 2 + n
                    writer.write(b"\xb0\x02" + pid)
                elif kind == 12:                                # PINGREQ
                    writer.write(b"\xd0\x00")
                elif kind == 14:                                # DISCONNECT
                    break
                await writer.drain()
        except (asyncio.IncompleteReadError, ConnectionError, OSError):
            pass
        finally:
            if self.clients.get(c.id) is c:
                del self.clients[c.id]
                self.log(f"[離線] {c.id}")
            writer.close()


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


async def serve(host, port, quiet, ready=None):
    broker = Broker(quiet)
    server = await asyncio.start_server(broker.handle, host, port)
    if ready is not None:
        ready.set()
    async with server:
        await server.serve_forever()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=1883)
    ap.add_argument("--quiet", action="store_true", help="不要印出每一則訊息")
    args = ap.parse_args()
    print(f"迷你 MQTT broker 啟動：本機用 127.0.0.1:{args.port}，同網路的裝置用 {lan_ip()}:{args.port}")
    print("（Windows 第一次執行會跳防火牆詢問，要讓手機或板子連進來就選「允許」）  Ctrl+C 結束")
    try:
        asyncio.run(serve(args.host, args.port, args.quiet))
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
