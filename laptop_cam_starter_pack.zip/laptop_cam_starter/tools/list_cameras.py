"""找出這台筆電有哪些攝影機可以用（編號 0、1、2…），順便看支援的解析度與實際 FPS。

注意：這支程式會「逐一打開」每支攝影機大約 1 秒，執行前先告訴鏡頭前的人。

執行：python tools/list_cameras.py
結果裡的「編號」就是其他程式 --source 要填的數字。
（USB 攝影機通常是 1；筆電內建通常是 0；編號會因為插拔順序改變）
"""
import sys
import time

import cv2

TRY_SIZES = [(640, 480), (1280, 720), (1920, 1080)]


def probe(index):
    backend = cv2.CAP_DSHOW if sys.platform.startswith("win") else cv2.CAP_ANY
    cap = cv2.VideoCapture(index, backend)
    if not cap.isOpened():
        return None
    ok_sizes = []
    for w, h in TRY_SIZES:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
        ok, frame = cap.read()
        if ok and frame.shape[1] == w and frame.shape[0] == h:
            ok_sizes.append(f"{w}x{h}")
    t0, n = time.time(), 0
    while time.time() - t0 < 1.0:
        ok, _ = cap.read()
        n += ok
    cap.release()
    return ok_sizes, n


def main():
    print("[注意] 接下來會逐一打開攝影機約 1 秒。")
    found = 0
    for i in range(6):
        r = probe(i)
        if r is None:
            continue
        found += 1
        sizes, fps = r
        print(f"  編號 {i}：可用解析度 {', '.join(sizes) or '（讀不到畫面）'}；實測約 {fps} FPS")
    if not found:
        print("一支都沒找到。請檢查：USB 有沒有插好、其他程式（Teams、Meet、LINE）是否正在使用鏡頭、"
              "Windows 設定 → 隱私權 → 相機 是否允許桌面應用程式。")
        return 1
    print("用法範例：python d1_01_snapshot.py --source 1")
    return 0


if __name__ == "__main__":
    sys.exit(main())
