"""下載課程用到的 AI 模型（只要跑一次，放在 models/ 資料夾）

  python tools/download_models.py            全部下載
  python tools/download_models.py face       只下載人臉用的兩個
  python tools/download_models.py pose       只下載姿態模型
  python tools/download_models.py yolo       只下載 YOLO11n

模型來源都是官方公開的：
  YuNet（找臉）、SFace（認臉）：OpenCV 官方 opencv_zoo
  Pose Landmarker：Google MediaPipe
  YOLO11n：ultralytics 官方（約 5 MB）
"""
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
MODELS = os.path.join(os.path.dirname(HERE), "models")

FILES = {
    "face": [
        ("face_detection_yunet_2023mar.onnx",
         "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx"),
        ("face_recognition_sface_2021dec.onnx",
         "https://github.com/opencv/opencv_zoo/raw/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx"),
    ],
    "yolo": [
        ("yolo11n.pt",
         "https://github.com/ultralytics/assets/releases/download/v8.3.0/yolo11n.pt"),
    ],
    "pose": [
        ("pose_landmarker_lite.task",
         "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task"),
    ],
}


def fetch(name, url):
    dest = os.path.join(MODELS, name)
    if os.path.exists(dest) and os.path.getsize(dest) > 10_000:
        print(f"  已經有了：{name}（{os.path.getsize(dest) // 1024} KB）")
        return True
    print(f"  下載 {name} …")
    tmp = dest + ".part"
    try:
        urllib.request.urlretrieve(url, tmp)
        os.replace(tmp, dest)
    except Exception as e:
        if os.path.exists(tmp):
            os.remove(tmp)
        print(f"  失敗：{e}\n  請用瀏覽器開這個網址，把檔案存到 models 資料夾：\n  {url}")
        return False
    print(f"  完成：{name}（{os.path.getsize(dest) // 1024} KB）")
    return True


def main():
    os.makedirs(MODELS, exist_ok=True)
    if any(a in ("-h", "--help") for a in sys.argv[1:]):
        print(__doc__)
        return 0
    groups = sys.argv[1:] or list(FILES)
    ok = True
    for g in groups:
        if g not in FILES:
            print(f"不認得 {g}，可以用：{', '.join(FILES)}")
            return 1
        print(f"[{g}]")
        for name, url in FILES[g]:
            ok = fetch(name, url) and ok
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
