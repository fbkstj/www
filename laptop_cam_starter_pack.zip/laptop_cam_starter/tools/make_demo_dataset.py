"""產生一個「練習用」的小資料集：橘色三角錐（cone）和綠色球（ball）。

目的不是做出有用的模型，而是在上課前先把「標註格式 → 檢查 → 訓練 → 測試」整條路走一遍，
確定電腦環境沒問題；真正的專題要用自己拍、自己標的照片。

執行：python tools/make_demo_dataset.py
產生：datasets/demo_shapes/
        images/train/*.jpg  labels/train/*.txt   150 張
        images/val/*.jpg    labels/val/*.txt      40 張
        data.yaml           給 ultralytics 訓練用
        classes.txt         類別順序（0 cone、1 ball）
"""
import os
import sys

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from camlib import imwrite_u  # noqa: E402

OUT = os.path.join(ROOT, "datasets", "demo_shapes")
CLASSES = ["cone", "ball"]
SIZE = 320


def background(rng):
    """隨機的桌面／地板紋理，讓模型不能只靠背景顏色猜答案。"""
    base = rng.integers(60, 200, 3)
    img = np.full((SIZE, SIZE, 3), base, np.uint8)
    for _ in range(rng.integers(3, 8)):
        c = tuple(int(v) for v in rng.integers(40, 220, 3))
        p1 = tuple(int(v) for v in rng.integers(0, SIZE, 2))
        p2 = tuple(int(v) for v in rng.integers(0, SIZE, 2))
        cv2.line(img, p1, p2, c, int(rng.integers(1, 6)))
    noise = rng.normal(0, 6, img.shape)
    return np.clip(img + noise, 0, 255).astype(np.uint8)


def draw_object(img, rng, cls):
    s = int(rng.integers(36, 90))
    cx, cy = int(rng.integers(s // 2 + 2, SIZE - s // 2 - 2)), int(rng.integers(s // 2 + 2, SIZE - s // 2 - 2))
    if cls == 0:        # 三角錐：橘色三角形＋白色橫條
        pts = np.int32([[cx, cy - s // 2], [cx - s // 2, cy + s // 2], [cx + s // 2, cy + s // 2]])
        cv2.fillPoly(img, [pts], (0, int(rng.integers(110, 160)), 255))
        cv2.line(img, (cx - s // 5, cy), (cx + s // 5, cy), (255, 255, 255), max(2, s // 10))
        x1, y1, x2, y2 = cx - s // 2, cy - s // 2, cx + s // 2, cy + s // 2
    else:               # 球：綠色圓形＋亮點
        r = s // 2
        cv2.circle(img, (cx, cy), r, (0, int(rng.integers(150, 230)), 0), -1)
        cv2.circle(img, (cx - r // 3, cy - r // 3), max(2, r // 4), (200, 255, 200), -1)
        x1, y1, x2, y2 = cx - r, cy - r, cx + r, cy + r
    # YOLO 格式：類別 中心x 中心y 寬 高（都除以圖片大小，變成 0～1）
    return f"{cls} {(x1 + x2) / 2 / SIZE:.6f} {(y1 + y2) / 2 / SIZE:.6f} {(x2 - x1) / SIZE:.6f} {(y2 - y1) / SIZE:.6f}"


def make_split(split, n, rng):
    img_dir = os.path.join(OUT, "images", split)
    lbl_dir = os.path.join(OUT, "labels", split)
    os.makedirs(img_dir, exist_ok=True)
    os.makedirs(lbl_dir, exist_ok=True)
    for i in range(n):
        img = background(rng)
        lines = [draw_object(img, rng, int(rng.integers(0, 2))) for _ in range(int(rng.integers(1, 4)))]
        imwrite_u(os.path.join(img_dir, f"{split}_{i:03d}.jpg"), img)
        with open(os.path.join(lbl_dir, f"{split}_{i:03d}.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")


def main():
    rng = np.random.default_rng(42)
    make_split("train", 150, rng)
    make_split("val", 40, rng)
    with open(os.path.join(OUT, "classes.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(CLASSES) + "\n")
    with open(os.path.join(OUT, "data.yaml"), "w", encoding="utf-8") as f:
        f.write(f"path: {OUT.replace(os.sep, '/')}\ntrain: images/train\nval: images/val\n"
                f"names:\n  0: cone\n  1: ball\n")
    print(f"完成：{OUT}（train 150 張、val 40 張，類別 {CLASSES}）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
