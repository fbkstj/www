"""訓練前先檢查資料集（YOLO 格式），省得訓練兩小時才發現標錯。

會檢查：
  1. 每張圖片有沒有對應的 .txt 標註檔（沒有的圖片會被當成「背景」）
  2. 有沒有多出來、找不到圖片的 .txt
  3. 類別編號有沒有超出 classes 檔的範圍（最常見的錯）
  4. 座標是不是都在 0～1 之間（沒有正規化、或超出邊界）
  5. 每個類別各有幾個標註（差太多會訓練不起來）

用法：
  python dataset_check.py 資料夾
  python dataset_check.py 資料夾 --classes classes.txt

資料夾長這樣（Roboflow / LabelImg 匯出的 YOLO 格式）：
  資料夾/
    images/  001.jpg 002.jpg …
    labels/  001.txt 002.txt …
    classes.txt（或 data.yaml）
"""
import argparse
import os
import sys

IMAGE_EXT = (".jpg", ".jpeg", ".png", ".bmp")


def find_dir(root, name):
    """資料夾可能是 images/，也可能是 train/images/，兩種都找找看。"""
    direct = os.path.join(root, name)
    if os.path.isdir(direct):
        return direct
    for sub in sorted(os.listdir(root)):
        cand = os.path.join(root, sub, name)
        if os.path.isdir(cand):
            return cand
    return None


def load_classes(root, path):
    if path and os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return [ln.strip() for ln in f if ln.strip()]
    for name in ("classes.txt", "obj.names"):
        p = os.path.join(root, name)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                return [ln.strip() for ln in f if ln.strip()]
    yaml_path = os.path.join(root, "data.yaml")
    if os.path.exists(yaml_path):    # 只做最簡單的解析，不用另外裝 pyyaml
        with open(yaml_path, encoding="utf-8") as f:
            text = f.read()
        if "names:" in text:
            chunk = text.split("names:", 1)[1].strip()
            if chunk.startswith("["):
                inside = chunk[1:chunk.index("]")]
                return [c.strip().strip("'\"") for c in inside.split(",") if c.strip()]
            names = []
            for line in chunk.splitlines():
                line = line.strip()
                if line.startswith("-"):
                    names.append(line[1:].strip().strip("'\""))
                elif names:
                    break
            if names:
                return names
    return []


def find_pairs(root):
    """找出所有 (圖片資料夾, 標註資料夾) 配對，支援三種常見排法：
    images/ + labels/、images/train + labels/train（ultralytics）、train/images + train/labels（Roboflow）"""
    img_dir, lbl_dir = os.path.join(root, "images"), os.path.join(root, "labels")
    if os.path.isdir(img_dir) and os.path.isdir(lbl_dir):
        subs = [d for d in sorted(os.listdir(img_dir)) if os.path.isdir(os.path.join(img_dir, d))]
        if subs:
            return [(os.path.join(img_dir, d), os.path.join(lbl_dir, d)) for d in subs
                    if os.path.isdir(os.path.join(lbl_dir, d))]
        return [(img_dir, lbl_dir)]
    pairs = []
    for d in sorted(os.listdir(root)):
        i, l = os.path.join(root, d, "images"), os.path.join(root, d, "labels")
        if os.path.isdir(i) and os.path.isdir(l):
            pairs.append((i, l))
    return pairs


def check(root, classes_path):
    pairs = find_pairs(root)
    if not pairs:
        print(f"找不到 images 或 labels 資料夾（在 {root} 底下）")
        return 1
    classes = load_classes(root, classes_path)
    code = 0
    for img_dir, lbl_dir in pairs:
        if len(pairs) > 1:
            print(f"\n===== {os.path.basename(img_dir)} =====")
        code |= check_pair(img_dir, lbl_dir, classes)
    print("\n全部檢查通過，可以開始訓練" if code == 0 else "\n有問題要先修，修完再檢查一次")
    return code


def check_pair(img_dir, lbl_dir, classes):
    problems = []
    warnings = []
    print(f"圖片資料夾：{img_dir}")
    print(f"標註資料夾：{lbl_dir}")
    print(f"類別：{classes if classes else '（找不到 classes.txt，跳過類別範圍檢查）'}")

    images = [f for f in sorted(os.listdir(img_dir)) if f.lower().endswith(IMAGE_EXT)]
    labels = [f for f in sorted(os.listdir(lbl_dir)) if f.lower().endswith(".txt")]
    label_set = set(labels)
    stems = {os.path.splitext(f)[0] for f in images}

    per_class = {}
    boxes = 0
    empty_labels = 0

    for img in images:
        stem = os.path.splitext(img)[0]
        if stem + ".txt" not in label_set:
            warnings.append(f"{img} 沒有標註檔（會被當成沒有物件的背景圖）")

    for lbl in labels:
        stem = os.path.splitext(lbl)[0]
        if stem == "classes":
            continue
        if stem not in stems:
            problems.append(f"{lbl} 找不到對應的圖片")
        path = os.path.join(lbl_dir, lbl)
        with open(path, encoding="utf-8") as f:
            lines = [ln.strip() for ln in f if ln.strip()]
        if not lines:
            empty_labels += 1
            continue
        for n, line in enumerate(lines, 1):
            parts = line.split()
            if len(parts) < 5:
                problems.append(f"{lbl} 第 {n} 行欄位不足（應該是「類別 x y 寬 高」5 個數字）")
                continue
            try:
                cid = int(float(parts[0]))
                vals = [float(v) for v in parts[1:5]]
            except ValueError:
                problems.append(f"{lbl} 第 {n} 行不是數字：{line}")
                continue
            boxes += 1
            per_class[cid] = per_class.get(cid, 0) + 1
            if classes and not (0 <= cid < len(classes)):
                problems.append(f"{lbl} 第 {n} 行類別編號 {cid} 超出範圍（只有 {len(classes)} 類）")
            for v, name in zip(vals, ("x", "y", "寬", "高")):
                if not (0.0 <= v <= 1.0):
                    problems.append(f"{lbl} 第 {n} 行的 {name}={v} 不在 0～1（座標要正規化）")
            x, y, bw, bh = vals
            if bw <= 0 or bh <= 0:
                problems.append(f"{lbl} 第 {n} 行的框寬或高是 0")
            elif x - bw / 2 < -0.01 or x + bw / 2 > 1.01 or y - bh / 2 < -0.01 or y + bh / 2 > 1.01:
                warnings.append(f"{lbl} 第 {n} 行的框超出畫面邊界")

    print(f"\n圖片 {len(images)} 張、標註檔 {len(labels)} 個、標註框 {boxes} 個、空白標註 {empty_labels} 個")
    if per_class:
        print("各類別的標註數：")
        biggest = max(per_class.values())
        for cid in sorted(per_class):
            name = classes[cid] if classes and 0 <= cid < len(classes) else f"（編號 {cid}）"
            n = per_class[cid]
            flag = "  ← 太少，建議補到最多那一類的三分之一以上" if n * 3 < biggest else ""
            print(f"  {cid} {name}: {n}{flag}")

    if warnings:
        print(f"\n提醒 {len(warnings)} 則：")
        for w in warnings[:20]:
            print("  ·", w)
        if len(warnings) > 20:
            print(f"  …還有 {len(warnings) - 20} 則")
    if problems:
        print(f"\n要修的問題 {len(problems)} 個：")
        for p in problems[:20]:
            print("  X", p)
        if len(problems) > 20:
            print(f"  …還有 {len(problems) - 20} 個")
        return 1
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder", help="資料集資料夾")
    ap.add_argument("--classes", help="classes.txt 的路徑（不給就自己找）")
    args = ap.parse_args()
    if not os.path.isdir(args.folder):
        print("找不到資料夾：", args.folder)
        return 1
    return check(args.folder, args.classes)


if __name__ == "__main__":
    sys.exit(main())
