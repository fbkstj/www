"""本機假的 Apps Script 接收端：不用 Google 帳號，也能練習第 1 天第 4 節的上傳流程。

它收的欄位、回的 JSON 都和 apps_script/Code.gs 一樣：
  照片存到 fake_drive/資料夾名稱/檔名
  每一筆寫進 fake_sheet.csv（時間、裝置、檔名、連結、大小KB）

執行：python tools/fake_appscript.py          （預設 http://127.0.0.1:8080/）
     python tools/fake_appscript.py --port 8090
確認上傳流程沒問題後，再換成真正的 Apps Script 網址。
"""
import argparse
import base64
import csv
import json
import os
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DRIVE = os.path.join(ROOT, "fake_drive")
SHEET = os.path.join(ROOT, "fake_sheet.csv")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _reply(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        body = "假的 Apps Script 接收端運作中：請用 POST 上傳照片".encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length", 0))
            form = parse_qs(self.rfile.read(n).decode("utf-8"))
            get = lambda k, d="": form.get(k, [d])[0]
            folder = get("myFoldername", "AMB82-Mini")
            name = os.path.basename(get("myFilename", f"{int(time.time())}.jpg"))
            device = get("myDevice", "未命名裝置")
            raw = get("myFile")
            b64 = raw.split("base32,", 1)[1] if "base32," in raw else raw
            data = base64.b64decode(b64)
            if not data.startswith(b"\xff\xd8"):
                return self._reply({"ok": False, "error": "收到的不是 JPEG"})
            d = os.path.join(DRIVE, folder)
            os.makedirs(d, exist_ok=True)
            path = os.path.join(d, name)
            with open(path, "wb") as f:
                f.write(data)
            new = not os.path.exists(SHEET)
            with open(SHEET, "a", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                if new:
                    w.writerow(["時間", "裝置", "檔名", "連結", "大小(KB)"])
                w.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), device, name, path, len(data) // 1024])
            print(f"收到 {name}（{len(data) // 1024} KB，來自 {device}）")
            self._reply({"ok": True, "file": name, "url": "file:///" + path.replace("\\", "/")})
        except Exception as e:
            self._reply({"ok": False, "error": str(e)})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8080)
    args = ap.parse_args()
    print(f"假的 Apps Script 接收端：http://127.0.0.1:{args.port}/   （Ctrl+C 結束）")
    print(f"照片存到 {DRIVE}，紀錄寫到 {SHEET}")
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
        srv.handle_error = lambda request, client_address: None
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
