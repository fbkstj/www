"""MQTT 小工具：在電腦上訂閱板子送出的訊息，或送指令給板子。

板子收不到／送不出時，先用這支確認「到底是板子的問題，還是網路的問題」。

執行前：pip install paho-mqtt

用法：
  python mqtt_check.py --sub                          聽 ymhs/lab 底下所有訊息（Ctrl+C 結束）
  python mqtt_check.py --sub --topic ymhs/lab/fence/01
  python mqtt_check.py --pub green_on                 送一則指令給板子
  python mqtt_check.py --pub blink --topic ymhs/lab/cmd/01
  python mqtt_check.py --ping                         只測連不連得上伺服器

預設連 127.0.0.1（先執行 python tools/mini_broker.py）。
改用公開伺服器：--broker test.mosquitto.org（任何人都看得到內容，不要送姓名、座號、照片）。
"""
import argparse
import random
import sys
import time

DEFAULT_BROKER = "127.0.0.1"          # 預設連自己筆電上的 tools/mini_broker.py
DEFAULT_SUB_TOPIC = "ymhs/lab/#"
DEFAULT_PUB_TOPIC = "ymhs/lab/cmd/01"


def make_client(client_id):
    try:
        import paho.mqtt.client as mqtt
    except ImportError:
        print("找不到 paho-mqtt，請先執行：pip install paho-mqtt")
        return None, None
    try:    # paho-mqtt 2.x 要指定回呼版本
        return mqtt, mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=client_id)
    except AttributeError:    # paho-mqtt 1.x
        return mqtt, mqtt.Client(client_id=client_id)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--broker", default=DEFAULT_BROKER)
    ap.add_argument("--port", type=int, default=1883)
    ap.add_argument("--topic", help="預設：訂閱用 ymhs/lab/#，送出用 ymhs/lab/cmd/01")
    # 每次執行都用不同的 client id：同一個 id 同時連兩次，broker 會把先連的那個踢掉
    #（一個視窗 --sub、另一個視窗 --pub 時就會發生），所以後面加上隨機號碼
    ap.add_argument("--client-id", default=f"pc-mqtt-check-{random.randint(1000, 9999)}")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--sub", action="store_true", help="訂閱並印出收到的訊息")
    g.add_argument("--pub", help="送出這則訊息")
    g.add_argument("--ping", action="store_true", help="只測連線")
    ap.add_argument("--seconds", type=int, default=0, help="訂閱幾秒後自動結束（0＝一直聽）")
    args = ap.parse_args()

    mqtt, client = make_client(args.client_id)
    if client is None:
        return 1

    print(f"連線 {args.broker}:{args.port} …")
    try:
        client.connect(args.broker, args.port, 60)
    except Exception as e:
        print("連不上：", e)
        print("常見原因：學校網路擋掉 1883 埠、打錯伺服器名稱、電腦沒網路")
        return 1
    print("連上了")

    if args.ping:
        client.disconnect()
        return 0

    if args.pub is not None:
        topic = args.topic or DEFAULT_PUB_TOPIC
        client.loop_start()
        info = client.publish(topic, args.pub)
        info.wait_for_publish()
        print(f"已送出 [{topic}] {args.pub}")
        client.loop_stop()
        client.disconnect()
        return 0

    topic = args.topic or DEFAULT_SUB_TOPIC
    count = [0]

    def on_message(cli, userdata, msg):
        count[0] += 1
        text = msg.payload.decode("utf-8", errors="replace")
        print(f"{time.strftime('%H:%M:%S')}  [{msg.topic}] {text}")

    client.on_message = on_message
    client.subscribe(topic)
    print(f"訂閱中：{topic}（Ctrl+C 結束）")
    t0 = time.time()
    try:
        while True:
            client.loop(timeout=1.0)
            if args.seconds and (time.time() - t0) >= args.seconds:
                break
    except KeyboardInterrupt:
        pass
    client.disconnect()
    print(f"共收到 {count[0]} 則訊息")
    return 0


if __name__ == "__main__":
    sys.exit(main())
