"""MediaPipe 姿態模型的共用程式（第 2 天第 5、6 節）。

重要觀念：一定要把「沒翻過」的畫面交給 MediaPipe 判斷，LEFT 才會是那個人真正的左手；
判斷完，要顯示給自己看時才鏡像（像照鏡子），畫骨架時 x 也要跟著翻成 1 - x。
"""
import os

import cv2

from camlib import HERE

MODEL = os.path.join(HERE, "models", "pose_landmarker_lite.task")

BONES = [
    (11, 12), (11, 23), (12, 24), (23, 24),
    (11, 13), (13, 15), (12, 14), (14, 16),
    (23, 25), (25, 27), (24, 26), (26, 28),
]


class PoseDetector:
    def __init__(self):
        import mediapipe as mp
        from mediapipe.tasks import python as mp_python
        from mediapipe.tasks.python import vision
        if not os.path.exists(MODEL):
            raise SystemExit("找不到姿態模型，請先執行：python tools/download_models.py pose")
        with open(MODEL, "rb") as f:          # 用 buffer 載入：路徑有中文也不會失敗
            buf = f.read()
        self.mp = mp
        self.landmarker = vision.PoseLandmarker.create_from_options(vision.PoseLandmarkerOptions(
            base_options=mp_python.BaseOptions(model_asset_buffer=buf),
            running_mode=vision.RunningMode.VIDEO,
            num_poses=1,
            min_pose_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        ))
        self.last_ts = -1

    def detect(self, frame_bgr, t_seconds):
        """回傳 33 個關節點（沒有人就回傳 None）。時間戳記必須一直增加。"""
        ts = max(self.last_ts + 1, int(t_seconds * 1000))
        self.last_ts = ts
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        result = self.landmarker.detect_for_video(
            self.mp.Image(image_format=self.mp.ImageFormat.SRGB, data=rgb), ts)
        return result.pose_landmarks[0] if result.pose_landmarks else None


def draw_skeleton(frame, landmarks, mirror=False):
    """把骨架畫在 frame 上。mirror=True 表示 frame 已經鏡像過，x 要翻轉。"""
    if not landmarks:
        return frame
    h, w = frame.shape[:2]

    def px(p):
        x = 1.0 - p.x if mirror else p.x
        return int(x * w), int(p.y * h)

    for a, b in BONES:
        cv2.line(frame, px(landmarks[a]), px(landmarks[b]), (0, 220, 0), 3)
    for i, p in enumerate(landmarks):
        if i in (0, 11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28):
            cv2.circle(frame, px(p), 6, (0, 165, 255) if i in (15, 16) else (255, 160, 0), -1)
    return frame
