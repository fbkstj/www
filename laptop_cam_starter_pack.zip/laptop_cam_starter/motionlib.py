"""移動偵測（格子比對法），第 1 天第 4、5 節拿來當觸發條件，第 2 天第 1 節專門講它。

原理：把畫面縮小、轉灰階、稍微模糊，切成 cols × rows 個格子；
每一格和「上一張」同一格比較，變化夠大的像素超過一定比例，這格就算「在動」。
在動的格子數 >= min_blocks，才算「有東西在動」。

為什麼要縮小、模糊？
  攝影機畫面本來就有細小雜訊（每一張都會有一點點不一樣），
  縮小＋模糊可以把雜訊抹平，只留下「真的有東西移動」造成的大變化，也比較省電腦資源。
"""
import cv2
import numpy as np


class MotionGrid:
    def __init__(self, cols=16, rows=9, pixel_thresh=25, cell_ratio=0.10, min_blocks=2,
                 work_size=(320, 180)):
        self.cols = cols                    # 橫的切幾格
        self.rows = rows                    # 直的切幾格
        self.pixel_thresh = pixel_thresh    # 一個像素亮度變多少（0～255）才算有變
        self.cell_ratio = cell_ratio        # 一格裡有多少比例的像素變了，這格才算在動
        self.min_blocks = min_blocks        # 至少幾格在動，才算「有東西在動」
        self.work_size = work_size
        self.prev = None
        self.cells = []                     # 最近一次在動的格子 [(col, row), ...]

    def update(self, frame):
        """吃一張畫面，回傳在動的格子清單。"""
        small = cv2.resize(frame, self.work_size, interpolation=cv2.INTER_AREA)
        gray = cv2.GaussianBlur(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY), (5, 5), 0)
        if self.prev is None:
            self.prev = gray
            self.cells = []
            return self.cells
        changed = cv2.absdiff(gray, self.prev) > self.pixel_thresh
        self.prev = gray
        h, w = changed.shape
        cells = []
        for r in range(self.rows):
            y0, y1 = r * h // self.rows, (r + 1) * h // self.rows
            for c in range(self.cols):
                x0, x1 = c * w // self.cols, (c + 1) * w // self.cols
                if changed[y0:y1, x0:x1].mean() > self.cell_ratio:
                    cells.append((c, r))
        self.cells = cells
        return cells

    @property
    def moving(self):
        return len(self.cells) >= self.min_blocks

    def draw(self, frame, color=(255, 255, 0)):
        """把在動的格子畫在畫面上（青色框）。"""
        h, w = frame.shape[:2]
        for c, r in self.cells:
            x0, x1 = c * w // self.cols, (c + 1) * w // self.cols
            y0, y1 = r * h // self.rows, (r + 1) * h // self.rows
            cv2.rectangle(frame, (x0, y0), (x1, y1), color, 2)
        return frame


class EventGate:
    """把「一直在動」變成「一次事件」：觸發後 quiet 秒內不再觸發。"""

    def __init__(self, quiet=3.0):
        self.quiet = quiet
        self.last = -1e9
        self.count = 0

    def fire(self, active, now):
        if active and now - self.last >= self.quiet:
            self.last = now
            self.count += 1
            return True
        return False
