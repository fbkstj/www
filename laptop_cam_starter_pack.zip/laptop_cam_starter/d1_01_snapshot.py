"""第 1 天 第 1 節：打開 USB 攝影機，定時拍照存檔
（原 AMB82 版：01_camera_snapshot，拍照存 SD 卡）

做什麼：
  每隔幾秒自動拍一張，存到 snapshots/ 資料夾；按 s 可以手動多拍一張。
  畫面上方顯示解析度、實際 FPS、下一張倒數。

用法：
  python d1_01_snapshot.py                          用攝影機 0，每 5 秒一張，拍 10 張
  python d1_01_snapshot.py --source 1               外接 USB 攝影機通常是 1
  python d1_01_snapshot.py --interval 1 --count 30  每秒一張，做縮時素材
  python d1_01_snapshot.py --source demo/street.mp4 --no-window   不開鏡頭，用示範影片測
按鍵：s＝立刻拍一張　q＝結束
"""
import os
import sys

import cv2

from camlib import FrameLoop, add_source_args, ensure_dir, imwrite_u, new_parser, status_bar, HERE


def main(argv=None):
    ap = add_source_args(new_parser(__doc__))
    ap.add_argument("--interval", type=float, default=5.0, help="幾秒拍一張")
    ap.add_argument("--count", type=int, default=10, help="拍幾張就停（0＝不限）")
    ap.add_argument("--folder", default=os.path.join(HERE, "snapshots"))
    ap.add_argument("--quality", type=int, default=90, help="JPEG 品質 1～100")
    args = ap.parse_args(argv)

    folder = ensure_dir(args.folder)
    loop = FrameLoop(args, "d1_01 snapshot")
    shots = 0
    next_shot = 2.0            # 剛開啟時鏡頭還在自動調曝光，等 2 秒再拍第一張
    flash = 0
    saved = []

    for frame in loop:
        now = loop.now()
        h, w = frame.shape[:2]
        take = now >= next_shot
        view = frame.copy()
        remain = max(0.0, next_shot - now)
        status_bar(view, f"{w}x{h}  {loop.measured_fps:4.1f} FPS  shots {shots}  next {remain:3.1f}s")
        if flash > 0:                                  # 拍照時畫面邊框閃一下（代替板子上的 LED）
            cv2.rectangle(view, (0, 0), (w - 1, h - 1), (255, 255, 255), 12)
            flash -= 1
        key = loop.show(view)
        if key == ord("s"):
            take = True
        if take:
            shots += 1
            name = f"img{shots:03d}.jpg"
            path = os.path.join(folder, name)
            if imwrite_u(path, frame, args.quality):   # 存「沒畫字」的原始畫面
                kb = os.path.getsize(path) // 1024
                print(f"第 {shots} 張：{name}  大小 {kb} KB  （影片時間 {now:5.1f} 秒）")
                saved.append((name, kb))
            else:
                print("存檔失敗：", path)
            next_shot = now + args.interval
            flash = 3
            if args.count and shots >= args.count:
                loop.stop()

    print(f"共拍 {len(saved)} 張，存在 {folder}")
    return 0 if saved else 1


if __name__ == "__main__":
    sys.exit(main())
