"""所有單元共用的小工具：開攝影機或影片、畫面迴圈、中文路徑存檔、畫狀態列。

每支程式都可以用同樣的參數：
  --source 0              用第 0 支攝影機（筆電內建通常是 0，外接 USB 通常是 1）
  --source demo/street.mp4  用影片代替攝影機（沒有鏡頭、或不方便拍人時用這個）
  --source rtsp://...     讀網路串流
  --no-window             不開視窗（自動測試用）
  --max-frames 300        跑幾張就停（自動測試用）
  --out result.mp4        把畫好框的畫面另存成影片（交報告用）

為什麼要能用影片代替攝影機？
  1. 同一段影片每次跑結果都一樣，才能比較「改了門檻之後有沒有變好」
  2. 不用每次都對著同學拍，比較尊重隱私
  3. 沒有攝影機的電腦也能先把程式寫好
"""
import argparse
import os
import sys
import time

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

try:    # 把 OpenCV 自己的一般警告關掉，只留錯誤，終端機比較乾淨
    cv2.utils.logging.setLogLevel(cv2.utils.logging.LOG_LEVEL_ERROR)
except AttributeError:
    pass


# ---------- 中文路徑 ----------
def imread_u(path):
    """cv2.imread 在 Windows 讀不到中文路徑，改用 numpy 讀進來再解碼。"""
    data = np.fromfile(path, dtype=np.uint8)
    return cv2.imdecode(data, cv2.IMREAD_COLOR)


def imwrite_u(path, img, quality=90):
    """cv2.imwrite 遇到中文路徑會「安靜地失敗」（回傳 False 不報錯），改用這個。"""
    ext = os.path.splitext(path)[1].lower() or ".jpg"
    params = [cv2.IMWRITE_JPEG_QUALITY, quality] if ext in (".jpg", ".jpeg") else []
    ok, buf = cv2.imencode(ext, img, params)
    if not ok:
        return False
    buf.tofile(path)
    return True


def jpeg_bytes(img, quality=85):
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, quality])
    return buf.tobytes() if ok else b""


# ---------- 參數 ----------
def add_source_args(ap, default_source="0", mirror=True):
    ap.add_argument("--source", default=default_source,
                    help="攝影機編號（0、1…）、影片檔路徑，或 rtsp:// http:// 網址")
    ap.add_argument("--size", default="1280x720", help="攝影機解析度，例如 640x480、1280x720")
    ap.add_argument("--no-window", action="store_true", help="不開視窗（自動測試用）")
    ap.add_argument("--max-frames", type=int, default=0, help="跑幾張畫面就停，0＝不限")
    ap.add_argument("--out", help="把畫好的畫面另存成 mp4")
    ap.add_argument("--loop", action="store_true", help="影片播完從頭再播")
    if mirror:
        ap.add_argument("--no-mirror", action="store_true", help="攝影機畫面不要左右鏡像")
    else:
        ap.add_argument("--mirror", action="store_true", help="攝影機畫面左右鏡像")
    return ap


def parse_size(text):
    try:
        w, h = text.lower().split("x")
        return int(w), int(h)
    except ValueError:
        return 1280, 720


def is_camera(source):
    return str(source).isdigit()


def open_source(source, size="1280x720"):
    """打開攝影機、影片或網路串流；打不開就結束程式並說明原因。"""
    if is_camera(source):
        print(f"[注意] 即將打開攝影機 {source}，請先確認鏡頭前的人都知道。")
        # Windows 用 DirectShow 開 USB 攝影機比較快，也比較不會卡住
        backend = cv2.CAP_DSHOW if sys.platform.startswith("win") else cv2.CAP_ANY
        cap = cv2.VideoCapture(int(source), backend)
        w, h = parse_size(size)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
    else:
        path = source
        if "://" not in source and not os.path.exists(path):
            alt = os.path.join(HERE, source)    # 允許寫相對於程式包的路徑
            if os.path.exists(alt):
                path = alt
        cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        if is_camera(source):
            raise SystemExit(
                f"打不開攝影機 {source}。請試試：\n"
                "  1. 換一個編號（--source 1 或 2）；先執行 python tools/list_cameras.py 看有哪些\n"
                "  2. 關掉 Teams、Meet、LINE 等正在用鏡頭的程式\n"
                "  3. Windows 設定 → 隱私權 → 相機，允許桌面應用程式使用相機")
        raise SystemExit(f"打不開影像來源：{source}（檔案不存在？先執行 python tools/make_demo_media.py）")
    return cap


# ---------- 畫面迴圈 ----------
class FrameLoop:
    """把「讀一張 → 處理 → 顯示 → 看按鍵」包起來。

    用法：
        loop = FrameLoop(args, "d1_01 snapshot")
        for frame in loop:
            ...處理 frame、畫東西...
            key = loop.show(frame)
            if key == ord("s"): ...

    loop.now() 回傳「現在第幾秒」：
      攝影機用真實時間；影片用「影片裡的時間」（張數 ÷ FPS），
      這樣不管電腦快慢，同一段影片每次結果都一樣，方便測試。
    """

    def __init__(self, args, title, mirror_default=True):
        self.args = args
        self.title = title
        self.cap = open_source(args.source, getattr(args, "size", "1280x720"))
        self.camera = is_camera(args.source)
        if mirror_default:
            self.mirror = self.camera and not getattr(args, "no_mirror", False)
        else:
            self.mirror = self.camera and getattr(args, "mirror", False)
        self.window = not args.no_window
        self.max_frames = args.max_frames
        self.loop_video = getattr(args, "loop", False)
        src_fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.fps = src_fps if src_fps and 1 <= src_fps <= 120 else 30.0
        self.index = 0
        self.t0 = time.time()
        self.writer = None
        self.out_path = getattr(args, "out", None)
        self.key = -1
        self._stop = False
        self._fps_t = time.time()
        self._fps_n = 0
        self.measured_fps = 0.0

    def now(self):
        if self.camera or "://" in str(self.args.source):
            return time.time() - self.t0
        return self.index / self.fps

    def __iter__(self):
        while not self._stop:
            if self.max_frames and self.index >= self.max_frames:
                break
            ok, frame = self.cap.read()
            if not ok:
                if self.loop_video and not self.camera:
                    self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    ok, frame = self.cap.read()
                if not ok:
                    break
            if self.mirror:
                frame = cv2.flip(frame, 1)
            self.index += 1
            self._fps_n += 1
            if time.time() - self._fps_t >= 1.0:
                self.measured_fps = self._fps_n / (time.time() - self._fps_t)
                self._fps_t, self._fps_n = time.time(), 0
            yield frame
        self.close()

    def show(self, frame):
        """顯示並存檔；回傳按下的按鍵（沒按＝-1）。按 q 或 Esc 會結束迴圈。"""
        if self.out_path:
            if self.writer is None:
                h, w = frame.shape[:2]
                self.writer = cv2.VideoWriter(self.out_path, cv2.VideoWriter_fourcc(*"mp4v"),
                                              self.fps, (w, h))
            self.writer.write(frame)
        self.key = -1
        if self.window:
            cv2.imshow(self.title + "  (q = quit)", frame)
            self.key = cv2.waitKey(1) & 0xFF
            if self.key in (ord("q"), 27):
                self._stop = True
        return self.key

    def stop(self):
        self._stop = True

    def close(self):
        if self.cap is not None:
            self.cap.release()
            self.cap = None
        if self.writer is not None:
            self.writer.release()
            self.writer = None
        if self.window:
            cv2.destroyAllWindows()


# ---------- 畫圖 ----------
def status_bar(frame, text, color=(32, 32, 32), fg=(255, 255, 255)):
    """在畫面最上面畫一條狀態列。OpenCV 4 畫不了中文，所以畫面上一律用英文。"""
    w = frame.shape[1]
    cv2.rectangle(frame, (0, 0), (w, 34), color, -1)
    cv2.putText(frame, text, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.65, fg, 2, cv2.LINE_AA)
    return frame


def label(frame, text, xy, color=(255, 255, 255), scale=0.6):
    x, y = int(xy[0]), int(xy[1])
    (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, 2)
    y = max(y, th + 6)
    cv2.rectangle(frame, (x, y - th - 6), (x + tw + 6, y + 2), (0, 0, 0), -1)
    cv2.putText(frame, text, (x + 3, y - 3), cv2.FONT_HERSHEY_SIMPLEX, scale, color, 2, cv2.LINE_AA)


def led(frame, center, on, color, text=None):
    """畫一顆虛擬 LED（代替板子上的 LED_B、LED_G）。"""
    cv2.circle(frame, center, 16, color if on else (60, 60, 60), -1)
    cv2.circle(frame, center, 16, (220, 220, 220), 2)
    if text:
        cv2.putText(frame, text, (center[0] + 22, center[1] + 6), cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                    (255, 255, 255), 2, cv2.LINE_AA)


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)
    return path


def stamp():
    return time.strftime("%Y%m%d_%H%M%S")


def new_parser(description):
    return argparse.ArgumentParser(description=description,
                                   formatter_class=argparse.RawDescriptionHelpFormatter)
