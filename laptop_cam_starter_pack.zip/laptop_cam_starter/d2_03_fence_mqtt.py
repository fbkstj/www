"""第 2 天 第 3 節：YOLO 電子圍籬＋MQTT 通報
（原 AMB82 版：03_fence_mqtt，板子上跑 YOLOv4-tiny）

筆電版用 YOLO11n（ultralytics）找人和車，判斷「腳」有沒有踩進自己畫的禁區（多邊形）：
  有人踩進去    → 畫面變紅、存一張證據照、MQTT 送出 intrusion
  一直待在裡面  → 每隔 --repeat 秒送一次 still_inside（附停留秒數）
  全部離開      → 送出 clear（附總停留秒數）

用法：
  python tools/mini_broker.py                                  （另開一個視窗，自己的 MQTT 轉送站）
  python d2_03_fence_mqtt.py --edit-fence                      用滑鼠點出禁區，Enter 存檔
  python d2_03_fence_mqtt.py                                   攝影機 0，送到 127.0.0.1
  python d2_03_fence_mqtt.py --source demo/street.mp4          示範影片：約 6 秒時踩進禁區
  python d2_03_fence_mqtt.py --dry-run                         不送 MQTT，只印出來
  python d2_03_fence_mqtt.py --model runs/detect/train/weights/best.pt   第 4 節自己訓練的模型
看訊息：python tools/mqtt_check.py --sub
"""
import json
import os
import sys
import time

import cv2
import numpy as np

from camlib import (FrameLoop, add_source_args, ensure_dir, imwrite_u, label, led, new_parser, stamp,
                    status_bar, HERE)

FENCE_FILE = os.path.join(HERE, "fence.json")
DEFAULT_FENCE = [[0.55, 0.62], [0.98, 0.62], [0.98, 0.98], [0.55, 0.98]]
DEFAULT_WATCH = "person,bicycle,car,motorcycle"


def load_fence():
    if os.path.exists(FENCE_FILE):
        with open(FENCE_FILE, encoding="utf-8") as f:
            return json.load(f)["points"]
    return DEFAULT_FENCE


def edit_fence(args):
    """顯示第一張畫面，滑鼠左鍵點出禁區的頂點；c 清除、Enter 或 s 存檔、q 放棄。"""
    loop = FrameLoop(args, "edit fence")
    frame = next(iter(loop), None)
    loop.close()
    if frame is None:
        print("讀不到畫面")
        return 1
    h, w = frame.shape[:2]
    pts = []
    win = "edit fence: click points, c = clear, Enter = save, q = quit"

    def on_mouse(event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN:
            pts.append([round(x / w, 3), round(y / h, 3)])

    cv2.namedWindow(win)
    cv2.setMouseCallback(win, on_mouse)
    while True:
        view = frame.copy()
        if pts:
            poly = np.int32([[p[0] * w, p[1] * h] for p in pts])
            cv2.polylines(view, [poly], len(pts) > 2, (0, 255, 255), 3)
            for p in poly:
                cv2.circle(view, tuple(int(v) for v in p), 6, (0, 255, 255), -1)
        cv2.imshow(win, view)
        k = cv2.waitKey(30) & 0xFF
        if k == ord("c"):
            pts.clear()
        elif k in (13, ord("s")) and len(pts) >= 3:
            with open(FENCE_FILE, "w", encoding="utf-8") as f:
                json.dump({"points": pts}, f)
            print(f"已存檔 {FENCE_FILE}：{pts}")
            break
        elif k in (ord("q"), 27):
            print("沒有存檔")
            break
    cv2.destroyAllWindows()
    return 0


class Sender:
    def __init__(self, args):
        self.topic = args.topic
        self.client = None
        if args.dry_run:
            return
        try:
            import paho.mqtt.client as mqtt
            try:
                self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=args.client_id)
            except AttributeError:
                self.client = mqtt.Client(client_id=args.client_id)
            self.client.connect(args.broker, args.port, 60)
            self.client.loop_start()
            print(f"MQTT 已連線 {args.broker}:{args.port}，事件送到 {self.topic}")
        except Exception as e:
            print(f"[提醒] MQTT 連不上（{e}），改成只印在終端機。要先執行 python tools/mini_broker.py 嗎？")
            self.client = None

    def send(self, obj):
        text = json.dumps(obj, ensure_ascii=False)
        print("[MQTT]" if self.client else "[試跑]", self.topic, text)
        if self.client:
            self.client.publish(self.topic, text)

    def close(self):
        if self.client:
            time.sleep(0.3)
            self.client.loop_stop()
            self.client.disconnect()


def main(argv=None):
    ap = add_source_args(new_parser(__doc__))
    ap.add_argument("--edit-fence", action="store_true", help="用滑鼠畫禁區")
    ap.add_argument("--model", default=os.path.join(HERE, "models", "yolo11n.pt"))
    ap.add_argument("--watch", default=None, help=f"要看的類別，逗號隔開（預設 {DEFAULT_WATCH}；自訓模型預設全部）")
    ap.add_argument("--conf", type=float, default=0.4, help="信心門檻 0～1")
    ap.add_argument("--confirm", type=float, default=0.3, help="要連續在裡面幾秒才算闖入（擋掉閃一下的誤判）")
    ap.add_argument("--repeat", type=float, default=5.0, help="還在裡面時，每幾秒再報一次")
    ap.add_argument("--broker", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=1883)
    ap.add_argument("--topic", default="ymhs/lab/fence/01")
    ap.add_argument("--client-id", default=f"fence-{os.getpid()}")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-evidence", action="store_true", help="不要存證據照")
    args = ap.parse_args(argv)

    if args.edit_fence:
        return edit_fence(args)

    from ultralytics import YOLO
    model_path = args.model if os.path.exists(args.model) else "yolo11n.pt"   # 沒有就讓 ultralytics 自動下載
    model = YOLO(model_path)
    names = model.names
    custom = os.path.basename(model_path) not in ("yolo11n.pt",)
    watch = set((args.watch or ("" if custom else DEFAULT_WATCH)).split(",")) - {""}
    if not watch:
        watch = set(names.values())
    print(f"模型 {os.path.basename(model_path)}；要看的類別：{', '.join(sorted(watch))}")

    fence = load_fence()
    sender = Sender(args)
    folder = None if args.no_evidence else ensure_dir(os.path.join(HERE, "fence_events"))
    loop = FrameLoop(args, "d2_03 fence")
    inside_since = None          # 目前這次闖入是從第幾秒開始
    confirmed = False
    last_seen_inside = -1e9
    last_report = -1e9
    events = 0

    for frame in loop:
        now = loop.now()
        h, w = frame.shape[:2]
        poly = np.int32([[p[0] * w, p[1] * h] for p in fence])
        result = model(frame, conf=args.conf, verbose=False, imgsz=640)[0]
        view = frame.copy()
        overlay = view.copy()
        inside = []
        for box, cls, conf in zip(result.boxes.xyxy.tolist(), result.boxes.cls.tolist(), result.boxes.conf.tolist()):
            name = names[int(cls)]
            if name not in watch:
                continue
            x1, y1, x2, y2 = box
            foot = ((x1 + x2) / 2, y2)                     # 腳的位置＝框的底邊中點
            hit = cv2.pointPolygonTest(poly, foot, False) >= 0
            color = (0, 0, 255) if hit else (255, 255, 255)
            cv2.rectangle(view, (int(x1), int(y1)), (int(x2), int(y2)), color, 3)
            cv2.circle(view, (int(foot[0]), int(foot[1])), 8, color, -1)
            label(view, f"{name} {conf:.2f}", (x1, y1 - 6), color)
            if hit:
                inside.append(name)

        # ---- 狀態：進入 → 確認 → 持續 → 離開 ----
        if inside:
            last_seen_inside = now
            if inside_since is None:
                inside_since = now
            if not confirmed and now - inside_since >= args.confirm:
                confirmed, events, last_report = True, events + 1, now
                sender.send({"event": "intrusion", "count": len(inside), "objects": ",".join(inside),
                             "total": events, "video_s": round(now, 1), "time": time.strftime("%H:%M:%S")})
                if folder:
                    imwrite_u(os.path.join(folder, f"intrusion_{stamp()}_{events:03d}.jpg"), frame)
            elif confirmed and now - last_report >= args.repeat:
                last_report = now
                sender.send({"event": "still_inside", "count": len(inside),
                             "dwell_s": round(now - inside_since, 1), "video_s": round(now, 1)})
        elif inside_since is not None and now - last_seen_inside >= 1.0:   # 離開超過 1 秒才算真的走了
            if confirmed:
                sender.send({"event": "clear", "dwell_s": round(last_seen_inside - inside_since, 1),
                             "video_s": round(now, 1)})
            inside_since, confirmed = None, False

        cv2.fillPoly(overlay, [poly], (0, 0, 255) if confirmed else (0, 220, 255))
        view = cv2.addWeighted(overlay, 0.25, view, 0.75, 0)
        cv2.polylines(view, [poly], True, (0, 0, 255) if confirmed else (0, 220, 255), 3)
        status_bar(view, f"{'INTRUSION' if confirmed else 'clear'}  inside {len(inside)}  events {events}",
                   color=(0, 0, 170) if confirmed else (32, 32, 32))
        led(view, (w - 150, 60), confirmed, (0, 0, 255), "ALARM")
        loop.show(view)

    if confirmed:
        sender.send({"event": "clear", "dwell_s": round(last_seen_inside - inside_since, 1), "video_s": round(loop.now(), 1)})
    sender.close()
    print(f"結束：共 {events} 次闖入事件")
    return 0


if __name__ == "__main__":
    sys.exit(main())
