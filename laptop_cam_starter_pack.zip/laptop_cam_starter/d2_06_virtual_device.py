"""第 2 天 第 6 節（接收端）：虛擬裝置，代替原本的 AMB82 板子
（原 AMB82 版：06_mqtt_actuator）

訂閱 MQTT 指令，畫面上的「綠燈、藍燈、門」跟著變，並把狀態回報到 status 主題。
指令和板子版完全一樣（送純文字，也接受包在 JSON 裡）：
  green_on / green_off / blue_on / blue_off / blink / open / close / ping

用法：
  python tools/mini_broker.py                          （先開轉送站）
  python d2_06_virtual_device.py                       開一個「裝置」視窗
  python tools/mqtt_check.py --pub green_on            另一個視窗送指令，綠燈就亮
  python d2_06_pose_to_device.py                       用姿勢送指令
有實體 AMB82 板子的組別：板子燒 06_mqtt_actuator，broker 填筆電 IP，兩邊就能一起動。
"""
import json
import sys
import time

import cv2
import numpy as np

from camlib import led, new_parser


class Device:
    def __init__(self):
        self.green = False
        self.blue = False
        self.door_open = False
        self.blink_until = 0.0
        self.count = 0
        self.last = "-"

    def apply(self, text):
        """吃一則指令，回傳狀態字串（和板子版 say() 回報的一樣）。"""
        cmd = text.strip().lower()
        self.count += 1
        self.last = cmd[:30]
        for name in ("green_on", "green_off", "blue_on", "blue_off", "blink", "open", "close", "ping"):
            if name in cmd:          # 用「包含」比對，所以 {"cmd":"green_on"} 也認得
                break
        else:
            return "unknown_command"
        if name == "green_on":
            self.green = True
        elif name == "green_off":
            self.green = False
        elif name == "blue_on":
            self.blue = True
        elif name == "blue_off":
            self.blue = False
        elif name == "blink":
            self.blink_until = time.time() + 1.2
        elif name == "open":
            self.door_open, self.green, self.blue = True, True, False
        elif name == "close":
            self.door_open, self.green, self.blue = False, False, True
        elif name == "ping":
            return "pong"
        return name

    def render(self):
        img = np.full((300, 480, 3), (45, 35, 25), np.uint8)
        cv2.putText(img, "VIRTUAL DEVICE", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)
        blink = time.time() < self.blink_until and int(time.time() * 5) % 2 == 0
        led(img, (50, 100), self.green or blink, (0, 220, 0), "GREEN")
        led(img, (50, 160), self.blue or blink, (255, 120, 0), "BLUE")
        # 門：開＝綠色缺口，關＝紅色實心
        x0, y0 = 300, 70
        cv2.rectangle(img, (x0, y0), (x0 + 120, y0 + 170), (200, 200, 200), 3)
        if self.door_open:
            pts = np.int32([[x0, y0], [x0 + 45, y0 + 20], [x0 + 45, y0 + 190], [x0, y0 + 170]])
            cv2.fillPoly(img, [pts], (0, 160, 0))
            cv2.putText(img, "OPEN", (x0 + 50, y0 + 95), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 220, 0), 2)
        else:
            cv2.rectangle(img, (x0 + 4, y0 + 4), (x0 + 116, y0 + 166), (0, 0, 150), -1)
            cv2.putText(img, "LOCK", (x0 + 25, y0 + 95), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(img, f"cmds {self.count}  last: {self.last}", (20, 280), cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                    (200, 200, 200), 1)
        return img


def main(argv=None):
    ap = new_parser(__doc__)
    ap.add_argument("--broker", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=1883)
    ap.add_argument("--topic-cmd", default="ymhs/lab/cmd/01")
    ap.add_argument("--topic-status", default="ymhs/lab/status/01")
    ap.add_argument("--client-id", default="virtual-device-01")
    ap.add_argument("--no-window", action="store_true")
    ap.add_argument("--run-seconds", type=float, default=0, help="（測試用）幾秒後自動結束")
    args = ap.parse_args(argv)

    import paho.mqtt.client as mqtt
    dev = Device()
    try:
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=args.client_id)
    except AttributeError:
        client = mqtt.Client(client_id=args.client_id)

    def report(state):
        payload = json.dumps({"state": state, "count": dev.count, "green": dev.green, "blue": dev.blue,
                              "door": "open" if dev.door_open else "closed"})
        client.publish(args.topic_status, payload)
        print(f"[狀態] {payload}", flush=True)

    def on_connect(c, userdata, flags, rc, *extra):
        c.subscribe(args.topic_cmd)
        print(f"已連線 {args.broker}:{args.port}，訂閱 {args.topic_cmd}", flush=True)
        report("online")

    def on_message(c, userdata, msg):
        text = msg.payload.decode("utf-8", errors="replace")
        print(f"收到指令 [{msg.topic}] {text}", flush=True)
        report(dev.apply(text))

    client.on_connect = on_connect
    client.on_message = on_message
    try:
        client.connect(args.broker, args.port, 60)
    except Exception as e:
        print(f"連不上 MQTT：{e}\n先在另一個視窗執行：python tools/mini_broker.py")
        return 1
    client.loop_start()
    t0 = time.time()
    try:
        while not (args.run_seconds and time.time() - t0 > args.run_seconds):
            if args.no_window:
                time.sleep(0.1)
                continue
            cv2.imshow("virtual device (q = quit)", dev.render())
            if cv2.waitKey(50) & 0xFF in (ord("q"), 27):
                break
    except KeyboardInterrupt:
        pass
    client.loop_stop()
    client.disconnect()
    cv2.destroyAllWindows()
    return 0


if __name__ == "__main__":
    sys.exit(main())
