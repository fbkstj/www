"""第 1 天 第 6 節：用 Telegram 遠端遙控筆電攝影機
（原 AMB82 版：06_telegram_bot）

手機傳指令給你的 Bot，筆電就回應：
  /photo         拍一張傳回來
  /clip 5        錄 5 秒影片傳回來（最長 15 秒）
  /status        回報狀態（開機多久、LED、警戒模式、拍了幾張）
  /led on|off    開關虛擬 LED（筆電畫面右上角）
  /alarm on|off  警戒模式：有人經過就自動傳照片（每 30 秒最多一張）
  /help          列出指令

準備：
  1. Telegram 找 @BotFather → /newbot → 拿到 Token（等於密碼，不要外流）
  2. 設定環境變數：set TELEGRAM_TOKEN=123456:ABC...（或用 --token）
  3. 先執行一次，傳訊息給 Bot，終端機會印出你的 chat id；再用 --allow 那個數字 執行
     （沒在 --allow 名單裡的人傳指令，Bot 不會理）

用法：
  python d1_06_telegram_bot.py --allow 123456789
  python d1_06_telegram_bot.py --allow 123456789 --source demo/street.mp4 --loop
"""
import json
import os
import queue
import sys
import threading
import time
import urllib.parse
import urllib.request
import uuid

import cv2

from camlib import FrameLoop, add_source_args, jpeg_bytes, led, new_parser, status_bar, HERE
from motionlib import EventGate, MotionGrid

HELP = ("可用指令：\n/photo 拍一張\n/clip 5 錄 5 秒影片\n/status 狀態\n"
        "/led on｜off 開關 LED\n/alarm on｜off 有人經過自動傳照片\n/help 說明")


def parse_command(text):
    """'/led@MyBot on' → ('led', 'on')。不是指令就回傳 (None, '')。"""
    text = (text or "").strip()
    if not text.startswith("/"):
        return None, ""
    head, _, rest = text.partition(" ")
    cmd = head[1:].split("@")[0].lower()
    return cmd, rest.strip().lower()


class Telegram:
    def __init__(self, token, api="https://api.telegram.org"):
        self.base = f"{api.rstrip('/')}/bot{token}/"

    def call(self, method, params=None, timeout=30):
        data = urllib.parse.urlencode(params or {}).encode()
        with urllib.request.urlopen(self.base + method, data=data, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def send_file(self, method, field, chat_id, filename, content, mime, caption=""):
        """sendPhoto／sendVideo 要用 multipart/form-data 上傳檔案。"""
        boundary = uuid.uuid4().hex
        parts = []
        for k, v in (("chat_id", str(chat_id)), ("caption", caption)):
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{field}"; filename="{filename}"\r\n'
                     f"Content-Type: {mime}\r\n\r\n".encode() + content + b"\r\n")
        parts.append(f"--{boundary}--\r\n".encode())
        req = urllib.request.Request(self.base + method, data=b"".join(parts),
                                     headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read().decode("utf-8"))


def poller(tg, inbox, stop):
    """背景一直問 Telegram「有沒有新訊息」（long polling）。"""
    offset = 0
    while not stop.is_set():
        try:
            res = tg.call("getUpdates", {"offset": offset, "timeout": 20}, timeout=30)
        except Exception as e:
            print("[連線問題]", e, "（5 秒後重試）")
            time.sleep(5)
            continue
        for u in res.get("result", []):
            offset = u["update_id"] + 1
            msg = u.get("message") or {}
            if "text" in msg:
                inbox.put((msg["chat"]["id"], msg.get("from", {}).get("first_name", ""), msg["text"]))


def main(argv=None):
    ap = add_source_args(new_parser(__doc__))
    ap.add_argument("--token", default=os.environ.get("TELEGRAM_TOKEN", ""))
    ap.add_argument("--allow", default="", help="允許的 chat id，多個用逗號隔開")
    ap.add_argument("--api", default="https://api.telegram.org", help="（測試用）換成假的伺服器")
    ap.add_argument("--run-seconds", type=float, default=0, help="（測試用）跑幾秒自動結束")
    args = ap.parse_args(argv)
    if not args.token:
        print("請設定 TELEGRAM_TOKEN 環境變數，或用 --token")
        return 1
    allow = {int(x) for x in args.allow.split(",") if x.strip().lstrip("-").isdigit()}
    if not allow:
        print("提醒：還沒設定 --allow，任何指令都不會執行；先傳訊息給 Bot 看看自己的 chat id。")

    tg = Telegram(args.token, args.api)
    inbox, stop = queue.Queue(), threading.Event()
    threading.Thread(target=poller, args=(tg, inbox, stop), daemon=True).start()

    state = {"led": False, "alarm": False, "photos": 0, "t0": time.time()}
    grid, gate = MotionGrid(min_blocks=3), EventGate(30.0)
    clip = None          # 錄影中的短片：dict(chat, until, path, writer)
    loop = FrameLoop(args, "d1_06 telegram bot")
    print("Bot 執行中：用手機傳 /help 給你的 Bot")

    def reply(chat, text):
        try:
            tg.call("sendMessage", {"chat_id": chat, "text": text})
        except Exception as e:
            print("[回覆失敗]", e)

    for frame in loop:
        now = loop.now()
        if args.run_seconds and time.time() - state["t0"] > args.run_seconds:
            break
        # ---- 處理收到的指令 ----
        while not inbox.empty():
            chat, who, text = inbox.get()
            cmd, arg = parse_command(text)
            if chat not in allow:
                print(f"[拒絕] {who}（chat id {chat}）傳了「{text}」；要允許的話加 --allow {chat}")
                continue
            print(f"[指令] {who}：{text}")
            if cmd == "photo":
                state["photos"] += 1
                tg.send_file("sendPhoto", "photo", chat, "photo.jpg", jpeg_bytes(frame), "image/jpeg",
                             time.strftime("%H:%M:%S 拍攝"))
            elif cmd == "clip":
                sec = min(15, max(1, int(arg) if arg.isdigit() else 5))
                path = os.path.join(HERE, "tg_clip.mp4")
                h, w = frame.shape[:2]
                clip = {"chat": chat, "until": now + sec, "path": path,
                        "writer": cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), loop.fps, (w, h))}
                reply(chat, f"開始錄 {sec} 秒…")
            elif cmd == "status":
                reply(chat, f"執行 {int(time.time() - state['t0'])} 秒｜LED {'開' if state['led'] else '關'}｜"
                            f"警戒 {'開' if state['alarm'] else '關'}｜已拍 {state['photos']} 張")
            elif cmd == "led" and arg in ("on", "off"):
                state["led"] = arg == "on"
                reply(chat, f"LED 已{'開' if state['led'] else '關'}")
            elif cmd == "alarm" and arg in ("on", "off"):
                state["alarm"] = arg == "on"
                reply(chat, f"警戒模式已{'開啟：有人經過會傳照片' if state['alarm'] else '關閉'}")
            else:
                reply(chat, HELP)
        # ---- 錄短片 ----
        if clip:
            clip["writer"].write(frame)
            if now >= clip["until"]:
                clip["writer"].release()
                with open(clip["path"], "rb") as f:
                    tg.send_file("sendVideo", "video", clip["chat"], "clip.mp4", f.read(), "video/mp4")
                os.remove(clip["path"])          # 傳完就刪，不在筆電留下影像
                clip = None
        # ---- 警戒模式 ----
        if state["alarm"]:
            grid.update(frame)
            if gate.fire(grid.moving, now):
                for chat in allow:
                    tg.send_file("sendPhoto", "photo", chat, "alarm.jpg", jpeg_bytes(frame), "image/jpeg",
                                 "有人經過！" + time.strftime("%H:%M:%S"))
                print("[警戒] 偵測到移動，已傳照片")
        view = frame.copy()
        status_bar(view, f"bot running  alarm {'ON' if state['alarm'] else 'off'}  photos {state['photos']}")
        led(view, (view.shape[1] - 100, 60), state["led"], (0, 220, 0), "LED")
        loop.show(view)
        if not loop.camera:
            time.sleep(1.0 / loop.fps)

    stop.set()
    return 0


if __name__ == "__main__":
    sys.exit(main())
