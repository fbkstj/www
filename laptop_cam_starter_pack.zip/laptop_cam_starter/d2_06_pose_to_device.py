"""第 2 天 第 6 節（送出端）：用姿勢遙控裝置
（原 AMB82 版：pc_pose/pose_to_mqtt.py）

攝影機 → MediaPipe 33 點 → pose_rules 判斷 → PoseTrigger 穩定化 → MQTT 指令 → 虛擬裝置（或 AMB82 板子）
  舉左手 green_on｜舉右手 green_off｜雙手舉高 blink｜平舉 open｜蹲下 close｜倒下 blink

建議測試順序：
  python d2_06_pose_to_device.py --selftest       不開鏡頭：用假的關節點跑一遍，應送出 green_on、blink、close
  python d2_06_pose_to_device.py --dry-run        開鏡頭但不送出，確認動作判得對
  python d2_06_pose_to_device.py                  正式送到 127.0.0.1 的 mini_broker
"""
import sys
import time

import cv2

from camlib import FrameLoop, add_source_args, new_parser, status_bar
from pose_rules import DEFAULT_COMMANDS, POSE_NAMES, PoseTrigger, classify_pose, pose_to_command


class Sender:
    def __init__(self, args, dry):
        self.topic, self.client = args.topic, None
        if dry:
            print(f"[試跑] 不會真的送出（主題 {args.topic}）")
            return
        import paho.mqtt.client as mqtt
        try:
            self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=args.client_id)
        except AttributeError:
            self.client = mqtt.Client(client_id=args.client_id)
        self.client.connect(args.broker, args.port, 60)
        self.client.loop_start()
        print(f"已連線 {args.broker}:{args.port}，指令送到 {args.topic}")

    def send(self, command):
        if self.client is None:
            print(f"[試跑] 本來要送：{command}")
        else:
            self.client.publish(self.topic, command)
            print(f"→ 已送出：{command}")

    def close(self):
        if self.client is not None:
            time.sleep(0.3)
            self.client.loop_stop()
            self.client.disconnect()


def fake_person(shoulder_y=0.30, hip_y=0.55, ankle_y=0.95, lw=None, rw=None):
    """和 tests/test_pose_rules.py 的假人一樣，給 --selftest 用。"""
    pts = [(0.5, shoulder_y - 0.1, 1.0)] * 33
    pts = list(pts)
    pts[11], pts[12] = (0.58, shoulder_y, 1.0), (0.42, shoulder_y, 1.0)
    pts[15] = (lw or (0.60, hip_y)) + (1.0,)
    pts[16] = (rw or (0.40, hip_y)) + (1.0,)
    pts[23], pts[24] = (0.55, hip_y, 1.0), (0.45, hip_y, 1.0)
    pts[27], pts[28] = (0.55, ankle_y, 1.0), (0.45, ankle_y, 1.0)
    return pts


def selftest(sender, trig):
    script = [("站著", fake_person()), ("舉左手", fake_person(lw=(0.60, 0.10))), ("放下", fake_person()),
              ("雙手舉高", fake_person(lw=(0.60, 0.08), rw=(0.40, 0.08))), ("放下", fake_person()),
              ("蹲下", fake_person(0.40, 0.70, 0.90))]
    sent = []
    for label, lm in script:
        for _ in range(8):
            event = trig.update(classify_pose(lm))
            if event and pose_to_command(event):
                print(f"  {label} → {event} → {pose_to_command(event)}")
                sender.send(pose_to_command(event))
                sent.append(pose_to_command(event))
    ok = sent == ["green_on", "blink", "close"]
    print("自我測試通過" if ok else f"自我測試失敗，送出的是 {sent}")
    return 0 if ok else 1


def main(argv=None):
    ap = add_source_args(new_parser(__doc__))
    ap.add_argument("--broker", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=1883)
    ap.add_argument("--topic", default="ymhs/lab/cmd/01", help="要和裝置訂閱的主題一樣")
    ap.add_argument("--client-id", default="pose-sender-01")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--selftest-send", action="store_true", help="自我測試時真的送出（測 broker 與裝置用）")
    ap.add_argument("--hold", type=int, default=6)
    ap.add_argument("--cooldown", type=int, default=20)
    args = ap.parse_args(argv)

    print("動作 → 指令：" + "、".join(f"{POSE_NAMES[p]}→{c}" for p, c in DEFAULT_COMMANDS.items()))
    trig = PoseTrigger(hold=args.hold, cooldown=args.cooldown)
    sender = Sender(args, dry=args.dry_run or (args.selftest and not args.selftest_send))
    try:
        if args.selftest:
            return selftest(sender, trig)
        from poselib import PoseDetector, draw_skeleton
        det = PoseDetector()
        args.mirror = False
        loop = FrameLoop(args, "d2_06 pose to device", mirror_default=False)
        show_mirror = loop.camera and not getattr(args, "no_mirror", False)
        last = ""
        for frame in loop:
            lm = det.detect(frame, loop.now())          # 用沒翻過的畫面判斷
            pose = classify_pose(lm) if lm else "no_person"
            event = trig.update(pose)
            if event and pose_to_command(event):
                last = pose_to_command(event)
                sender.send(last)
            view = cv2.flip(frame, 1) if show_mirror else frame.copy()
            draw_skeleton(view, lm, mirror=show_mirror)
            status_bar(view, f"{pose}   last sent: {last}")
            loop.show(view)
        return 0
    finally:
        sender.close()


if __name__ == "__main__":
    sys.exit(main())
