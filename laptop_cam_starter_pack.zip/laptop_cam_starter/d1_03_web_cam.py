"""第 1 天 第 3 節：手機用瀏覽器看筆電攝影機＋遙控虛擬 LED
（原 AMB82 版：03_ap_web_snapshot，板子開 AP、手機連上看畫面）

筆電版的「AP 模式」：Windows 設定 → 網路和網際網路 → 行動熱點 → 開啟，
手機連上這個熱點，再用瀏覽器打開程式印出來的網址。

網頁功能：
  即時畫面（MJPEG，瀏覽器直接看，不用裝 App）
  LED 開／關（筆電畫面和網頁上的虛擬 LED 會一起變）
  拍一張（下載目前畫面）
  狀態（FPS、觀看人數、開機多久）

用法：
  python d1_03_web_cam.py                                 用攝影機 0，網址看終端機
  python d1_03_web_cam.py --source demo/street.mp4 --loop 用示範影片
  python d1_03_web_cam.py --key 5678                      網址要加 ?key=5678 才看得到（用 ngrok 對外時一定要設）
對外公開（課堂示範用，結束一定要關）：另開視窗執行 ngrok http 8000
"""
import json
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import cv2

from camlib import FrameLoop, add_source_args, jpeg_bytes, led, new_parser, status_bar

PAGE = """<!DOCTYPE html>
<html lang="zh-Hant-TW"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>筆電攝影機</title>
<style>
 body{font-family:"Noto Sans TC","Microsoft JhengHei",sans-serif;margin:0;background:#0f172a;color:#e2e8f0;text-align:center}
 img{width:100%;max-width:960px;display:block;margin:0 auto;background:#000}
 .bar{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;padding:12px}
 button,a.btn{font-size:1.05rem;padding:10px 18px;border-radius:10px;border:0;cursor:pointer;text-decoration:none}
 .on{background:#22c55e;color:#052e16}.off{background:#475569;color:#fff}.shot{background:#fde047;color:#0f172a}
 #st{font-size:.95rem;color:#94a3b8;padding:0 12px 16px}
</style></head><body>
<img src="/stream.mjpg__KEYQ__" alt="即時畫面">
<div class="bar">
 <button class="on" onclick="setLed('on')">LED 開</button>
 <button class="off" onclick="setLed('off')">LED 關</button>
 <a class="btn shot" href="/snapshot.jpg__KEYQ__" download="snapshot.jpg">拍一張</a>
</div>
<div id="st">讀取狀態中…</div>
<script>
 const KEY = "__KEY__";
 const q = p => p + (KEY ? (p.includes('?') ? '&' : '?') + 'key=' + encodeURIComponent(KEY) : '');
 function setLed(s){ fetch(q('/led?state=' + s)).then(r => r.json()).then(show); }
 function show(d){ document.getElementById('st').textContent =
   'LED：' + (d.led ? '開' : '關') + '　FPS：' + d.fps + '　觀看中：' + d.viewers + ' 人　已執行 ' + d.uptime_s + ' 秒'; }
 setInterval(() => fetch(q('/status')).then(r => r.json()).then(show).catch(() => {}), 2000);
</script></body></html>"""


class State:
    def __init__(self):
        self.lock = threading.Lock()
        self.jpeg = b""
        self.led = False
        self.viewers = 0
        self.fps = 0.0
        self.t0 = time.time()
        self.key = ""
        self.frame_id = 0


STATE = State()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):          # 不要每個請求都印一行
        pass

    def _allowed(self, query):
        if not STATE.key:
            return True
        return parse_qs(query).get("key", [""])[0] == STATE.key

    def _json(self, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _status(self):
        return {"led": STATE.led, "fps": round(STATE.fps, 1), "viewers": STATE.viewers,
                "uptime_s": int(time.time() - STATE.t0)}

    def do_GET(self):
        url = urlparse(self.path)
        if not self._allowed(url.query):
            self.send_response(403)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write("需要正確的 key".encode("utf-8"))
            return
        if url.path == "/":
            keyq = f"?key={STATE.key}" if STATE.key else ""
            body = PAGE.replace("__KEYQ__", keyq).replace("__KEY__", STATE.key).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif url.path == "/snapshot.jpg":
            with STATE.lock:
                data = STATE.jpeg
            self.send_response(200)
            self.send_header("Content-Type", "image/jpeg")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        elif url.path == "/led":
            state = parse_qs(url.query).get("state", [""])[0]
            if state in ("on", "off"):
                STATE.led = (state == "on")
                print(f"[網頁] LED {'開' if STATE.led else '關'}（來自 {self.client_address[0]}）")
            self._json(self._status())
        elif url.path == "/status":
            self._json(self._status())
        elif url.path == "/stream.mjpg":
            self._stream()
        else:
            self.send_error(404)

    def _stream(self):
        """MJPEG：一直送 JPEG，每張用 --frame 隔開，瀏覽器會自動換成最新那張。"""
        self.send_response(200)
        self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        STATE.viewers += 1
        last = -1
        try:
            while True:
                with STATE.lock:
                    data, fid = STATE.jpeg, STATE.frame_id
                if fid == last or not data:
                    time.sleep(0.01)
                    continue
                last = fid
                self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\n")
                self.wfile.write(f"Content-Length: {len(data)}\r\n\r\n".encode())
                self.wfile.write(data + b"\r\n")
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        finally:
            STATE.viewers -= 1


def main(argv=None):
    ap = add_source_args(new_parser(__doc__))
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--key", default="", help="設定後網址要加 ?key=這個值")
    ap.add_argument("--quality", type=int, default=70, help="JPEG 品質，調低比較順")
    ap.add_argument("--width", type=int, default=960, help="送到手機的畫面寬度")
    args = ap.parse_args(argv)
    STATE.key = args.key

    server = ThreadingHTTPServer(("0.0.0.0", args.port), Handler)
    server.handle_error = lambda request, client_address: None   # 手機關掉網頁時不要印一大串錯誤
    threading.Thread(target=server.serve_forever, daemon=True).start()
    from d1_02_stream import lan_ip
    ip = lan_ip()
    keyq = f"?key={args.key}" if args.key else ""
    print(f"手機（同一個網路或筆電熱點）打開：http://{ip}:{args.port}/{keyq}")
    print(f"筆電自己打開：http://127.0.0.1:{args.port}/{keyq}")
    if not args.key:
        print("提醒：沒有設 --key，同一個網路的人都看得到。要用 ngrok 對外時一定要加 --key。")

    loop = FrameLoop(args, "d1_03 web cam")
    for frame in loop:
        view = frame
        if view.shape[1] > args.width:
            scale = args.width / view.shape[1]
            view = cv2.resize(view, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        status_bar(view, time.strftime("%H:%M:%S") + f"  viewers {STATE.viewers}")
        led(view, (view.shape[1] - 110, 60), STATE.led, (0, 220, 0), "LED")
        data = jpeg_bytes(view, args.quality)
        with STATE.lock:
            STATE.jpeg = data
            STATE.frame_id += 1
            STATE.fps = loop.measured_fps
        loop.show(view)
        if not loop.camera and "://" not in args.source:
            time.sleep(1.0 / loop.fps)        # 影片檔照原本速度播，不要一下子就播完
    server.shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
