"""第 1 天 第 5 節：錄影存 MP4＋小螢幕狀態顯示
（原 AMB82 版：05_record_mp4_tft，按鈕錄影存 SD 卡、TFT 顯示狀態）

兩種錄法：
  按 r 開始／停止（手動）
  --on-motion 有人經過自動錄：會把「觸發前 --pre 秒」也一起存進去（像行車記錄器），
              沒動靜 --post 秒後自動停止

另外開一個 320×240 的「TFT」小視窗，模擬板子接的小螢幕：顯示錄影中、秒數、已錄幾段。
錄下來的畫面右下角會壓上日期時間（像監視器）。

用法：
  python d1_05_record.py                                 按 r 錄影
  python d1_05_record.py --on-motion --pre 2 --post 3
  python d1_05_record.py --source demo/street.mp4 --on-motion --no-window
  python d1_05_record.py --h264                          錄完用 ffmpeg 轉成 H.264（手機、LINE、網頁都能直接播）
"""
import collections
import os
import shutil
import subprocess
import sys
import time

import cv2
import numpy as np

from camlib import FrameLoop, add_source_args, ensure_dir, new_parser, stamp, status_bar, HERE
from motionlib import MotionGrid


def tft_panel(recording, seconds, clips, motion):
    """畫一張 320×240 的狀態畫面（代替 TFT 小螢幕）。"""
    p = np.full((240, 320, 3), (40, 30, 20), np.uint8)
    cv2.putText(p, time.strftime("%H:%M:%S"), (70, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (255, 255, 255), 2)
    if recording:
        cv2.circle(p, (60, 115), 18, (0, 0, 255), -1)
        cv2.putText(p, f"REC {seconds:5.1f}s", (95, 128), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
    else:
        cv2.putText(p, "STANDBY", (80, 128), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (180, 180, 180), 2)
    cv2.putText(p, f"clips: {clips}", (20, 185), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (200, 255, 200), 2)
    cv2.putText(p, "motion" if motion else "quiet", (190, 185), cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                (0, 200, 255) if motion else (140, 140, 140), 2)
    return p


def burn_time(frame, text):
    h, w = frame.shape[:2]
    cv2.putText(frame, text, (w - 330, h - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 4)
    cv2.putText(frame, text, (w - 330, h - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)


def to_h264(path):
    if not shutil.which("ffmpeg"):
        print("  （沒有 ffmpeg，略過轉檔）")
        return path
    out = path[:-4] + "_h264.mp4"
    r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", path, "-c:v", "libx264", "-pix_fmt", "yuv420p",
                        "-movflags", "+faststart", out], capture_output=True)
    if r.returncode == 0:
        os.remove(path)
        return out
    return path


def main(argv=None):
    ap = add_source_args(new_parser(__doc__))
    ap.add_argument("--on-motion", action="store_true", help="有人經過自動錄")
    ap.add_argument("--pre", type=float, default=2.0, help="觸發前要保留幾秒")
    ap.add_argument("--post", type=float, default=3.0, help="沒動靜幾秒後停止")
    ap.add_argument("--max-len", type=float, default=60.0, help="一段最長幾秒")
    ap.add_argument("--folder", default=os.path.join(HERE, "recordings"))
    ap.add_argument("--h264", action="store_true", help="錄完轉成 H.264")
    args = ap.parse_args(argv)

    folder = ensure_dir(args.folder)
    loop = FrameLoop(args, "d1_05 record")
    grid = MotionGrid(min_blocks=3)
    buf = collections.deque(maxlen=max(1, int(args.pre * loop.fps)))   # 觸發前的畫面先暫存在這裡
    writer = None
    path = None
    rec_start = 0.0
    pre_used = 0.0
    last_motion = -1e9
    clips = []

    def start(now):
        nonlocal writer, path, rec_start, pre_used
        h, w = frame.shape[:2]
        path = os.path.join(folder, f"rec_{stamp()}_{len(clips) + 1:02d}.mp4")
        writer = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), loop.fps, (w, h))
        rec_start = now
        pre_used = len(buf) / loop.fps
        for old in buf:                     # 先把觸發前的畫面寫進去
            writer.write(old)
        print(f"[錄影] 開始 {os.path.basename(path)}（含觸發前 {len(buf) / loop.fps:.1f} 秒）")

    def stop(now):
        nonlocal writer
        writer.release()
        writer = None
        final = to_h264(path) if args.h264 else path
        mb = os.path.getsize(final) / 1024 / 1024
        clips.append(final)
        print(f"[錄影] 停止 {os.path.basename(final)}  長度約 {now - rec_start + pre_used:.1f} 秒  {mb:.2f} MB")

    for frame in loop:
        now = loop.now()
        rec_frame = frame.copy()
        burn_time(rec_frame, time.strftime("%Y-%m-%d %H:%M:%S"))
        moving = False
        if args.on_motion:
            grid.update(frame)
            moving = grid.moving
            if moving:
                last_motion = now
        if writer is None:
            buf.append(rec_frame)
            if args.on_motion and moving:
                start(now)
        else:
            writer.write(rec_frame)
            too_long = now - rec_start >= args.max_len
            quiet = args.on_motion and now - last_motion >= args.post
            if too_long or quiet:
                stop(now)
                buf.clear()

        view = rec_frame.copy()
        status_bar(view, ("REC  " if writer else "STANDBY  ") + f"clips {len(clips)}   r = start/stop",
                   color=(0, 0, 160) if writer else (32, 32, 32))
        key = loop.show(view)
        if loop.window:
            cv2.imshow("TFT 320x240", tft_panel(writer is not None, now - rec_start, len(clips), moving))
        if key == ord("r"):
            if writer is None:
                start(now)
            else:
                stop(now)

    if writer is not None:
        stop(loop.now())
    print(f"共錄 {len(clips)} 段，存在 {folder}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
