"""第 2 天 第 1 節（上半）：移動偵測
（原 AMB82 版：01a_motion_detect）

畫面切成 16 × 9 格，和上一張比較，有格子在動就畫青色框；在動的格子夠多，就算一次「有人經過」，
虛擬 LED 亮起、終端機印出紀錄，也可以順便存一張證據照（--save）。

用法：
  python d2_01a_motion.py                                  攝影機 0
  python d2_01a_motion.py --source demo/street.mp4         示範影片（2～11 秒有人走動）
  python d2_01a_motion.py --min-blocks 5 --quiet 5         比較不敏感、比較不會洗版
  python d2_01a_motion.py --save                           每次事件存一張照片到 motion_events/
按鍵：+／- 調整 min-blocks（即時看效果）　q 結束
"""
import os
import sys

from camlib import FrameLoop, add_source_args, ensure_dir, imwrite_u, led, new_parser, stamp, status_bar, HERE
from motionlib import EventGate, MotionGrid


def main(argv=None):
    ap = add_source_args(new_parser(__doc__))
    ap.add_argument("--min-blocks", type=int, default=2, help="至少幾格在動才算數（容易誤報就調大）")
    ap.add_argument("--quiet", type=float, default=3.0, help="事件之後幾秒內不重複回報")
    ap.add_argument("--pixel-thresh", type=int, default=25, help="像素亮度差多少才算有變（光線閃爍就調大）")
    ap.add_argument("--save", action="store_true", help="每次事件存一張照片")
    args = ap.parse_args(argv)

    grid = MotionGrid(min_blocks=args.min_blocks, pixel_thresh=args.pixel_thresh)
    gate = EventGate(args.quiet)
    folder = ensure_dir(os.path.join(HERE, "motion_events")) if args.save else None
    loop = FrameLoop(args, "d2_01a motion")
    moving_frames = 0

    for frame in loop:
        now = loop.now()
        grid.update(frame)
        if grid.moving:
            moving_frames += 1
        if gate.fire(grid.moving, now):
            print(f"[移動] 第 {gate.count} 次  時間 {now:5.1f} 秒  在動的格子：{len(grid.cells)}")
            if folder:
                imwrite_u(os.path.join(folder, f"motion_{stamp()}_{gate.count:03d}.jpg"), frame)
        view = grid.draw(frame.copy())
        status_bar(view, f"blocks {len(grid.cells):3d} / need {grid.min_blocks}   events {gate.count}")
        led(view, (view.shape[1] - 120, 60), grid.moving, (255, 120, 0), "MOTION")
        key = loop.show(view)
        if key in (ord("+"), ord("=")):
            grid.min_blocks += 1
            print("min-blocks =", grid.min_blocks)
        elif key == ord("-") and grid.min_blocks > 1:
            grid.min_blocks -= 1
            print("min-blocks =", grid.min_blocks)

    print(f"結束：共 {gate.count} 次事件，{moving_frames} 張畫面偵測到移動")
    return 0


if __name__ == "__main__":
    sys.exit(main())
