"""第 2 天 第 5 節：姿態辨識（舉左手、舉右手、雙手舉高、平舉、蹲下、倒下）
（原 AMB82 版：pc_pose/pose_basics.py，本來就在電腦上跑）

MediaPipe 找出 33 個關節點 → pose_rules.py 用「比大小」判斷動作 → PoseTrigger 穩定化成事件。
畫面左上角顯示「這一張」的判斷，終端機印出「維持夠久」才成立的事件。

用法：
  python d2_05_pose.py                                攝影機 0（會自動鏡像顯示，像照鏡子）
  python d2_05_pose.py --image 照片.jpg               用一張照片測，輸出 pose_result.jpg
  python d2_05_pose.py --source demo/street.mp4       示範影片（站著走路，應該都是 none）
  python d2_05_pose.py --log                          把每一張的判斷寫進 pose_log.csv（做報告、算準確率用）
先下載模型：python tools/download_models.py pose
"""
import csv
import os
import sys

import cv2

from camlib import FrameLoop, add_source_args, imread_u, imwrite_u, new_parser, status_bar, HERE
from pose_rules import POSE_NAMES, PoseTrigger, classify_pose
from poselib import PoseDetector, draw_skeleton


def run_image(path):
    img = imread_u(path)
    if img is None:
        print("讀不到圖片：", path)
        return 1
    det = PoseDetector()
    lm = det.detect(img, 0)
    pose = classify_pose(lm) if lm else "no_person"
    print(f"判斷結果：{pose}（{POSE_NAMES.get(pose, pose)}）")
    if lm:
        for name, i in (("左肩", 11), ("右肩", 12), ("左腕", 15), ("右腕", 16)):
            print(f"  {name}: x={lm[i].x:.3f} y={lm[i].y:.3f} 信心={lm[i].visibility:.2f}")
    out = os.path.join(HERE, "pose_result.jpg")
    imwrite_u(out, status_bar(draw_skeleton(img.copy(), lm), pose))
    print("結果圖：", out)
    return 0


def main(argv=None):
    ap = add_source_args(new_parser(__doc__))
    ap.add_argument("--image", help="用一張照片測")
    ap.add_argument("--hold", type=int, default=6, help="動作要維持幾張畫面才算數")
    ap.add_argument("--log", action="store_true", help="每一張的判斷寫進 pose_log.csv")
    args = ap.parse_args(argv)
    if args.image:
        return run_image(args.image)

    det = PoseDetector()
    trig = PoseTrigger(hold=args.hold)
    # 不在 FrameLoop 裡鏡像：要先用原始畫面判斷，顯示時才翻
    args.mirror = False
    loop = FrameLoop(args, "d2_05 pose", mirror_default=False)
    show_mirror = loop.camera and not getattr(args, "no_mirror", False)
    counts = {}
    logf = open(os.path.join(HERE, "pose_log.csv"), "w", newline="", encoding="utf-8-sig") if args.log else None
    log = csv.writer(logf) if logf else None
    if log:
        log.writerow(["秒數", "判斷", "左腕y", "右腕y", "左肩y", "右肩y"])

    for frame in loop:
        now = loop.now()
        lm = det.detect(frame, now)
        pose = classify_pose(lm) if lm else "no_person"
        counts[pose] = counts.get(pose, 0) + 1
        event = trig.update(pose)
        if event:
            print(f"[動作] {POSE_NAMES.get(event, event)}（{event}）  時間 {now:5.1f} 秒")
        if log:
            row = [f"{now:.2f}", pose] + ([f"{lm[i].y:.3f}" for i in (15, 16, 11, 12)] if lm else ["", "", "", ""])
            log.writerow(row)
        view = cv2.flip(frame, 1) if show_mirror else frame.copy()
        draw_skeleton(view, lm, mirror=show_mirror)
        status_bar(view, f"{pose}   {loop.measured_fps:4.1f} FPS")
        loop.show(view)

    if logf:
        logf.close()
    total = sum(counts.values()) or 1
    print("各判斷佔的比例：" + "、".join(f"{POSE_NAMES.get(k, k)} {v * 100 / total:.0f}%"
                                   for k, v in sorted(counts.items(), key=lambda kv: -kv[1])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
