"""第 1 天 第 4 節：拍照自動上傳 Google 雲端硬碟、寫進試算表、推播 LINE
（原 AMB82 版：04_cloud_upload；Apps Script 接收端完全沿用，放在 apps_script/Code.gs）

什麼時候上傳（可以同時開）：
  按 u              手動上傳一張
  --every 60        每 60 秒上傳一張
  --on-motion       偵測到有人經過就上傳（用第 2 天第 1 節的移動偵測）

用法：
  python d1_04_cloud_upload.py --url https://script.google.com/macros/s/xxxx/exec --on-motion
  python d1_04_cloud_upload.py --dry-run --on-motion --source demo/street.mp4   不上傳，只存到 outbox/ 看看內容
  本機假接收端練習（不用 Google 帳號）：
    視窗 1：python tools/fake_appscript.py
    視窗 2：python d1_04_cloud_upload.py --url http://127.0.0.1:8080/ --on-motion --source demo/street.mp4

網址也可以放在環境變數 APPS_SCRIPT_URL，就不用每次打；網址等於「知道的人都能上傳」，不要貼到報告或 GitHub。
"""
import base64
import json
import os
import queue
import sys
import threading
import time
import urllib.parse
import urllib.request

from camlib import FrameLoop, add_source_args, ensure_dir, jpeg_bytes, led, new_parser, stamp, status_bar, HERE
from motionlib import EventGate, MotionGrid


def build_payload(jpeg, filename, device, folder):
    """和 AMB82 版送的欄位一模一樣，所以 Code.gs 不用改。"""
    return urllib.parse.urlencode({
        "myFoldername": folder,
        "myFilename": filename,
        "myDevice": device,
        "myFile": "data:image/jpeg;base32," + base64.b64encode(jpeg).decode(),
    }).encode()


def post(url, payload, timeout=60):
    """送出；Apps Script 會回 302 轉址，urllib 會自動跟過去拿結果。"""
    req = urllib.request.Request(url, data=payload,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        text = r.read().decode("utf-8", errors="replace")
    try:
        return json.loads(text)
    except ValueError:
        return {"ok": False, "error": "回應不是 JSON（部署權限是不是沒選『任何人』？）", "raw": text[:200]}


class Uploader(threading.Thread):
    """在背景上傳，畫面才不會每上傳一次就卡住幾秒。"""

    def __init__(self, args):
        super().__init__(daemon=True)
        self.args = args
        self.q = queue.Queue()
        self.done = 0
        self.failed = 0
        self.busy = False
        self.last = ""

    def run(self):
        while True:
            jpeg, name = self.q.get()
            if jpeg is None:
                break
            self.busy = True
            payload = build_payload(jpeg, name, self.args.device, self.args.folder)
            t0 = time.time()
            if self.args.dry_run:
                out = ensure_dir(os.path.join(HERE, "outbox"))
                with open(os.path.join(out, name), "wb") as f:
                    f.write(jpeg)
                result = {"ok": True, "file": name, "url": "（試跑，沒有上傳）"}
            else:
                try:
                    result = post(self.args.url, payload)
                except Exception as e:
                    result = {"ok": False, "error": str(e)}
            sec = time.time() - t0
            if result.get("ok"):
                self.done += 1
                self.last = f"OK {name}"
                print(f"[上傳] {name}  {len(jpeg) // 1024} KB  花 {sec:.1f} 秒  → {result.get('url', '')}")
            else:
                self.failed += 1
                self.last = f"FAIL {name}"
                print(f"[失敗] {name}：{result.get('error')}  {result.get('raw', '')}")
            self.busy = False
            self.q.task_done()


def main(argv=None):
    ap = add_source_args(new_parser(__doc__))
    ap.add_argument("--url", default=os.environ.get("APPS_SCRIPT_URL", ""), help="Apps Script 網頁應用程式網址")
    ap.add_argument("--dry-run", action="store_true", help="不上傳，照片存到 outbox/")
    ap.add_argument("--every", type=float, default=0, help="每幾秒上傳一張（0＝不定時）")
    ap.add_argument("--on-motion", action="store_true", help="偵測到移動就上傳")
    ap.add_argument("--quiet", type=float, default=10.0, help="移動觸發後幾秒內不再上傳")
    ap.add_argument("--max-uploads", type=int, default=20, help="最多上傳幾張（避免塞爆雲端硬碟）")
    ap.add_argument("--device", default="laptop-cam-01", help="寫進試算表的裝置名稱")
    ap.add_argument("--folder", default="筆電攝影機", help="雲端硬碟資料夾名稱")
    args = ap.parse_args(argv)
    if not args.url and not args.dry_run:
        print("請用 --url 指定 Apps Script 網址，或加 --dry-run 先試跑")
        return 1

    up = Uploader(args)
    up.start()
    grid = MotionGrid(min_blocks=3)
    gate = EventGate(args.quiet)
    next_timed = args.every if args.every else None
    queued = 0
    loop = FrameLoop(args, "d1_04 cloud upload")

    for frame in loop:
        now = loop.now()
        reason = None
        if args.on_motion:
            grid.update(frame)
            if gate.fire(grid.moving, now):
                reason = "motion"
        if next_timed is not None and now >= next_timed:
            reason = reason or "timer"
            next_timed = now + args.every
        view = frame.copy()
        status_bar(view, f"uploaded {up.done}  failed {up.failed}  {up.last}")
        led(view, (view.shape[1] - 120, 60), up.busy, (0, 200, 255), "UPLOAD")
        if loop.show(view) == ord("u"):
            reason = "key"
        if reason and queued < args.max_uploads:
            queued += 1
            name = f"{stamp()}_{reason}_{queued:03d}.jpg"
            up.q.put((jpeg_bytes(frame, 85), name))

    up.q.put((None, None))
    up.join(timeout=120)
    print(f"結束：成功 {up.done} 張，失敗 {up.failed} 張")
    return 0 if up.failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
