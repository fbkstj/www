"""第 2 天 第 2 節：人臉辨識門禁
（原 AMB82 版：02_face_door，板子上是 SCRFD＋MobileFaceNet）

筆電版用 OpenCV 內建的兩個模型接力（和板子上的做法一樣）：
  YuNet  找臉：畫面裡有幾張臉、在哪裡、眼睛鼻子嘴巴在哪
  SFace  認臉：把每張臉變成 128 個數字（特徵值），和註冊過的人比「餘弦相似度」
相似度 >= 0.363（OpenCV 官方建議值）就算同一個人。

註冊（只存 128 個數字，不存照片；存在 faces/face_db.npz）：
  python d2_02_face_door.py --register Tom --image demo/register_tom.jpg   用照片註冊
  執行中按 r，再到終端機輸入名字                                           用攝影機現場註冊（畫面裡只能有一張臉）
管理：
  python d2_02_face_door.py --list            看有誰
  python d2_02_face_door.py --delete Tom      刪一個人
  python d2_02_face_door.py --reset           全部清掉（下課前請執行）
執行：
  python d2_02_face_door.py
  python d2_02_face_door.py --source demo/faces.mp4    0～3 秒兩人同框、3～6 秒只有 A、6～9 秒只有 B
先下載模型：python tools/download_models.py face
"""
import csv
import os
import sys
import time

import cv2
import numpy as np

from camlib import FrameLoop, add_source_args, ensure_dir, imread_u, label, led, new_parser, status_bar, HERE

MODELS = os.path.join(HERE, "models")
DET_MODEL = os.path.join(MODELS, "face_detection_yunet_2023mar.onnx")
REC_MODEL = os.path.join(MODELS, "face_recognition_sface_2021dec.onnx")
DB_PATH = os.path.join(HERE, "faces", "face_db.npz")
COSINE_THRESHOLD = 0.363


def load_models():
    for p in (DET_MODEL, REC_MODEL):
        if not os.path.exists(p):
            raise SystemExit(f"找不到模型 {os.path.basename(p)}，請先執行：python tools/download_models.py face")
    try:
        det = cv2.FaceDetectorYN.create(DET_MODEL, "", (320, 320), 0.8, 0.3, 50)
        rec = cv2.FaceRecognizerSF.create(REC_MODEL, "")
    except cv2.error:
        # 舊版 OpenCV 遇到中文路徑會讀不到模型，改成先讀進記憶體再載入
        empty = np.array([], np.uint8)
        det = cv2.FaceDetectorYN.create("onnx", np.fromfile(DET_MODEL, np.uint8), empty, (320, 320), 0.8, 0.3, 50)
        rec = cv2.FaceRecognizerSF.create("onnx", np.fromfile(REC_MODEL, np.uint8), empty)
    return det, rec


def detect(det, frame, work_width=640):
    """在縮小的畫面上找臉（比較快），再把座標放大回原圖。回傳 N×15 的陣列。"""
    h, w = frame.shape[:2]
    scale = min(1.0, work_width / w)
    small = cv2.resize(frame, None, fx=scale, fy=scale) if scale < 1 else frame
    det.setInputSize((small.shape[1], small.shape[0]))
    _, faces = det.detect(small)
    if faces is None:
        return np.zeros((0, 15), np.float32)
    faces = faces.copy()
    faces[:, :14] /= scale
    return faces


def feature(rec, frame, face):
    aligned = rec.alignCrop(frame, face)          # 依眼睛位置把臉轉正、切成 112×112
    return rec.feature(aligned)


def load_db():
    if not os.path.exists(DB_PATH):
        return [], np.zeros((0, 128), np.float32)
    d = np.load(DB_PATH, allow_pickle=False)
    return list(d["names"]), d["feats"]


def save_db(names, feats):
    ensure_dir(os.path.dirname(DB_PATH))
    np.savez(DB_PATH, names=np.array(names), feats=np.asarray(feats, np.float32).reshape(-1, 128))


def register(rec, det, frame, name):
    faces = detect(det, frame)
    if len(faces) != 1:
        print(f"註冊失敗：畫面裡有 {len(faces)} 張臉，必須剛好 1 張")
        return False
    names, feats = load_db()
    feats = np.vstack([feats, feature(rec, frame, faces[0])]) if len(feats) else feature(rec, frame, faces[0])
    names.append(name)
    save_db(names, feats)
    print(f"已註冊 {name}（名單共 {len(names)} 筆特徵，同一個人可以註冊多次，不同角度會更準）")
    return True


def identify(rec, feat, names, feats):
    """回傳 (名字或 'unknown', 最高相似度)。"""
    best_name, best = "unknown", -1.0
    for n, f in zip(names, feats):
        s = rec.match(feat, f.reshape(1, -1), cv2.FaceRecognizerSF_FR_COSINE)
        if s > best:
            best_name, best = n, s
    return (best_name if best >= COSINE_THRESHOLD else "unknown"), best


def main(argv=None):
    global DB_PATH
    ap = add_source_args(new_parser(__doc__))
    ap.add_argument("--register", metavar="NAME", help="註冊這個名字")
    ap.add_argument("--image", help="搭配 --register：用這張照片註冊")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--delete", metavar="NAME")
    ap.add_argument("--reset", action="store_true")
    ap.add_argument("--open-seconds", type=float, default=5.0, help="開門幾秒後自動關")
    ap.add_argument("--allow-multi", action="store_true", help="允許多張臉同框也開門（預設不允許，防尾隨）")
    ap.add_argument("--log", default=os.path.join(HERE, "door_log.csv"))
    ap.add_argument("--db", default=DB_PATH, help="註冊資料檔（預設 faces/face_db.npz）")
    args = ap.parse_args(argv)
    DB_PATH = args.db

    if args.reset:
        if os.path.exists(DB_PATH):
            os.remove(DB_PATH)
        print("已清除全部註冊資料")
        return 0
    names, feats = load_db()
    if args.list:
        print("已註冊：", "、".join(sorted(set(names))) or "（沒有人）")
        return 0
    if args.delete:
        keep = [i for i, n in enumerate(names) if n != args.delete]
        save_db([names[i] for i in keep], feats[keep] if len(keep) else np.zeros((0, 128), np.float32))
        print(f"已刪除 {args.delete}（刪掉 {len(names) - len(keep)} 筆）")
        return 0

    det, rec = load_models()
    if args.register and args.image:
        img = imread_u(args.image)
        if img is None:
            print("讀不到照片：", args.image)
            return 1
        return 0 if register(rec, det, img, args.register) else 1

    print("已註冊：", "、".join(sorted(set(names))) or "（還沒有人，按 r 註冊）")
    loop = FrameLoop(args, "d2_02 face door")
    door_until = -1.0
    opened = 0
    last_state = None
    new_log = not os.path.exists(args.log)
    logf = open(args.log, "a", newline="", encoding="utf-8-sig")
    log = csv.writer(logf)
    if new_log:
        log.writerow(["時間", "影片秒數", "事件", "名字", "相似度"])

    for frame in loop:
        now = loop.now()
        faces = detect(det, frame)
        view = frame.copy()
        results = []
        for f in faces:
            name, score = identify(rec, feature(rec, frame, f), names, feats) if len(names) else ("unknown", 0.0)
            results.append((name, score))
            x, y, w, h = f[:4].astype(int)
            color = (0, 200, 0) if name != "unknown" else (0, 0, 255)
            cv2.rectangle(view, (x, y), (x + w, y + h), color, 3)
            label(view, f"{name} {score:.2f}", (x, y - 6), color)

        known = [r for r in results if r[0] != "unknown"]
        if len(faces) > 1 and not args.allow_multi:
            state = "multi"                    # 防尾隨：同框兩個人以上不開
        elif known:
            state = "open"
        elif len(faces):
            state = "unknown"
        else:
            state = "empty"
        if state == "open":
            if now >= door_until:
                opened += 1
                log.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), f"{now:.1f}", "開門", known[0][0], f"{known[0][1]:.3f}"])
                print(f"[開門] {known[0][0]}（相似度 {known[0][1]:.2f}，影片時間 {now:.1f} 秒）")
            door_until = now + args.open_seconds
        if state != last_state and state in ("multi", "unknown"):
            why = "多人同框，不開門" if state == "multi" else "陌生人，不開門"
            log.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), f"{now:.1f}", why, "", ""])
            print(f"[拒絕] {why}（影片時間 {now:.1f} 秒）")
        last_state = state
        is_open = now < door_until
        status_bar(view, f"door {'OPEN' if is_open else 'LOCKED'}  faces {len(faces)}  opened {opened}   r = register",
                   color=(0, 110, 0) if is_open else (32, 32, 32))
        led(view, (view.shape[1] - 230, 60), is_open, (0, 220, 0), "OPEN")
        led(view, (view.shape[1] - 110, 60), state in ("multi", "unknown"), (255, 120, 0), "DENY")
        if loop.show(view) == ord("r"):
            name = input("要註冊的名字（英文，Enter 確認）：").strip()
            if name and register(rec, det, frame, name):
                names, feats = load_db()
        logf.flush()

    logf.close()
    print(f"結束：開門 {opened} 次，紀錄在 {args.log}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
