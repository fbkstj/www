"""一鍵驗收：不開攝影機，用示範影片把 12 個單元都跑一遍，看環境和程式是不是都正常。

執行：
  python tools/make_demo_media.py          （第一次先產生示範影片）
  python tools/download_models.py          （第一次先下載模型）
  python tests/run_all_tests.py            全部測（約 3～5 分鐘，電腦慢會久一點）
  python tests/run_all_tests.py --quick    跳過比較慢的 YOLO 與姿態影片
  python tests/run_all_tests.py --with-train   連訓練也測（多 5～15 分鐘）
  python tests/run_all_tests.py d2_01b d2_02    只測指定的單元

每一項會印 [OK]、[FAIL] 或 [SKIP]（缺套件或缺模型時跳過，並告訴你缺什麼）。
測試產生的檔案都放在暫存資料夾，不會動到你自己的照片、註冊資料或紀錄。
"""
import asyncio
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request

TESTS = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(TESTS)
sys.path.insert(0, ROOT)
sys.path.insert(0, TESTS)
sys.path.insert(0, os.path.join(ROOT, "tools"))
PY = sys.executable
ENV = dict(os.environ, PYTHONIOENCODING="utf-8")
TMP = tempfile.mkdtemp(prefix="labcam_test_")
RESULTS = []


def has(module):
    return importlib.util.find_spec(module) is not None


def model(name):
    return os.path.exists(os.path.join(ROOT, "models", name))


def demo(name):
    return os.path.join(ROOT, "demo", name)


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def run(args, timeout=600):
    r = subprocess.run([PY] + args, cwd=ROOT, env=ENV, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=timeout)
    return r.returncode, r.stdout + r.stderr


def record(unit, title, status, detail):
    RESULTS.append((unit, title, status, detail))
    print(f"[{status}] {unit} {title}：{detail}", flush=True)


# ---------------- 第 1 天 ----------------
def t_d1_01():
    folder = os.path.join(TMP, "snap")
    code, out = run(["d1_01_snapshot.py", "--source", demo("street.mp4"), "--no-window",
                     "--interval", "2", "--count", "3", "--folder", folder])
    n = len([f for f in os.listdir(folder) if f.endswith(".jpg")]) if os.path.isdir(folder) else 0
    return ("OK" if code == 0 and n == 3 else "FAIL"), f"拍到 {n} 張（預期 3 張）"


def t_d1_02():
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        return "SKIP", "沒有安裝 ffmpeg（winget install Gyan.FFmpeg）"
    port = free_port()
    p = subprocess.Popen([PY, "d1_02_stream.py", "--mode", "tcp", "--file", demo("street.mp4"), "--port", str(port)],
                         cwd=ROOT, env=ENV, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        time.sleep(3)
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_name,width,height", "-of", "csv=p=0",
                            f"tcp://127.0.0.1:{port}"], capture_output=True, text=True, timeout=30)
        info = r.stdout.strip().splitlines()[0] if r.stdout.strip() else ""
    finally:
        p.kill()
        subprocess.run(["taskkill", "/F", "/IM", "ffmpeg.exe"], capture_output=True) if os.name == "nt" else None
    return ("OK" if info.startswith("h264") else "FAIL"), f"TCP 串流讀到：{info or '沒有畫面'}"


def t_d1_03():
    port = free_port()
    p = subprocess.Popen([PY, "d1_03_web_cam.py", "--source", demo("street.mp4"), "--loop", "--no-window",
                          "--port", str(port), "--key", "t123"], cwd=ROOT, env=ENV,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    base = f"http://127.0.0.1:{port}"
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen(f"{base}/status?key=t123", timeout=1)
                break
            except Exception:
                time.sleep(0.5)
        try:
            urllib.request.urlopen(f"{base}/status", timeout=3)
            blocked = False
        except urllib.error.HTTPError as e:
            blocked = e.code == 403
        led = json.loads(urllib.request.urlopen(f"{base}/led?state=on&key=t123", timeout=3).read())["led"]
        jpg = urllib.request.urlopen(f"{base}/snapshot.jpg?key=t123", timeout=3).read()
        s = urllib.request.urlopen(f"{base}/stream.mjpg?key=t123", timeout=5)
        chunk = b""
        t0 = time.time()
        while time.time() - t0 < 2:
            chunk += s.read(4096)
        frames = chunk.count(b"--frame")
    finally:
        p.kill()
    ok = blocked and led and jpg[:2] == b"\xff\xd8" and frames >= 5
    return ("OK" if ok else "FAIL"), f"沒 key 擋下={blocked}、LED 開={led}、快照 {len(jpg) // 1024} KB、2 秒串流 {frames} 張"


def t_d1_04():
    import fake_appscript
    from http.server import ThreadingHTTPServer
    fake_appscript.DRIVE = os.path.join(TMP, "fake_drive")
    fake_appscript.SHEET = os.path.join(TMP, "fake_sheet.csv")
    srv = ThreadingHTTPServer(("127.0.0.1", 0), fake_appscript.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        code, out = run(["d1_04_cloud_upload.py", "--url", f"http://127.0.0.1:{srv.server_address[1]}/",
                         "--on-motion", "--quiet", "3", "--source", demo("street.mp4"), "--no-window"])
    finally:
        srv.shutdown()
    rows = 0
    if os.path.exists(fake_appscript.SHEET):
        with open(fake_appscript.SHEET, encoding="utf-8-sig") as f:
            rows = len(f.read().strip().splitlines()) - 1
    return ("OK" if code == 0 and rows == 3 else "FAIL"), f"假雲端收到 {rows} 張、試算表 {rows} 列（預期 3）"


def t_d1_05():
    folder = os.path.join(TMP, "rec")
    code, out = run(["d1_05_record.py", "--source", demo("street.mp4"), "--on-motion", "--no-window", "--folder", folder])
    clips = [f for f in os.listdir(folder) if f.endswith(".mp4")] if os.path.isdir(folder) else []
    size = sum(os.path.getsize(os.path.join(folder, f)) for f in clips) // 1024
    return ("OK" if code == 0 and len(clips) == 1 and size > 100 else "FAIL"), f"錄到 {len(clips)} 段、共 {size} KB（預期 1 段）"


def t_d1_06():
    from fake_telegram import FakeTelegram
    ft = FakeTelegram([(111, "/photo"), (111, "/led on"), (111, "/status"), (999, "/photo"), (111, "/clip 2")])
    try:
        code, out = run(["d1_06_telegram_bot.py", "--token", "TEST", "--allow", "111", "--api", ft.url,
                         "--source", demo("street.mp4"), "--no-window", "--run-seconds", "8"], timeout=120)
    finally:
        ft.close()
    kinds = [s[0] for s in ft.sent]
    to_stranger = [s for s in ft.sent if s[1] == 999]
    ok = "sendPhoto" in kinds and "sendVideo" in kinds and kinds.count("sendMessage") >= 3 and not to_stranger
    return ("OK" if ok else "FAIL"), f"回了 {len(ft.sent)} 則（照片 {kinds.count('sendPhoto')}、影片 {kinds.count('sendVideo')}、文字 {kinds.count('sendMessage')}），陌生人 0 則={not to_stranger}"


# ---------------- 第 2 天 ----------------
def t_d2_01a():
    code, out = run(["d2_01a_motion.py", "--source", demo("street.mp4"), "--no-window"])
    n = out.count("[移動]")
    code2, out2 = run(["d2_01a_motion.py", "--source", demo("street.mp4"), "--no-window", "--max-frames", "55"])
    quiet = out2.count("[移動]")
    return ("OK" if n == 3 and quiet == 0 else "FAIL"), f"整段 {n} 次事件（預期 3）、前 1.8 秒沒人時 {quiet} 次（預期 0）"


def t_d2_01b():
    code, out = run(["d2_01b_qr_gate.py", "--source", demo("qr.mp4"), "--no-window", "--allow", "S001,S002",
                     "--log", os.path.join(TMP, "qr_log.csv")])
    p, d = out.count("[通過]"), out.count("[拒絕]")
    return ("OK" if (p, d) == (3, 1) else "FAIL"), f"通過 {p}、拒絕 {d}（預期 3、1）"


def t_d2_02():
    if not (model("face_detection_yunet_2023mar.onnx") and model("face_recognition_sface_2021dec.onnx")):
        return "SKIP", "缺人臉模型（python tools/download_models.py face）"
    db = os.path.join(TMP, "face_db.npz")
    run(["d2_02_face_door.py", "--db", db, "--register", "Tom", "--image", demo("register_tom.jpg")])
    code, out = run(["d2_02_face_door.py", "--db", db, "--source", demo("faces.mp4"), "--no-window",
                     "--log", os.path.join(TMP, "door.csv")])
    opened, multi, stranger = out.count("[開門] Tom"), out.count("多人同框"), out.count("陌生人")
    ok = opened == 1 and multi >= 1 and stranger >= 1
    return ("OK" if ok else "FAIL"), f"Tom 開門 {opened} 次、擋下多人同框 {multi} 次、擋下陌生人 {stranger} 次"


class Broker:
    """在背景執行 tools/mini_broker.py。"""

    def __init__(self):
        import mini_broker
        self.port = free_port()
        self.ready = threading.Event()
        self.loop = asyncio.new_event_loop()

        def go():
            asyncio.set_event_loop(self.loop)
            try:
                self.loop.run_until_complete(mini_broker.serve("127.0.0.1", self.port, True, self.ready))
            except Exception:
                pass
        threading.Thread(target=go, daemon=True).start()
        self.ready.wait(5)


def subscribe(port, topic):
    import paho.mqtt.client as mqtt
    got = []
    try:
        c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"test-sub-{port}")
    except AttributeError:
        c = mqtt.Client(client_id=f"test-sub-{port}")
    c.on_message = lambda cl, u, m: got.append(m.payload.decode("utf-8", "replace"))
    c.connect("127.0.0.1", port, 30)
    c.subscribe(topic)
    c.loop_start()
    time.sleep(0.5)
    return c, got


def t_d2_03():
    if not has("ultralytics"):
        return "SKIP", "沒有安裝 ultralytics（pip install ultralytics）"
    if not has("paho"):
        return "SKIP", "沒有安裝 paho-mqtt"
    b = Broker()
    c, got = subscribe(b.port, "ymhs/lab/fence/#")
    code, out = run(["d2_03_fence_mqtt.py", "--source", demo("street.mp4"), "--no-window", "--port", str(b.port),
                     "--no-evidence"], timeout=900)
    time.sleep(1)
    c.loop_stop()
    events = [json.loads(g)["event"] for g in got]
    ok = events.count("intrusion") == 1 and events[-1:] == ["clear"]
    first = next((json.loads(g) for g in got if '"intrusion"' in g), {})
    return ("OK" if ok else "FAIL"), f"MQTT 收到 {events}；闖入時間 {first.get('video_s')} 秒（預期約 6 秒）"


def t_d2_04(with_train):
    code, out = run(["tools/make_demo_dataset.py"])
    code2, out2 = run(["tools/dataset_check.py", os.path.join(ROOT, "datasets", "demo_shapes")])
    if code2 != 0:
        return "FAIL", "練習資料集檢查沒通過"
    if not with_train:
        return "OK", "資料集產生並檢查通過（訓練要加 --with-train 才測）"
    if not has("ultralytics"):
        return "SKIP", "沒有安裝 ultralytics"
    code3, out3 = run(["d2_04_train_custom.py", "--data", "datasets/demo_shapes", "--epochs", "15",
                       "--name", "selftest"], timeout=3600)
    line = next((ln for ln in out3.splitlines() if "mAP50 =" in ln), "")
    try:
        m = float(line.split("mAP50 =")[1].split()[0])
    except (IndexError, ValueError):
        m = 0.0
    return ("OK" if code3 == 0 and m >= 0.5 else "FAIL"), f"訓練完成，{line.strip() or '沒有成績'}（預期 mAP50 >= 0.5）"


def t_d2_05(quick):
    code, out = run(["tests/test_pose_rules.py"])
    if "失敗 0 項" not in out:
        return "FAIL", "姿勢規則測試沒全過：" + out.strip().splitlines()[0]
    if not has("mediapipe") or not model("pose_landmarker_lite.task"):
        return "OK", "規則 24 項全過（沒有 mediapipe 或姿態模型，影片部分跳過）"
    if quick:
        return "OK", "規則 24 項全過（--quick 跳過影片）"
    code2, out2 = run(["d2_05_pose.py", "--source", demo("street.mp4"), "--no-window"])
    line = next((ln for ln in out2.splitlines() if "各判斷佔的比例" in ln), "")
    ok = code2 == 0 and "沒有動作" in line
    return ("OK" if ok else "FAIL"), "規則 24 項全過；示範影片 " + line.replace("各判斷佔的比例：", "")


def t_d2_06():
    if not has("paho"):
        return "SKIP", "沒有安裝 paho-mqtt"
    b = Broker()
    c, status = subscribe(b.port, "ymhs/lab/status/#")
    dev = subprocess.Popen([PY, "d2_06_virtual_device.py", "--port", str(b.port), "--no-window", "--run-seconds", "15"],
                           cwd=ROOT, env=ENV, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(40):
        if any('"online"' in s for s in status):
            break
        time.sleep(0.25)
    code, out = run(["d2_06_pose_to_device.py", "--selftest", "--selftest-send", "--port", str(b.port)])
    time.sleep(1.5)
    dev.kill()
    c.loop_stop()
    states = [json.loads(s)["state"] for s in status]
    ok = "自我測試通過" in out and states[-3:] == ["green_on", "blink", "close"]
    return ("OK" if ok else "FAIL"), f"裝置回報：{states}"


UNITS = [
    ("d1_01", "定時拍照", lambda a: t_d1_01()),
    ("d1_02", "影像串流", lambda a: t_d1_02()),
    ("d1_03", "手機網頁", lambda a: t_d1_03()),
    ("d1_04", "雲端上傳", lambda a: t_d1_04()),
    ("d1_05", "錄影", lambda a: t_d1_05()),
    ("d1_06", "Telegram", lambda a: t_d1_06()),
    ("d2_01a", "移動偵測", lambda a: t_d2_01a()),
    ("d2_01b", "QR 門禁", lambda a: t_d2_01b()),
    ("d2_02", "人臉門禁", lambda a: t_d2_02()),
    ("d2_03", "電子圍籬＋MQTT", lambda a: ("SKIP", "--quick 跳過") if a.quick else t_d2_03()),
    ("d2_04", "自訓模型", lambda a: t_d2_04(a.with_train)),
    ("d2_05", "姿態辨識", lambda a: t_d2_05(a.quick)),
    ("d2_06", "姿勢遙控裝置", lambda a: t_d2_06()),
]


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("only", nargs="*", help="只測這些單元，例如 d1_01 d2_02")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--with-train", action="store_true")
    args = ap.parse_args()
    if not os.path.exists(demo("street.mp4")):
        print("找不到示範影片，請先執行：python tools/make_demo_media.py")
        return 1
    print(f"Python {sys.version.split()[0]}；暫存資料夾 {TMP}\n")
    t0 = time.time()
    for unit, title, fn in UNITS:
        if args.only and unit not in args.only:
            continue
        start = time.time()
        try:
            status, detail = fn(args)
        except Exception as e:
            status, detail = "FAIL", f"{type(e).__name__}: {e}"
        record(unit, title, status, f"{detail}　（{time.time() - start:.0f} 秒）")
    shutil.rmtree(TMP, ignore_errors=True)
    ok = sum(1 for r in RESULTS if r[2] == "OK")
    fail = sum(1 for r in RESULTS if r[2] == "FAIL")
    skip = sum(1 for r in RESULTS if r[2] == "SKIP")
    print(f"\n總結：OK {ok}、FAIL {fail}、SKIP {skip}（共 {time.time() - t0:.0f} 秒）")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
