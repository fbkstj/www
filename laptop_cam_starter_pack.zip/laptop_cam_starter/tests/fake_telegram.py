"""測試用的假 Telegram 伺服器：不用真的 Bot，也能測第 1 天第 6 節的程式。

它會把預先排好的「使用者訊息」交給 Bot，並記錄 Bot 回了什麼（文字、照片、影片）。
平常上課用不到，是 tests/run_all_tests.py 在用。
"""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs


class FakeTelegram:
    def __init__(self, messages, port=0):
        """messages：[(chat_id, 文字), ...]，Bot 第一次 getUpdates 時一次給出去。"""
        self.pending = [
            {"update_id": i + 1, "message": {"chat": {"id": c}, "from": {"first_name": "tester"}, "text": t}}
            for i, (c, t) in enumerate(messages)]
        self.sent = []          # (method, chat_id, 內容摘要)
        self.lock = threading.Lock()
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_POST(self):
                method = self.path.rsplit("/", 1)[-1]
                body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
                result = True
                if method == "getUpdates":
                    offset = int(parse_qs(body.decode()).get("offset", ["0"])[0])
                    with fake.lock:
                        result = [u for u in fake.pending if u["update_id"] >= offset]
                    if not result:
                        time.sleep(0.5)
                elif method == "sendMessage":
                    q = parse_qs(body.decode())
                    with fake.lock:
                        fake.sent.append((method, int(q["chat_id"][0]), q.get("text", [""])[0]))
                else:           # sendPhoto / sendVideo：multipart
                    kind = "mp4" if b"ftyp" in body else ("jpeg" if b"\xff\xd8" in body else "?")
                    chat = body.split(b'name="chat_id"\r\n\r\n', 1)[1].split(b"\r\n", 1)[0].decode()
                    with fake.lock:
                        fake.sent.append((method, int(chat), f"{kind} {len(body) // 1024}KB"))
                data = json.dumps({"ok": True, "result": result}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

        self.server = ThreadingHTTPServer(("127.0.0.1", port), H)
        self.server.handle_error = lambda request, client_address: None   # 對方中途斷線不要印一大串錯誤
        self.port = self.server.server_address[1]
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}"

    def close(self):
        self.server.shutdown()
