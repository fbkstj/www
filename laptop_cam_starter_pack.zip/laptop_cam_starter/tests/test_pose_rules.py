"""pose_rules.py 的自我測試（不用鏡頭、不用網路、不用裝 mediapipe）

執行：python test_pose_rules.py
全部通過會印出「全部通過」，有錯會印出哪一項錯、期待什麼、實際得到什麼。
先讓這支跑過，再去接鏡頭，可以省下很多「到底是規則錯還是鏡頭錯」的時間。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pose_rules import (
    L_ANKLE, L_ELBOW, L_HIP, L_KNEE, L_SHOULDER, L_WRIST,
    R_ANKLE, R_ELBOW, R_HIP, R_KNEE, R_SHOULDER, R_WRIST,
    DEFAULT_COMMANDS, PoseTrigger, classify_pose, pose_to_command,
)

passed = 0
failed = []


def check(name, got, want):
    global passed
    if got == want:
        passed += 1
    else:
        failed.append(f"{name}：期待 {want}，實際 {got}")


def make_person(shoulder_y=0.30, hip_y=0.55, ankle_y=0.95,
                lw=None, rw=None, vis=1.0, lean_x=0.0):
    """做出一個假人的 33 個關節點，方便測試。

    lw / rw 是左右手腕的 (x, y)；預設垂在身體兩側。
    lean_x 讓臀部往旁邊移，用來模擬躺著的姿勢。
    """
    pts = [(0.5, shoulder_y - 0.1, vis) for _ in range(33)]
    pts[L_SHOULDER] = (0.58, shoulder_y, vis)
    pts[R_SHOULDER] = (0.42, shoulder_y, vis)
    pts[L_ELBOW] = (0.60, (shoulder_y + hip_y) / 2, vis)
    pts[R_ELBOW] = (0.40, (shoulder_y + hip_y) / 2, vis)
    pts[L_WRIST] = (lw if lw else (0.60, hip_y)) + (vis,)
    pts[R_WRIST] = (rw if rw else (0.40, hip_y)) + (vis,)
    pts[L_HIP] = (0.55 + lean_x, hip_y, vis)
    pts[R_HIP] = (0.45 + lean_x, hip_y, vis)
    pts[L_KNEE] = (0.55 + lean_x, (hip_y + ankle_y) / 2, vis)
    pts[R_KNEE] = (0.45 + lean_x, (hip_y + ankle_y) / 2, vis)
    pts[L_ANKLE] = (0.55 + lean_x, ankle_y, vis)
    pts[R_ANKLE] = (0.45 + lean_x, ankle_y, vis)
    return pts


def run_tests():
    global passed, failed
    passed, failed = 0, []
    # ---------- classify_pose ----------
    check("空畫面", classify_pose([]), "no_person")
    check("點數不足", classify_pose([(0.5, 0.5, 1.0)] * 10), "no_person")
    check("關節點信心太低", classify_pose(make_person(vis=0.2)), "no_person")

    check("站著不動", classify_pose(make_person()), "none")
    check("舉左手", classify_pose(make_person(lw=(0.60, 0.10))), "raise_left")
    check("舉右手", classify_pose(make_person(rw=(0.40, 0.10))), "raise_right")
    check("雙手舉高", classify_pose(make_person(lw=(0.60, 0.10), rw=(0.40, 0.10))), "both_up")
    check("雙手平舉", classify_pose(make_person(lw=(0.85, 0.31), rw=(0.15, 0.29))), "t_pose")
    check("手張開但垂下不算平舉", classify_pose(make_person(lw=(0.85, 0.60), rw=(0.15, 0.60))), "none")
    check("蹲下", classify_pose(make_person(shoulder_y=0.40, hip_y=0.70, ankle_y=0.90)), "squat")
    check("倒下", classify_pose(make_person(shoulder_y=0.80, hip_y=0.82, ankle_y=0.84, lean_x=0.30)), "fall")

    # 手腕被擋住時，不應該誤判成舉手
    hidden = make_person()
    hidden[L_WRIST] = (0.60, 0.10, 0.1)
    check("手腕看不清楚就不算舉手", classify_pose(hidden), "none")

    # 只高一點點（小於門檻）不算舉手
    check("手只抬一點點", classify_pose(make_person(lw=(0.60, 0.28))), "none")

    # ---------- PoseTrigger ----------
    t = PoseTrigger(window=5, hold=3, cooldown=10)
    fires = [t.update("none") for _ in range(5)]
    check("沒動作時不觸發", fires.count(None), 5)

    t = PoseTrigger(window=5, hold=3, cooldown=10)
    out = [t.update("raise_left") for _ in range(5)]
    check("維持夠久才觸發一次", [o for o in out if o], ["raise_left"])

    t = PoseTrigger(window=5, hold=3, cooldown=10)
    for _ in range(5):
        t.update("raise_left")
    more = [t.update("raise_left") for _ in range(20)]
    check("手一直舉著不會重複觸發", [o for o in more if o], [])

    t = PoseTrigger(window=5, hold=3, cooldown=2)
    for _ in range(5):
        t.update("raise_left")
    for _ in range(6):
        t.update("none")
    again = [t.update("raise_left") for _ in range(5)]
    check("手放下再舉可以再觸發", [o for o in again if o], ["raise_left"])

    # 中間夾雜一張判錯的畫面，多數決應該擋掉
    t = PoseTrigger(window=5, hold=3, cooldown=10)
    seq = ["raise_left", "raise_left", "both_up", "raise_left", "raise_left", "raise_left"]
    out = [t.update(p) for p in seq]
    check("偶爾判錯一張不受影響", [o for o in out if o], ["raise_left"])

    # 一個動作的冷卻時間，不應該擋住另一個動作
    t = PoseTrigger(window=3, hold=2, cooldown=50)
    fired = []
    for pose in ["raise_left"] * 3 + ["none"] * 3 + ["squat"] * 3:
        e = t.update(pose)
        if e:
            fired.append(e)
    check("不同動作各自冷卻", fired, ["raise_left", "squat"])

    # 換動作時要能觸發新的
    t = PoseTrigger(window=3, hold=2, cooldown=1)
    for _ in range(4):
        t.update("raise_left")
    out2 = [t.update("both_up") for _ in range(4)]
    check("換動作可以觸發新的", [o for o in out2 if o], ["both_up"])

    # ---------- 指令對照表 ----------
    check("舉左手→開綠燈", pose_to_command("raise_left"), "green_on")
    check("沒對應的動作", pose_to_command("none"), None)
    check("可以自訂對照表", pose_to_command("raise_left", {"raise_left": "blink"}), "blink")
    check("每個動作都有指令", sorted(DEFAULT_COMMANDS), ["both_up", "fall", "raise_left", "raise_right", "squat", "t_pose"])

    print(f"通過 {passed} 項，失敗 {len(failed)} 項")
    for f in failed:
        print("  X", f)
    if failed:
        return 1
    print("全部通過")
    return 0


if __name__ == "__main__":
    sys.exit(run_tests())
